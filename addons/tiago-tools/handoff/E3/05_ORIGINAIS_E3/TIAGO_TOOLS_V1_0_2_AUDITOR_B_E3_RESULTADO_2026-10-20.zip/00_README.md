# Auditor B — E3 — Tiago Tools v1.0.2 — 20/10/2026

**Gate desta rodada: GO ESTÁTICO PARA TESTES E4, estritamente em Blender real e ambiente descartável, com autorização do proprietário. NÃO É GO PRODUÇÃO.**

## Independência
Auditoria cega B. Fontes: somente kit individual Auditor B E3, base comum contida no kit e documentação oficial consultada por conta própria. Nenhum parecer E3 do Auditor A foi consultado. Nenhum ChatGPT Work foi utilizado. Candidata nunca alterada. Arquivos originais são preservados byte a byte. Blender real não foi executado.

## Como navegar
1. `01_PARECER_B.md` — veredito, riscos B-001...B-010, evidências e níveis de prova.
2. `02_MATRIZ_POR_ADDON.md` — classificação independente e cobertura das funções.
3. `03_EVIDENCIAS_E_TESTES/` — programa adversarial independente, relatório JSON e logs, comprovação de custódia e diff independente, fontes técnicas.
4. `04_MANIFESTO_SHA256.txt` — SHA-256 de todos os itens deste bundle, exceto o manifesto ele próprio.
5. `05_LIMITACOES_E_PENDENCIAS.md` — restrições e plano de testes E4 em Windows/Blender 5.0.0 e 5.2.2.
6. `06_PROMPT_CONTINUIDADE_MASTER.md` — handoff do auditor para o Master.
7. `07_ENTRADAS_CONGELADAS/` — ZIP recebido E3 original, candidato v1.0.2, baselines 1.0.1 e 1.0.0, sem qualquer alteração.

## Cadeia de custódia
- Remessa individual: SHA-256 `c47f15542385760ee9490ca676d42b516fead33bbcea26a48b5ea5c72449bce4`.
- Base comum: SHA-256 `aa65457eb4ff6035976d4181e9627ea3f7d287b465fad2a4b1c082d21f5b96a8`.
- Candidata `tiago-tools-1.0.2.zip`: SHA-256 `28cba4b80e058e726f1e802498588d80278897918a4163b554c6697edda5bad2`.
- Baseline v1.0.1: SHA-256 `30dc30ec35dc2b8444366bf4faea40dbe4106176cdea68b2604ae0750f191548`.
- Histórico v1.0.0: SHA-256 `18f727f6cb58297e94ac14af4c656b7ae631e56f71076aaf68bf9bb863406e99`.

## Reprodutibilidade offline
Execução de verificação do auditor B (Python 3.13+ com `tomllib`, sem `bpy` real):

```sh
python -I 03_EVIDENCIAS_E_TESTES/test_adversarial_independent_b_e3.py
```

O harness é portátil no bundle: localiza os ZIPs congelados em `07_ENTRADAS_CONGELADAS/` sem editá-los. Reproduza numa **cópia extraída e descartável** do bundle; os JSONs resultantes serão gravados na pasta do harness dessa cópia. O log e JSON originais estão incluídos e têm hashes próprios.

Exercícios de simulação não avaliam desempenho, RNA real, efeitos de Undo do Blender ou validação oficial do pacote. O número de cenários observados como risco não equivale a número de defeitos no Blender real.
