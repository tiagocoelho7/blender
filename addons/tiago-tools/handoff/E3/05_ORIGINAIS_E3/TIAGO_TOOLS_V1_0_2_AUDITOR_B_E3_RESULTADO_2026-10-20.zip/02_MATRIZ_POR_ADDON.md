# Matriz de auditoria E3 — v1.0.2

Há uma única extensão, **Tiago Tools**, com dois operadores e um painel. A classificação global `C - testes especiais` refere-se a necessidade de validar estados excepcionais em runtime Blender; não significa incompatibilidade demonstrada.

| Subcomponente | Versão / escopo | Evidência estática e offline do Auditor B | Risco residual | Classificação E3 |
|---|---|---|---|---|
| Pacote / manifesto | `blender_manifest.toml` | TOML válido; `schema_version=1.0.0`; `version=1.0.2`; hashes corretos | Falta validador CLI oficial Blender 5.0/5.2.2 | A — provável compatível (documental) |
| `TIAGO_OT_disable_modifiers` | `__init__.py:40-129` | AST idêntico 1.0.1; ALL inclui ocultos; VISIBLE_COLLECTIONS segue collection visível; render intacto; best effort; testes T-037..T-041 | Estado parcial intencional e Undo nativo não verificado; objetos linkados e crash não testados | A — provável compatível; gate funcional E4 |
| `TIAGO_OT_safe_add_subdivision` | `__init__.py:137-197` | Setter de 6 campos em sucesso; rollback de handle em falha cada setter, antes/depois; protege preexistentes e colisão de nome; T-001..T-036 + T-058..T-059 | Dupla falha de cleanup, `new` pós-efeito, comportamento Undo e janela de avaliação | C — testes especiais |
| Registro / desregistro | `__init__.py:239-293` | Ordem, idempotência local, rollback parcial e retry modelados; falhas pós-efeito também modeladas | Possíveis órfãos/phantom tracking se nativo alterar e lançar; atualizações/reloads | C — testes especiais |
| Painel UI | `__init__.py:205-237` | AST idêntico 1.0.1; dois conjuntos de botões; cores aleatórias removidas desde 1.0.1 | Disponibilidade/duplicidade de painel não verificadas em GUI real | A — provável compatível (estático) |
| Histórico v1.0.0 | ZIP baseline | SHA correto, somente comparação histórica; tinha recurso de cores | Não reintroduzir cores, não confundir com outro addon Tiago Global Scripts | Referência, não alvo |

## Cobertura por tipo de operação

| Controle | Prova obtida | Pendente|
|---|---|---|
| ZIP traversal, symlink, CRC, SHA | Cinco ZIPs, manifestos e todos os diff conferidos | Nenhum bloqueio de custódia atual |
| Sintaxe Python/TOML | `ast.parse`, `tomllib`, `compile` em mock, dados válidos | Parser/validador nativo extensão Blender |
| Safe Sub valor de 6 setters | Todos em mock independente | Leitura RNA real pós-operador em 5.0/5.2.2 |
| Safe Sub rollback antes/depois do setter | 12 casos com remove bem-sucedida | Linked/read-only, Edit Mode, Undo e desempenho |
| Safe Sub remove falha antes/depois | 12 casos deliberadamente anormais | Resiliência e Undo real diante de exceções nativas |
| Safe Sub `new` pós-alocação/interrupt | 3 casos anormais (T-028, T-029, T-059) | Possibilidade real no código nativo Blender ainda não comprovada |
| Preservar modifiers existentes | T-001, T-003..T-014, T-058 | Objetos reais com modifiers variados e driver/animation data |
| Batch Todas/Visíveis | T-037..T-041 | Visibilidade real por LayerCollection e objetos linkados/overrides |
| Register/Unregister | T-042..T-057 | RNA real, reload do módulo, updates, reinício, falha real |
| Undo nativo | Documentação oficial | NÃO EXECUTADO em Blender |
| Integridade `.blend` antes/depois | Nenhum arquivo `.blend` usado | E4 com fixtures descartáveis |
| Windows Blender 5.0/5.2.2 | NÃO EXECUTADO | Gate E4 obrigatório |

## Resultado do Auditor B

- Nenhuma quebra específica de API 5.2.2 comprovada.
- Confirmação estática de que mudanças E2 corrigem as causas principais do HOLD E1 sob as condições de rollback usual.
- Não é possível certificar compatibilidade real de execução, interface, persistência, undo ou eficiência sem E4.
- **Gate aprovado somente para testes controlados E4**, não para produção.
