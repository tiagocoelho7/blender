#!/usr/bin/env python3
"""Tiago Tools E3 independent Auditor B. Pure offline simulations; no Blender or real .blend files."""
from pathlib import Path
import types, sys, io, contextlib, traceback, hashlib, zipfile, json, time, ast, tomllib, platform

HERE=Path(__file__).resolve().parent
BUNDLE=HERE.parent
CAND=(BUNDLE/'07_ENTRADAS_CONGELADAS/tiago-tools-1.0.2.zip')
BASE=(BUNDLE/'07_ENTRADAS_CONGELADAS/tiago-tools-1.0.1.zip')
if not CAND.is_file(): CAND=Path('/mnt/data/audit_b_e3_work/inputs/01_CANDIDATA/tiago-tools-1.0.2.zip')
if not BASE.is_file(): BASE=Path('/mnt/data/audit_b_e3_work/inputs/02_BASELINE/tiago-tools-1.0.1.zip')
OUTPUT=HERE/'test_independent_b_e3_results.json'
FIELD_ORDER=['show_viewport','show_render','levels','render_levels','show_in_editmode','show_on_cage']
class Failure(Exception): pass

class FakeModifier:
    def __init__(self,name='Subdivision', mtype='SUBSURF',fail_field=None,fail_mode='before',noop_field=None):
        self.__dict__.update(name=name,type=mtype, fail_field=fail_field, fail_mode=fail_mode, noop_field=noop_field)
        self.__dict__.update(show_viewport=True,show_render=True,levels=2,render_levels=3,show_in_editmode=True,show_on_cage=True)
    def __setattr__(self,k,v):
        if k==self.__dict__.get('fail_field') and self.__dict__.get('fail_mode')=='before': raise Failure('INJECTED SET '+k+' BEFORE')
        if k==self.__dict__.get('noop_field'): return
        object.__setattr__(self,k,v)
        if k==self.__dict__.get('fail_field') and self.__dict__.get('fail_mode')=='after': raise Failure('INJECTED SET '+k+' AFTER')

class Modifiers(list):
    def __init__(self, seed=None):
        super().__init__(seed or []);self.created=[];self.removed=[]
        self.new_mode='normal';self.remove_mode='normal';self.fail_field=None;self.fail_mode='before';self.noop_field=None
    def new(self, *, name, type):
        if self.new_mode=='fail_before': raise Failure('INJECTED NEW BEFORE')
        m=FakeModifier(name=name,mtype=type,fail_field=self.fail_field,fail_mode=self.fail_mode,noop_field=self.noop_field)
        # Blender may automatically rename same-name modifiers; this fake only changes display name
        if any(x.name==name for x in self): m.name=name+'.001'
        self.append(m);self.created.append(m)
        if self.new_mode=='fail_after': raise Failure('INJECTED NEW AFTER ALLOC')
        if self.new_mode=='return_none': return None
        return m
    def remove(self,m):
        self.removed.append(m)
        if self.remove_mode=='fail_before': raise Failure('INJECTED REMOVE BEFORE')
        list.remove(self,m)
        if self.remove_mode=='fail_after': raise Failure('INJECTED REMOVE AFTER REMOVAL')

class FakeObj:
    def __init__(self,name='MESH', modifiers=None, obj_type='MESH'):
        self.name=name;self.type=obj_type;self.modifiers=modifiers if modifiers is not None else Modifiers()

class FakeLayer:
    def __init__(self, objects=(), children=(), visible=True):
        self.is_visible=visible; self.collection=types.SimpleNamespace(objects=objects); self.children=children

class FakeOp:
    def report(self, level, message):
        if not hasattr(self,'reports'):self.reports=[]
        self.reports.append((tuple(sorted(level)),message))
class FakePanel:pass

class FakeUtils:
    def __init__(self):
        self.registry=[];self.events=[];self.register_fail_at=None;self.unregister_fail_at=None;self.once_register=True;self.once_unregister=True
    def reg_idx(self,cls):
        known=['TIAGO_OT_disable_modifiers','TIAGO_OT_safe_add_subdivision','VIEW3D_PT_tiago_tools'];return known.index(cls.__name__)+1
    def register_class(self,cls):
        idx=self.reg_idx(cls);self.events.append(('register',idx))
        hit=self.register_fail_at is not None and idx==self.register_fail_at[0]
        if hit and self.register_fail_at[1]=='before':
            if self.once_register:self.register_fail_at=None
            raise Failure('INJECT REGISTER BEFORE '+str(idx))
        if cls in self.registry:raise Failure('DOUBLE REGISTER '+str(idx))
        self.registry.append(cls)
        if hit and self.register_fail_at[1]=='after':
            if self.once_register:self.register_fail_at=None
            raise Failure('INJECT REGISTER AFTER '+str(idx))
    def unregister_class(self,cls):
        idx=self.reg_idx(cls);self.events.append(('unregister',idx))
        hit=self.unregister_fail_at is not None and idx==self.unregister_fail_at[0]
        if hit and self.unregister_fail_at[1]=='before':
            if self.once_unregister:self.unregister_fail_at=None
            raise Failure('INJECT UNREGISTER BEFORE '+str(idx))
        if cls not in self.registry:raise Failure('NOT REGISTERED '+str(idx))
        self.registry.remove(cls)
        if hit and self.unregister_fail_at[1]=='after':
            if self.once_unregister:self.unregister_fail_at=None
            raise Failure('INJECT UNREGISTER AFTER '+str(idx))

class Environment:
    def __init__(self):
        with zipfile.ZipFile(CAND) as z: src=z.read('__init__.py').decode('utf-8')
        self.utils=FakeUtils()
        self.bpy=types.ModuleType('bpy');self.props=types.ModuleType('bpy.props');self.types=types.ModuleType('bpy.types')
        self.props.EnumProperty=lambda **opts:opts
        self.types.Operator=FakeOp;self.types.Panel=FakePanel
        self.bpy.utils=self.utils;self.bpy.props=self.props;self.bpy.types=self.types
        self.prev={k:sys.modules.get(k) for k in ('bpy','bpy.types','bpy.props')}
        sys.modules.update({'bpy':self.bpy,'bpy.types':self.types,'bpy.props':self.props})
        self.module=types.ModuleType('auditor_b_copia_descartavel');
        with contextlib.redirect_stdout(io.StringIO()):exec(compile(src,'CANDIDATE_COPY/__init__.py','exec'),self.module.__dict__)
    def close(self):
        for k,v in self.prev.items():
            if v is None:sys.modules.pop(k,None)
            else:sys.modules[k]=v
    def safe(self,obj):
        op=self.module.TIAGO_OT_safe_add_subdivision()
        ctx=types.SimpleNamespace(active_object=obj)
        with contextlib.redirect_stdout(io.StringIO()) as out: result=op.execute(ctx)
        return result,getattr(op,'reports',[]),out.getvalue()
    def disable(self,scope,scene,root,view_layer=True):
        op=self.module.TIAGO_OT_disable_modifiers();op.scope=scope
        ctx=types.SimpleNamespace(scene=scene,view_layer=(types.SimpleNamespace(layer_collection=root) if view_layer else None))
        with contextlib.redirect_stdout(io.StringIO()) as out:result=op.execute(ctx)
        return result,getattr(op,'reports',[]),out.getvalue()

records=[]
def run(name,fn,classification='CONFORME',note=''):
    e=None
    try:
        with contextlib.redirect_stdout(io.StringIO()):detail=fn()
        status='OBSERVED' if classification=='RISCO_OBSERVADO' else 'PASS'
    except Exception as err:
        status='FAIL';detail=traceback.format_exc();e=err
    records.append({'id':f'T-{len(records)+1:03}','scenario':name,'status':status,'classification':classification,'evidence':detail,'note':note})
    return e

def isolated(fn):
    e=Environment()
    try:return fn(e)
    finally:e.close()

def safe_case(field=None,fieldmode='before',remove_mode='normal',new_mode='normal',preexisting=True,noop_field=None):
    def inner(e):
        old=FakeModifier('OLD','BEVEL')
        mods=Modifiers([old] if preexisting else [])
        mods.fail_field=field;mods.fail_mode=fieldmode;mods.remove_mode=remove_mode;mods.new_mode=new_mode;mods.noop_field=noop_field
        obj=FakeObj(modifiers=mods)
        result,reports,stdout=e.safe(obj)
        return mods,old,result,reports,stdout
    return isolated(inner)

def check_case(field=None,fieldmode='before',remove_mode='normal',new_mode='normal',preexisting=True,noop_field=None):
    mods,old,status,reports,stdout=safe_case(field,fieldmode,remove_mode,new_mode,preexisting,noop_field)
    assert status in ({'CANCELLED'},{'FINISHED'})
    return {'return':sorted(status),'surviving_modifiers':[{'name':m.name,'flags':{k:getattr(m,k) for k in FIELD_ORDER}} for m in mods],
            'created_count':len(mods.created),'removed_count':len(mods.removed),'preexisting_preserved':(old in mods and all(getattr(old,k)==v for k,v in [('show_viewport',True),('show_render',True),('levels',2)])),
            'reports':reports,'console':stdout.strip()}

def success_checks():
    s=check_case()
    assert s['return']==['FINISHED'] and s['created_count']==1 and s['removed_count']==0 and s['preexisting_preserved']
    assert len(s['surviving_modifiers'])==2
    assert list(s['surviving_modifiers'][-1]['flags'].values())==[False,False,0,0,False,False]
    return s
run('Safe Sub normal, seis propriedades e modifier preexistente intacto',success_checks)

def duplicate():
    def f(e):
        mods=Modifiers();obj=FakeObj(modifiers=mods)
        out=[e.safe(obj)[0] for _ in range(2)]
        assert out==[{'FINISHED'},{'FINISHED'}] and len(mods)==2 and len(mods.created)==2
        return {'statuses':out,'count':len(mods),'names':[m.name for m in mods]}
    return isolated(f)
run('Safe Sub duas chamadas acrescentam dois modifiers (contrato herdado)',duplicate)

for field in FIELD_ORDER:
 for when in ('before','after'):
    def f(field=field,when=when):
        s=check_case(field,when)
        assert s['return']==['CANCELLED'] and s['created_count']==s['removed_count']==1
        assert s['preexisting_preserved'] and len(s['surviving_modifiers'])==1
        assert 'novo modifier removido' in str(s['reports'])
        return s
    run(f'Setter {field} falha {when}: limpeza especifica e CANCELLED',f)

for field in FIELD_ORDER:
    def f(field=field):
        s=check_case(field,remove_mode='fail_before')
        assert s['return']==['FINISHED'] and len(s['surviving_modifiers'])==2
        assert s['preexisting_preserved'] and s['removed_count']==1
        assert 'WARNING' in str(s['reports']) and 'erro ao remover' in s['console']
        return s
    run(f'Setter {field} falha; remove falha ANTES: resto e FINISHED+warning',f,'RISCO_OBSERVADO','Preservação parcial depende do Undo real')

for field in FIELD_ORDER:
    def f(field=field):
        s=check_case(field,remove_mode='fail_after')
        assert s['return']==['FINISHED'] and len(s['surviving_modifiers'])==1
        assert s['preexisting_preserved'] and s['removed_count']==1
        assert 'WARNING' in str(s['reports'])
        return s
    run(f'Setter {field} falha; remove falha DEPOIS: final FINISHED sem resto',f,'RISCO_OBSERVADO','Conservador; aviso aponta possivel resto mesmo sem resto')

def new_before():
    s=check_case(new_mode='fail_before')
    assert s['return']==['CANCELLED'] and len(s['surviving_modifiers'])==1 and s['removed_count']==0 and s['preexisting_preserved']
    return s
run('new() falha ANTES de criacao: CANCELLED, sem alteracao',new_before)

def new_after():
    s=check_case(new_mode='fail_after')
    assert s['return']==['CANCELLED'] and len(s['surviving_modifiers'])==2 and s['removed_count']==0 and s['preexisting_preserved']
    return s
run('new() falha DEPOIS de inserir modifier mas sem devolver handle: CANCELLED com resto sem Undo',new_after,'RISCO_OBSERVADO','Injecao artificial plausivel em wrappers; sem evidencia de que bpy nativo emita esta sequencia')

def new_none():
    s=check_case(new_mode='return_none')
    assert s['return']==['CANCELLED'] and len(s['surviving_modifiers'])==2 and s['removed_count']==0
    return s
run('new() devolve None apos criar: CANCELLED com resto',new_none,'RISCO_OBSERVADO','API 5.2 documenta retorno de modifier; mock adversarial, nao falha confirmada do Blender')

for field in FIELD_ORDER:
    def f(field=field):
        s=check_case(noop_field=field)
        assert s['return']==['FINISHED'] and len(s['surviving_modifiers'])==2
        assert s['surviving_modifiers'][-1]['flags'][field] in (True,2,3)
        return s
    run(f'Setter {field} nao aplica valor e nao lanca excecao: FINISHED silencioso',f,'RISCO_OBSERVADO','Mock contrato degradado; RNA nativa requer confirmacao, nao se presume falha real')

def poll_check():
    def f(e):
        cls=e.module.TIAGO_OT_safe_add_subdivision
        observed=[cls.poll(types.SimpleNamespace(active_object=o)) for o in [None,FakeObj(obj_type='CURVE'),FakeObj(obj_type='MESH')]]
        assert observed==[False,False,True]
        return observed
    return isolated(f)
run('poll admite apenas objeto mesh ativo',poll_check)

def no_context():
    def f(e):
        empty=types.SimpleNamespace(scene=None,view_layer=None)
        op=e.module.TIAGO_OT_disable_modifiers();op.scope='ALL'
        ret=op.execute(empty)
        assert ret=={'CANCELLED'}
        return {'ret':ret,'reports':op.reports}
    return isolated(f)
run('Batch sem scene/viewlayer cancela sem efeito',no_context)

def batch_all():
    def f(e):
        hidden=FakeObj('HIDDEN',Modifiers([FakeModifier('H1')]))
        visible=FakeObj('VISIBLE',Modifiers([FakeModifier('V1')]))
        others=FakeObj('OTHER_SCENE',Modifiers([FakeModifier('X1')]))
        root=FakeLayer([visible],[FakeLayer([hidden],visible=False)])
        s=types.SimpleNamespace(objects=[visible,hidden])
        result,reports,log=e.disable('ALL',s,root)
        assert result=={'FINISHED'} and not visible.modifiers[0].show_viewport and not hidden.modifiers[0].show_viewport
        assert others.modifiers[0].show_viewport and all(o.modifiers[0].show_render for o in [hidden,visible,others])
        result2,reports2,log2=e.disable('ALL',s,root)
        assert 'Ja desativados: 2' in str(log2)
        return {'first_log':log,'second_log':log2,'result':result,'other_scene_unchanged':True}
    return isolated(f)
run('Batch TODOS: inclui invisiveis, exclui fora da scene; render permanece; repeticao',batch_all)

def batch_visible():
    def f(e):
        shared=FakeObj('SHARED',Modifiers([FakeModifier('M')]))
        in_hidden=FakeObj('HIDDEN',Modifiers([FakeModifier('H')]))
        in_visible=FakeObj('VISIBLE',Modifiers([FakeModifier('V')]))
        root=FakeLayer([],children=[FakeLayer([shared,in_visible]),FakeLayer([shared,in_hidden],visible=False)])
        scene=types.SimpleNamespace(objects=[shared,in_hidden,in_visible])
        result,reports,log=e.disable('VISIBLE_COLLECTIONS',scene,root)
        assert result=={'FINISHED'} and 'Objetos encontrados: 2' in log
        assert shared.modifiers[0].show_viewport==False and in_visible.modifiers[0].show_viewport==False and in_hidden.modifiers[0].show_viewport==True
        return {'result':result,'log':log}
    return isolated(f)
run('Batch VISIVEIS: exclui colecao oculta, dedup objeto em varias colecoes',batch_visible)

class ReadFailObj(FakeObj):
    @property
    def modifiers(self):raise Failure('INJECT READ modifiers')
    @modifiers.setter
    def modifiers(self,v):pass

class SetterFailModifier(FakeModifier):
    def __setattr__(self,k,v):
        if k=='show_viewport':raise Failure('INJECT disable write')
        super().__setattr__(k,v)

def batch_partial():
    def f(e):
        bad=FakeObj('BAD_WRITE',Modifiers([SetterFailModifier('X','BEVEL')]))
        read_bad=ReadFailObj('BAD_READ')
        good=FakeObj('GOOD',Modifiers([FakeModifier('G')]))
        scene=types.SimpleNamespace(objects=[read_bad,bad,good]);root=FakeLayer([])
        ret,reports,log=e.disable('ALL',scene,root)
        assert ret=={'FINISHED'} and len(reports)==1 and reports[0][0]==('WARNING',) and '2 erro' in str(reports)
        assert not good.modifiers[0].show_viewport and bad.modifiers[0].show_viewport
        return {'result':ret,'reports':reports,'log':log}
    return isolated(f)
run('Batch falha leitura e setter: best effort, report WARNING e estado parcial',batch_partial,'RISCO_OBSERVADO','Comportamento legado esperado; deve validar Undo em Blender real')

def scene_collection_raise():
    def f(e):
        class BrokenScene:
            @property
            def objects(self):raise Failure('SCENE OBJECTS UNAVAILABLE')
        try:e.disable('ALL',BrokenScene(),FakeLayer([]))
        except Failure as exc:return {'unhandled_exception':str(exc)}
        raise AssertionError('Expected exception')
    return isolated(f)
run('Batch excecao em scene.objects propaga sem report',scene_collection_raise,'RISCO_OBSERVADO','Comportamento herdado; erro no contexto fora do loop, efeito ainda nao ocorreu')

# Register/unregister lifecycle

def registration_normal():
    def f(e):
        with contextlib.redirect_stdout(io.StringIO()):
            e.module.register();e.module.register();e.module.unregister();e.module.unregister()
        assert not e.utils.registry and not e.module._REGISTERED_CLASSES
        return {'events':e.utils.events,'registry_after':[],'tracking_after':[]}
    return isolated(f)
run('Registro normal, duplo register, duplo unregister: tres classes e ordem inversa',registration_normal)

for idx in (1,2,3):
    def f(idx=idx):
        def act(e):
            e.utils.register_fail_at=(idx,'before')
            try:e.module.register()
            except Failure:pass
            else:raise AssertionError('Expected injected failure')
            assert not e.utils.registry and not e.module._REGISTERED_CLASSES
            e.module.register();e.module.unregister()
            assert not e.utils.registry and not e.module._REGISTERED_CLASSES
            return {'failure_idx':idx,'events':e.utils.events}
        return isolated(act)
    run(f'Registro falha ANTES do efeito na classe N={idx}; rollback e retry',f)

for idx in (1,2,3):
    def f(idx=idx):
        def act(e):
            e.utils.register_fail_at=(idx,'after')
            try:e.module.register()
            except Failure:pass
            else:raise AssertionError('Expected failure')
            actual=[c.__name__ for c in e.utils.registry];tracker=[c.__name__ for c in e.module._REGISTERED_CLASSES]
            assert len(actual)==1 and len(tracker)==0 and actual[0]==e.module.CLASSES[idx-1].__name__
            e.module.unregister()
            assert len(e.utils.registry)==1
            return {'injected_post_register_idx':idx,'registry_after_error':actual,'tracker_after_error':tracker,
                    'remaining_after_module_unregister':[c.__name__ for c in e.utils.registry],'events':e.utils.events}
        return isolated(act)
    run(f'Registro da classe N={idx} funciona mas API lanca excecao depois: classe orfa invisivel',f,'RISCO_OBSERVADO','Hipotetico em API nativa; mock pos-efeito confirma buraco de rastreio')

for idx in (1,2,3):
    def f(idx=idx):
        def act(e):
            e.module.register();e.utils.unregister_fail_at=(idx,'before')
            try:e.module.unregister()
            except RuntimeError:pass
            else:raise AssertionError('Expected RuntimeError')
            assert len(e.module._REGISTERED_CLASSES)==1 and len(e.utils.registry)==1
            e.module.unregister();assert not e.utils.registry and not e.module._REGISTERED_CLASSES
            return {'idx':idx,'events':e.utils.events,'retry_clean':True}
        return isolated(act)
    run(f'Unregister falha ANTES da remocao N={idx}: rastreia pendencia e retry resolve',f)

for idx in (1,2,3):
    def f(idx=idx):
        def act(e):
            e.module.register();e.utils.unregister_fail_at=(idx,'after')
            try:e.module.unregister()
            except RuntimeError:pass
            else:raise AssertionError('Expected RuntimeError')
            assert len(e.module._REGISTERED_CLASSES)==1 and not e.utils.registry
            try:e.module.unregister()
            except RuntimeError as x:msg=str(x)
            else:raise AssertionError('Expected RuntimeError again')
            assert len(e.module._REGISTERED_CLASSES)==1 and not e.utils.registry
            # Subsequent register skips phantom class (class is not installed).
            e.module.register()
            assert len(e.utils.registry)==2 and len(e.module._REGISTERED_CLASSES)==3
            return {'idx':idx,'events':e.utils.events,'stale_tracked':[c.__name__ for c in e.module._REGISTERED_CLASSES],
                   'registered_actual':[c.__name__ for c in e.utils.registry],'error_retry':msg}
        return isolated(act)
    run(f'Unregister remove classe N={idx} mas lanca excecao: tracking fantasma e retry falha',f,'RISCO_OBSERVADO','Injecao pos-efeito; discrepancia real requer confirmação')

for idx in (2,3):
    def f(idx=idx):
        def act(e):
            e.utils.register_fail_at=(idx,'before');e.utils.unregister_fail_at=(idx-1,'before')
            try:e.module.register()
            except Failure:pass
            else:raise AssertionError('Expected failure')
            # Previous class rollback failed, should remain in tracked state.
            assert len(e.module._REGISTERED_CLASSES)==1 and len(e.utils.registry)==1
            e.module.unregister();assert not e.utils.registry and not e.module._REGISTERED_CLASSES
            return {'events':e.utils.events,'retry_clean':True,'idx':idx}
        return isolated(act)
    run(f'Register falha N={idx} + rollback anterior tambem falha; unregister retry limpa',f)

def module_reload():
    def f(e):
        e.module.register()
        first_reg=list(e.utils.registry)
        # A second module instance is created with fresh class identities: likely during hot-reload, not normal lifecycle
        with zipfile.ZipFile(CAND) as z:src=z.read('__init__.py').decode()
        alt=types.ModuleType('second_module_copy')
        exec(compile(src,'RELOAD_COPY/__init__.py','exec'),alt.__dict__)
        try:alt.register()
        except Exception as exc:return {'exc':str(exc),'remaining_original':len(e.utils.registry),'new_tracked':len(alt._REGISTERED_CLASSES)}
        # FakeUtils class-object uniqueness permits a duplicate-by-name (real Blender rejects); this is a risk
        return {'duplicate_ids_after_reload':[cl.__name__ for cl in e.utils.registry],'new_tracked':len(alt._REGISTERED_CLASSES)}
    return isolated(f)
run('Modulos recompilados/hot-reload geram classe com nova identidade',module_reload,'RISCO_OBSERVADO','Mock registro nao e RNA real; gate Blender real para conflito entre geracoes')


# Targeted identity protection (preexisting same-name modifier).
def same_name_safety():
    def f(e):
        pre=FakeModifier('Subdivision','SUBSURF')
        mods=Modifiers([pre]);mods.fail_field='show_on_cage'
        obj=FakeObj(modifiers=mods)
        ret,reports,out=e.safe(obj)
        assert ret=={'CANCELLED'} and len(mods)==1 and mods[0] is pre
        assert len(mods.removed)==1 and mods.removed[0] is not pre
        assert mods.created[0].name=='Subdivision.001'
        return {'status':ret,'existing_retained':mods[0] is pre,'new_name':mods.created[0].name,'removed_handle_is_new':mods.removed[0] is mods.created[0]}
    return isolated(f)
run('Safe Sub com nome duplicado: remocao por identidade preserva Subdivision antigo',same_name_safety)

# Abrupt Python-level interruption bypasses `except Exception`. This is a model, not a claim about native crash safety.
def interrupted_setter():
    def f(e):
        class InterruptMod(FakeModifier):
            def __setattr__(self,k,v):
                if k=='show_viewport': raise KeyboardInterrupt('simulated-interruption')
                super().__setattr__(k,v)
        class InterruptModifiers(Modifiers):
            def new(self,*,name,type):
                m=InterruptMod(name,type)
                self.append(m);self.created.append(m);return m
        mods=InterruptModifiers([FakeModifier('OLD','BEVEL')])
        try:e.safe(FakeObj(modifiers=mods))
        except KeyboardInterrupt as exc:
            assert len(mods)==2 and len(mods.removed)==0
            return {'uncaught':str(exc),'created_leftover':len(mods.created),'remaining':len(mods),'undo_step':'unknown_not_executed_bpy_ops'}
        raise AssertionError('KeyboardInterrupt should propagate')
    return isolated(f)
run('Interrupcao abrupta durante setter (KeyboardInterrupt) escapa catch e deixa estado parcial',interrupted_setter,'RISCO_OBSERVADO','Modelo de interrupcao Python; nao extrapolar para crash real do Blender')

# independent source audits

def source_static():
    with zipfile.ZipFile(CAND) as z:source=z.read('__init__.py').decode();manifest=tomllib.loads(z.read('blender_manifest.toml').decode());members=set(z.namelist())
    with zipfile.ZipFile(BASE) as z: old=z.read('__init__.py').decode()
    a=ast.parse(source);b=ast.parse(old)
    def ast_obj(tr,n):return next(x for x in tr.body if isinstance(x,(ast.ClassDef,ast.FunctionDef)) and x.name==n)
    identity={n:ast.dump(ast_obj(a,n),include_attributes=False)==ast.dump(ast_obj(b,n),include_attributes=False) for n in ['_collect_objects_from_visible_collections','TIAGO_OT_disable_modifiers','VIEW3D_PT_tiago_tools']}
    assert all(identity.values())
    assert manifest['schema_version']=='1.0.0' and manifest['version']=='1.0.2' and manifest['blender_version_min']=='5.0.0' and manifest['id']=='tiago_tools'
    import_nodes=[n for n in a.body if isinstance(n,(ast.Import,ast.ImportFrom))]
    modules=[n.module if isinstance(n,ast.ImportFrom) else ','.join(t.name for t in n.names) for n in import_nodes]
    assert modules==['bpy','bpy.props','bpy.types']
    assert 'random' not in source and not any('random' in k for k in members)
    return {'manifest':manifest,'AST_equal':identity,'imports':modules,'members':sorted(members)}
run('AST regressao, sintaxe e manifesto TOML, imports sem dependencias externas',source_static)

ok=sum(r['status']=='PASS' for r in records)
risks=sum(r['status']=='OBSERVED' for r in records)
failed=sum(r['status']=='FAIL' for r in records)
result={'auditor':'B independente','timestamp_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
'platform':platform.platform(),'python':platform.python_version(),'bpy':'SIMULADO','blender_real':'NAO_EXECUTADO',
'candidate_sha256':hashlib.sha256(CAND.read_bytes()).hexdigest(),
'summary':{'total':len(records),'pass':ok,'observed_risks':risks,'failed_assertions':failed},
'cases':records}
OUTPUT.write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda o: sorted(o) if isinstance(o,set) else str(o)),encoding='utf-8')
print('ENV python='+platform.python_version()+' bpy=INDEPENDENT_MOCK blender=NOT_INSTALLED')
print('CANDIDATE_SHA256='+result['candidate_sha256'])
for r in records:
 print(f"{r['id']} {r['status']} {r['classification']} {r['scenario']}")
 if r['status']=='FAIL': print(r['evidence'])
print('SUMMARY:',result['summary'])
sys.exit(1 if failed else 0)
