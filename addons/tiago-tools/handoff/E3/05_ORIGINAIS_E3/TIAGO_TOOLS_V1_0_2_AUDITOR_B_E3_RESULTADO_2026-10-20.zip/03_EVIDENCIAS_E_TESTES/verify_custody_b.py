from pathlib import Path
import hashlib, zipfile, io, stat, difflib, tomllib, ast, json, sys
HERE=Path(__file__).resolve().parent
BUNDLE=HERE.parent
outer_path=BUNDLE/'07_ENTRADAS_CONGELADAS/TIAGO_TOOLS_V1_0_2_AUDITOR_B_E3_2026-10-20(1).zip'
if not outer_path.is_file(): outer_path=Path('/mnt/data/TIAGO_TOOLS_V1_0_2_AUDITOR_B_E3_2026-10-20(1).zip')
H=lambda bs: hashlib.sha256(bs).hexdigest()
def chk_zip(label,data,expected=None):
  assert expected is None or H(data)==expected,(label,'SHA mismatch', H(data), expected)
  out={'label':label,'sha256':H(data),'entries':[],'checks':{}}
  with zipfile.ZipFile(io.BytesIO(data)) as z:
    assert z.testzip() is None
    names=z.namelist(); assert len(names)==len(set(names))
    for f in z.infolist():
      name=f.filename; mode=f.external_attr>>16
      assert not (name.startswith('/') or '..' in name.replace('\\','/').split('/') or '\\' in name or ':' in name.split('/')[0] or stat.S_ISLNK(mode)), f'{label} unsafe {name}'
      out['entries'].append({'name':name,'size':f.file_size,'sha256':H(z.read(f))})
    manifest=z.read('99_MANIFESTO_SHA256.txt').decode()
    lines=[l for l in manifest.splitlines() if l.strip() and not l.lstrip().startswith('#')]
    entries=[]
    for line in lines:
      h,name=line.split('  ',1); assert H(z.read(name))==h,(label,name)
      entries.append(name)
    assert set(entries)==set(names)-{'99_MANIFESTO_SHA256.txt'},(label,'manifest incompleteness')
    out['checks']['zip_testzip']='OK';out['checks']['safe_paths_modes']='OK';out['checks']['sha_manifest_count']=len(entries)
  return out
reports=[]
outer=outer_path.read_bytes();reports.append(chk_zip('outer E3 Auditor B',outer))
with zipfile.ZipFile(io.BytesIO(outer)) as oz:
    common=oz.read('01_E3_BASE_COMUM.zip')
reports.append(chk_zip('base comum E3',common,'aa65457eb4ff6035976d4181e9627ea3f7d287b465fad2a4b1c082d21f5b96a8'))
with zipfile.ZipFile(io.BytesIO(common)) as z:
  for kind,name,expect in [
   ('v1.0.0 historica','02_BASELINE/tiago-tools-1.0.0_HISTORICO.zip','18f727f6cb58297e94ac14af4c656b7ae631e56f71076aaf68bf9bb863406e99'),
   ('v1.0.1 baseline','02_BASELINE/tiago-tools-1.0.1.zip','30dc30ec35dc2b8444366bf4faea40dbe4106176cdea68b2604ae0750f191548'),
   ('v1.0.2 candidata','01_CANDIDATA/tiago-tools-1.0.2.zip','28cba4b80e058e726f1e802498588d80278897918a4163b554c6697edda5bad2')]:
      b=z.read(name)
      # inner ZIP no manifest (maybe SHA256SUMS instead)
      assert H(b)==expect
      with zipfile.ZipFile(io.BytesIO(b)) as zz:
         assert zz.testzip() is None
         assert len(zz.namelist())==len(set(zz.namelist()))
         for info in zz.infolist():
            path=info.filename;mode=info.external_attr>>16
            assert not (path.startswith('/') or '..' in path.replace('\\','/').split('/') or '\\' in path or ':' in path.split('/')[0] or stat.S_ISLNK(mode))
         members=zz.namelist()
         inner={'label':kind,'sha256':H(b),'entries':[{'name':m,'sha256':H(zz.read(m))} for m in members],'checks':{'testzip':'OK','paths_modes':'OK'}}
         if 'SHA256SUMS.txt' in members:
           sha=zz.read('SHA256SUMS.txt').decode().splitlines()
           n=[]
           for l in sha:
             h,f=l.split('  ',1);assert H(zz.read(f))==h,(kind,f);n.append(f)
           assert set(n)==set(members)-{'SHA256SUMS.txt'}
           inner['checks']['sha256sums_count']=len(n)
         reports.append(inner)
      if kind=='v1.0.2 candidata': candidate=b
      elif kind=='v1.0.1 baseline': baseline=b
  with zipfile.ZipFile(io.BytesIO(candidate)) as c, zipfile.ZipFile(io.BytesIO(baseline)) as b:
    cd={n:c.read(n) for n in c.namelist()};bd={n:b.read(n) for n in b.namelist()}
    check_diff={}
    for fn,patchname in [('__init__.py','__init___py.patch'),('blender_manifest.toml','blender_manifest_toml.patch'),('README.txt','README_txt.patch'),('CHANGELOG.txt','CHANGELOG_txt.patch'),('SHA256SUMS.txt','SHA256SUMS_txt.patch')]:
      actual=''.join(difflib.unified_diff(bd[fn].decode().splitlines(keepends=True),cd[fn].decode().splitlines(keepends=True),fromfile=f'v1.0.1/{fn}',tofile=f'v1.0.2/{fn}'))
      reported=z.read('07_DIFF/'+patchname).decode()
      check_diff[fn]={'exact':actual==reported,'declared_hash':H(reported.encode()),'computed_hash':H(actual.encode()), 'changed':bd[fn]!=cd[fn]}
    reports.append({'label':'diffs recomputados','check_diff':check_diff})
    m=tomllib.loads(cd['blender_manifest.toml'].decode());src=ast.parse(cd['__init__.py'].decode())
    assert m['schema_version']=='1.0.0' and m['version']=='1.0.2' and m['blender_version_min']=='5.0.0'
    assert any(isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='bl_info' for t in n.targets) for n in src.body)
    key=['_collect_objects_from_visible_collections','TIAGO_OT_disable_modifiers','VIEW3D_PT_tiago_tools']
    def node(k,tree):return next(n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==k)
    astchecks={k:ast.dump(node(k,src),include_attributes=False)==ast.dump(node(k,ast.parse(bd['__init__.py'].decode())),include_attributes=False) for k in key}
    reports.append({'label':'TOML AST','manifest':m,'AST_identical':astchecks})
report_file=HERE/'custodia_indep_b_e3.json'
report_file.write_text(json.dumps(reports,ensure_ascii=False,indent=2))
print('ALL ZIP CRC SAFE, MANIFEST CHECKS OK')
for r in reports:
 print(r['label'],r.get('sha256',''),r.get('checks',r.get('check_diff',r.get('AST_identical',''))))
