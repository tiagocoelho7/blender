# Alegações do autor versus avaliação independente B

**Atenção**: a entrega do Master/autor v1.0.2 contém 23 testes. Esses resultados **não foram aceitos por confiança** nem somados aos 60 cenários do B como se fossem evidência independente. Foram lidos como orientação do que contestar.

| Alegação do autor | Constatação independente | Extensão / lacuna |
|---|---|---|
| 3 ZIPs históricos/candidato com hashes declarados | **CONFIRMADO** (`custodia_indep_b_e3.json`) | Inclui CRC, ZIP traversal, symlink, 5 diffs e SHA256SUMS; não há mudança de bytes |
| v1.0.2 remove modifier novo se setter falha | **CONFIRMADO EM MOCK** | 6 setters com erro antes/depois (T-003..14), colisão de nome e preservação do original (T-058) |
| `remove()` falhando gera `FINISHED`+warning | **CONFIRMADO EM MOCK** | Falha antes (novo modifier residual, T-015..20) e depois (sem residual, T-021..26) testadas por B |
| Falha em `new()` retorna `CANCELLED` | **CONFIRMADO PARA FALHA SEM EFEITO** (T-027) | Cenário adversarial de mutação antes de lançar (T-028/29) deixa residual; não demonstrado em API real |
| Mantém Safe Sub com duas chamadas adicionais | **CONFIRMADO EM MOCK** (T-002) | Repetição intencional é risco de acumulação em cenas pesadas |
| Registro normal e rollback de classes | **CONFIRMADO EM MOCK** para falha antes do registro (T-042..45; T-055..56) | Falha após registro cria órfão no modelo (T-046..48); efeito nativo não confirmado |
| Unregister permite retry | **CONFIRMADO EM MOCK** para falha antes da remoção (T-049..51) | Falha após remoção cria tracking fantasma no modelo (T-052..54); nativo pendente |
| Preservação do batch/painel 1.0.1 | **CONFIRMADO AST** (`T-060` + custódia) | Batch funcional nativo, render/GUI e Undo ainda pendentes |
| Manifesto schema_version corrigido | **CONFIRMADO por TOML e fonte oficial** | `blender --command extension validate` nos Blenders não executado |
| 23/23 testes do autor | **LOG DISPONÍVEL NO KIT**, sem validação independente de sua própria suíte | O B criou suíte própria de 60 cenários; não reproduziu a suíte do autor como principal fonte de evidência |
| Prova de Blender 5.0 e 5.2.2 | **NÃO ALEGADA PELO AUTOR E NÃO PRODUZIDA PELO B** | Somente E4 pode suprir |

Este documento não traz parecer E3 do outro auditor. A decisão após comparação A/B cabe ao Master/proprietário.
