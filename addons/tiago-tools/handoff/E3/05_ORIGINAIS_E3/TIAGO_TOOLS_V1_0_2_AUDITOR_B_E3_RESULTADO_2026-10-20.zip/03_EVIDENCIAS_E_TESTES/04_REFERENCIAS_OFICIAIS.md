# Fontes técnicas públicas verificadas separadamente pelo Auditor B

Consulta em 20/10/2026 via busca de documentação pública indexada. A indisponibilidade eventual de acesso direto a algumas páginas não foi ocultada; referências são links oficiais que podem ser conferidos pelo Master. Estes documentos ajudam a estabelecer a plausibilidade da API, mas **não substituem executar o Blender**.

1. **Extensions / manifesto**, manual 5.2 LTS: https://docs.blender.org/manual/en/5.2/advanced/extensions/getting_started.html — exemplo oficial de `blender_manifest.toml` usa `schema_version = "1.0.0"`, com versão da extensão em `version`, id e mínima declarados separadamente. Referência indexada do mesmo manual: https://docs.blender.org/manual/nl/5.2/advanced/extensions/getting_started.html.
2. **CLI extensão**, manual 5.2 LTS: https://docs.blender.org/manual/en/5.2/advanced/command_line/extension_arguments.html — subcomando `blender --command extension validate [SOURCE_PATH]`, valida diretório ou ZIP. Espelho localizado da própria documentação oficial pesquisado: https://docs.blender.org/manual/sl/5.2/advanced/command_line/extension_arguments.html.
3. **Operator / Undo**, API 5.0 e 5.2: https://docs.blender.org/api/5.0/bpy.types.Operator.html e https://docs.blender.org/api/5.2/bpy.types.Operator.html — `bl_options={'REGISTER','UNDO'}` e retorno `{'FINISHED'}` criam etapa Undo no ciclo normal; `{'CANCELLED'}` não cria uma etapa normal de Undo. Isto explica o fallback de 1.0.2, sem provar seu resultado no contexto nativo.
4. **ObjectModifiers**, API 5.2: https://docs.blender.org/api/5.2/bpy.types.ObjectModifiers.html — `new(name, type)` cria modifier e devolve handle, `remove(modifier)` opera por handle. Sem contrato documentado de rollback em falha pós-efeito. Snippets de documentação oficial de 5.0 também foram encontrados: https://docs.blender.org/UATEST/api/current/bpy.types.ObjectModifiers.html.
5. **Modifier**, API 5.0 e 5.2: https://docs.blender.org/api/5.0/bpy.types.Modifier.html e https://docs.blender.org/api/5.2/bpy.types.Modifier.html — propriedades `show_viewport`, `show_render`, `show_in_editmode`, `show_on_cage` exibidas como membros da API.
6. **SubsurfModifier**, API 5.0: https://docs.blender.org/api/5.0/bpy.types.SubsurfModifier.html — `levels`, `render_levels` documentados. Não implica teste RNA 5.2.2.
7. **LayerCollection**, API 5.0 e edição moderna: https://docs.blender.org/api/5.0/bpy.types.LayerCollection.html; https://docs.blender.org/api/5.4/bpy.types.LayerCollection.html — `is_visible`, `children`, `collection` documentados; não é igual a chamar `Object.visible_get`.
8. **Utilities**, API de Blender: https://docs.blender.org/api/5.2/bpy.utils.html — interface de `register_class` e `unregister_class`, ciclo deve ser medido na instalação real.

## Síntese da compatibilidade

Não apareceu evidência documental de remoção das APIs do candidato de 5.0.0 até 5.2.2. A ausência de incompatibilidade encontrada aqui **não constitui certificação da execução real** em ambas as versões. O validador `extension validate` **não foi executado**, porque Blender não estava instalado no ambiente de testes do Auditor B.
