# Limitações, condições do gate E4 e testes necessários

## Limites imutáveis desta rodada E3

1. NÃO houve instalação, execução ou carregamento em Blender 5.0.0 ou Blender 5.2.2 LTS.
2. NÃO houve teste em Windows, GUI, `bpy`/RNA real, atualização de extensões, persistência, `.blend` real, exceções C/RNA nativas, consumo de memória, avaliação de depsgraph, renderização ou Undo real.
3. O runtime do harness B foi CPython 3.13.5 em container; foi simulado um módulo `bpy`, sem comandos do Blender ou alteração de arquivos reais. Todos os resultados de erro pós-efeito são modelos e **não provam que a API nativa produz esses efeitos**.
4. Não é cientificamente válido usar a quantidade de `PASS` do harness como validação de compatibilidade nativa. Foram deliberadamente criados modos anormais que devem mostrar risco; sua observação é um resultado esperado do teste, não falha de asserção.
5. Não foram acessados dados do outro auditor, nem acionado Work. A única evidência do autor disponível foi estudada criticamente, sem adotá-la como validação independente.
6. Nenhum código da candidata foi modificado; os scripts e logs produzidos pertencem somente ao Auditor B.

## Plano de E4 (somente depois de autorização do proprietário e conciliação do Master)

**Ambiente:** Windows; **dois executáveis verificáveis**, Blender 5.0.0 e 5.2.2 LTS, com perfis/configs independentes e descartáveis. Evitar salvar startup real ou sobrescrever .blend legacy e perfis reais. Registrar versões exatas, Python incorporado, hashes dos ZIPs, perfil e ambiente.

### G0 — Custódia / validador / instalação

- Registrar SHA v1.0.2 `28cba4b80e058e726f1e802498588d80278897918a4163b554c6697edda5bad2` na máquina de testes e confrontar byte a byte antes da instalação.
- Executar em cada executável **sem modificar a candidata**: `"<BLENDER_EXE>" --command extension validate "<ZIP_CANDIDATA>"`, coletar saída e exit code (sintaxe oficial documentada em *Extensions Command Line Arguments*). Se a distribuição usar sintaxe diferente, registrar help/exato comando em vez de declarar sucesso sem validação.
- Instalar em perfil temporário. Testar import, register/unregister, habilitar/desabilitar; registrar logs íntegros; confirmar 3 classes e painel sem duplicidade.
- Upgrade sequencial 1.0.1→1.0.2 e reinício; garantir que o outro addon `Tiago Global Scripts` não seja alterado. Não mover ou remover outros addons.

### G1 — Safe Sub em fixture mínima

- Mesh local pequena, modo Object. Incluir modifier preexistente chamado Subdivision e outro de tipo diferente, registrar todos os atributos e ordem antes/depois (identidade do handle se observável).
- Clicar uma vez: exatamente um Subsurf novo com `show_viewport=False`, `show_render=False`, `levels=0`, `render_levels=0`, `show_in_editmode=False`, `show_on_cage=False`; original intacto.
- Clicar duas vezes: dois novos modifiers previstos; documentar nomes e custo. Fazer Ctrl+Z e confirmar estado/contagem preservados ou revertidos como esperado. Testar via painel e, se aplicável, via `bpy.ops`, sem presumir equivalência de contexto.
- Exercitar Edit Mode, objeto não mesh, nenhum objeto ativo, linked / library override em fixtures inteiramente descartáveis. Coletar `INFO/WARNING/ERROR`, efeito real, e status do operador. Não fabricar hard crashes ou corromper dados para forçar exceção.
- Investigar dentro das limitações de segurança o caso de erro de configuração com falha de limpeza. Se não for possível induzir isso com segurança no Blender, manter como **risco residual não validado**, em vez de marcar PASS.

### G2 — Batch modifiers

- Scene pequena com 2-3 collections visíveis, collection oculta/excluída, objeto em mais de uma collection e objetos com dois modifiers (um ativo, outro desativado).
- `Todos`: processa objetos da Scene independentemente de collection oculta, sem alterar collections; `Visíveis`: seleciona somente collections visíveis no view layer, não `Object.visible_get`.
- Validar contagens, `show_viewport`, intangibilidade de `show_render`, ordem dos modifiers, retries, Undo e warnings. Não testar diretamente em acervo real.
- Linked/library override e objetos sem permissões: confirmar que failures best-effort não silenciam erro do lote e que alterações parciais são compreendidas.

### G3 — Ciclo de vida e compatibilidade

- Registro/desregistro N=1..3 de classes, desabilitar/reabilitar, fechar/reabrir Blender, atualização 1.0.1→1.0.2 em perfil temporário; observar duplicação ou ausência de botões e operadores, sem tocar classes de terceiros.
- Se for seguro, testar caminhos de falha de registro sem monkeypatch de RNA em perfil real; caso contrário, consignar como hipótese do auditor independente.
- Em ambas as versões repetir a mesma matriz funcional; verificar mensagens, botões, manifestos, Undo, estado após salvar/reabrir fixture **copiada**. Não regravar um arquivo original 5.0 dentro do 5.2.2 para supor retrocompatibilidade.
- Medir tempo/memória/crashes em meshs crescentes somente se G1/G2 satisfatórios, começando com malha pequena. Assumir que a chamada `new()` poderá disparar avaliação antes do primeiro setter.

### G4 — Gate final

O Master deve comparar A e B **após** entregas independentes, decidir se há patch E4 ou teste real adicional, manter hashes congelados, apontar riscos residuais e só recomendar aprovação ao proprietário depois de evidências. Sem autoaprovação pelo autor, sem Work não autorizado, sem modificar `.blend` real.

**Triggers de HOLD imediato:** falha CLI oficial/instalação, inconsistência de SHA, erro reproduzido de modifier preexistente alterado/removido, flags Safe Sub incorretas, perda de Undo em alteração parcial, classe órfã/duplicada, regressão ALL/VISIBLE_COLLECTIONS ou crash em fixture simples.
