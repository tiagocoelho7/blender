# 02 — Matriz por addon (único pacote desta remessa)

| Campo | Estado verificado |
|---|---|
| Addon | Tiago Tools |
| Candidata | 1.0.2, `tiago-tools-1.0.2.zip` SHA `28cba4b80e058e726f1e802498588d80278897918a4163b554c6697edda5bad2` |
| Baseline principal | 1.0.1 SHA `30dc30ec35dc2b8444366bf4faea40dbe4106176cdea68b2604ae0750f191548` |
| Histórico | 1.0.0 SHA `18f727f6cb58297e94ac14af4c656b7ae631e56f71076aaf68bf9bb863406e99` |
| Tipo | Extensão instalável Blender: `blender_manifest.toml` + `__init__.py` |
| Requisitos declarados | `blender_version_min = "5.0.0"`, id `tiago_tools`; 5.2.2 LTS como alvo de migração |
| Dependências | Apenas `bpy`, `bpy.props.EnumProperty`, `bpy.types.Operator/Panel`; nenhuma biblioteca externa |
| Operadores | `tiago.disable_modifiers` (escopo `ALL`/`VISIBLE_COLLECTIONS`), `tiago.safe_add_subdivision` |
| Painel | `VIEW3D_PT_tiago_tools`, `VIEW_3D`, aba `Tiago`; 3 ações (Todos, Visíveis, Safe Sub) |
| Registros | `CLASSES` 3 classes, `register`, `unregister`, rastreamento e rollback novos |
| Escritas intencionais | `modifier.show_viewport = False` (batch); criação/edição/remoção modifier SUBSURF (Safe Sub); registro de classes em memória |
| Outras ações | Mensagens UI/console; não há implementação de escrita/remoção de arquivos ou rede |
| Comparação v1.0.1 | Batch/helper/UI AST idênticos; alteração do safe sub, registro e metadados; documentos atualizados |
| Histórico v1.0.0 | Continha operador Random Colors; já removido na v1.0.1, ausente na 1.0.2 |
| Compatibilidade API | Sem ruptura documental comprovada; validação runtime Blender 5.0 e 5.2.2 indisponível |
| Categoria A/B/C/D | **C — testes especiais**, pelo gate real obrigatório de Safe Sub/undo/registro |
| Veredito E3 Auditor A | **GO ESTÁTICO PARA TESTES** |
| Produção | **NÃO AUTORIZADA** |

## Invariantes a preservar em E4

1. `ALL` processa objetos da Scene, mesmo em collections não visíveis; `VISIBLE_COLLECTIONS` percorre `LayerCollection.is_visible`, elimina objetos repetidos e **não** faz filtro de ocultação individual.
2. Desativar Modifiers não altera flags de render, visibilidade de collection, IDs de objeto nem geometria; processo best-effort com aviso de falhas.
3. Safe Sub adiciona exatamente um SUBSURF por invocação a mesh ativa, tenta desligar 6 flags/níveis e mantém modifiers anteriores intactos; cliques repetidos adicionam novos.
4. Registrar classes 3 em ordem, desregistrar em ordem inversa, sem acumular duplicatas em chamadas repetidas no mesmo módulo.
5. Painel exibe somente `Modifiers` e `Subdivision`; função Random Colors não retorna.
6. ZIP instalável e metadados coerentes, sem intervenção na extensão distinta `Tiago Global Scripts`.
