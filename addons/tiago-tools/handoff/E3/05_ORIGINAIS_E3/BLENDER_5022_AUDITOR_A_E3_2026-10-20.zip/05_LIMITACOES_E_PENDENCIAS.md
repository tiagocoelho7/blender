# 05 — Limitações e pendências

## Informação demonstrada

- Hashes/manifestos ZIP de duas camadas e SHA256SUMS candidato íntegros.
- Diffs recompostos 5/5, patches declarados limitados às mudanças observadas.
- Contratos prévios Batch/UI/collections AST preservados.
- 59 testes **offline com mocks Python**, inclusive cenários artificiais de riscos, sem falhas do harness.
- Documentação Blender 5.0/5.2 consultada por resultados indexados para schema, API modifiers, `Operator`/Undo, registro, CLI.

## NÃO EXECUTADO / BLOQUEADO

- Blender 5.0.0 real, Blender 5.2.2 LTS real, Python embutido dessas versões.
- `blender --command extension validate` e instalação Extensões no Windows.
- Registro RNA real, ciclos GUI ou hot reload/upgrade in-session.
- Undo real de `bpy.ops.tiago.safe_add_subdivision`, especialmente em falha dupla; reabrir `.blend` descartável.
- Linked/Override reais, contexts fora de VIEW_3D, Edit Mode real, flags persistentes e consumo em meshes de grande porte.
- Provocar pós-efeito de exceção em `new()`/`register_class()` no Blender: mocks demonstram apenas condicional; não está provado que tal sequência existe na implementação nativa.
- Atestar integridade de dados de produção, que não foram acessados.
- Não consultado parecer atual do Auditor B; não utilizado Work.

## Gate seguinte

Master recebe ZIP A e de B em separado, compara sem contaminar Fase 1, decide necessidade de patch adicional e planeja E4 real autorizado em fixtures isoladas. Mesmo depois de E4, GO produção exige avaliação/decisão do proprietário. Se E4 detectar alterações residuais com retorno CANCELLED, Undo falho ou regressão concreta, aplicar HOLD.
