# Tiago Tools v1.0.2 — Auditor A, E3 independente

**Data:** 20/10/2026  
**Veredito:** **GO ESTÁTICO PARA TESTES** — estritamente testes reais isolados, **não GO PRODUÇÃO**.  
**Foco:** Blender 5.0.0 → 5.2.2 LTS; compatibilidade/API, semântica, preservação funcional e cenários adversariais.

## Escopo e independência

- Inspecionados os ZIPs congelados v1.0.0, v1.0.1 e v1.0.2; originais foram mantidos byte a byte.
- A remessa inclui relatório e testes do **autor (Master)**; tratados como declarações, não como auditoria independente.
- **Nenhum parecer do Auditor B ou de Work foi consultado. Nenhum Work acionado.**
- **Nenhuma alteração na candidata, nem execução Blender real/produção.** O código inspecionado da candidata foi executado **somente em memória com um `bpy` inteiramente simulado**.
- Ambiente de teste: Linux x86_64, CPython 3.13.5; executável Blender não encontrado no PATH.

## Índice

- `01_PARECER_A.md` — veredito, evidências, classificação, achados e gates.
- `02_MATRIZ_POR_ADDON.md` — matriz do addon e invariantes.
- `03_EVIDENCIAS_E_TESTES/00_CUSTODIA_SHA256.md` — verificação externa, interna e ZIPs congelados.
- `03_EVIDENCIAS_E_TESTES/01_DIFF_E_INVARIANTES.md` — delta v1.0.1→v1.0.2, referências históricas.
- `03_EVIDENCIAS_E_TESTES/02_TESTES_OFFLINE.md` — casos independentes e critérios.
- `03_EVIDENCIAS_E_TESTES/03_TESTES_OFFLINE.log` — saída integral dos 59 testes.
- `03_EVIDENCIAS_E_TESTES/04_HARNESS_A_INDEPENDENTE.py` — reprodução do harness (somente cópias em ambiente isolado).
- `03_EVIDENCIAS_E_TESTES/05_REFERENCIAS_API.md` — documentação Blender 5.0 e 5.2.
- `03_EVIDENCIAS_E_TESTES/06_ROTEIRO_BLENDER_REAL.md` — testes nativos obrigatórios em 5.0.0 e 5.2.2.
- `03_EVIDENCIAS_E_TESTES/07_AMBIENTE_COMANDOS.md` — comandos efetivos e restrições.
- `04_MANIFESTO_SHA256.txt` — hashes de TODOS os membros do presente ZIP, exceto este manifesto (evita auto-referência).
- `05_LIMITACOES_E_PENDENCIAS.md` — bloqueios e lacunas.
- `06_PROMPT_CONTINUIDADE_MASTER.md` — handoff pronto.
- `07_FONTES_CONGELADAS/` — ZIP original recebido e três ZIPs aninhados inalterados.

## Reprodução offline (sem Blender)

1. Extrair **este bundle** em diretório descartável em sistema Linux/macOS/Windows com Python 3.11+.
2. O harness carrega os **ZIPs congelados** já extraídos? Não: ele espera as fontes como arquivos no layout de trabalho. Para reprodução fiel sem alterar originais, execute este comando a partir do diretório extraído do bundle:

```sh
python -B 03_EVIDENCIAS_E_TESTES/08_REPRODUZIR_E3.py
```

Esse wrapper só cria cópias em uma pasta temporária e invoca o harness independente copiado, sem editar os ZIPs de origem. Consulte `07_AMBIENTE_COMANDOS.md` para a execução original.

> **Leitura correta:** `59/59 PASS` significa que os 59 testes do harness simulado satisfizeram suas asserções, incluindo asserções de que falhas artificiais podem deixar estados residuais. **Não significa 59 execuções Blender, nem que todas as situações são seguras.**

## Fluxo seguinte

Master concilia E3 A/B **sem inferir independência do teste do próprio autor**; define E4, obtém autorização específica e executa Blender 5.0.0 e 5.2.2 em perfil/arquivos descartáveis. Somente depois pode existir discussão de liberação, sujeito a decisão do proprietário.
