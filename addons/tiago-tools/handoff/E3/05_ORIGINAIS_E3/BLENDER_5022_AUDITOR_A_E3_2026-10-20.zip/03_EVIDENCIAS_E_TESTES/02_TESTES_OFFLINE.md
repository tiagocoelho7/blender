# E3 — Testes independentes offline

**Comando executado pelo Auditor A:**

```sh
python -B /mnt/data/tiago_e3_a_20261020/harness_a_independente.py > /mnt/data/tiago_e3_a_20261020/testes_a_independente.log 2>&1
```

**Ambiente:** CPython 3.13.5 / Linux x86_64, `bpy` integralmente simulado, sem Blender instalado/rodado. Mocks em memória, apenas cópias de ZIPs para leitura/inspeção. Não foi executado o teste do autor.

**Resultado:** 59 testes executados, `59 PASS`, `0 FAIL`, `0 ERROR`, saída no arquivo `03_TESTES_OFFLINE.log`.

## Grupos de cenários

- **Estático:** sintaxe Python (sem gerar bytecode), TOML, hash interno SHA256SUMS 4/4, 5 patches/diffs, AST inalterado de batch/coleta/painel/CLASSES, IDs, metadados, ausência de imports externos e operações de arquivo/rede.
- **Safe Sub:** seleção `None`, tipo errado em `poll`, `new` bem-sucedido, `new` falha antes/depois de side effect (hipótese), 6 propriedades desligadas, dois cliques/duplicação, falha antes/depois de cada um dos seis setters com remoção bem-sucedida, falha antes de remover em cada setter com fallback e modifier residual, `remove` que altera e só então lança (hipótese), modo EDIT sintético sem guard adicional.
- **Registro:** ordem, dupla chamada idempotente, rollback nas três posições, falha rollback com tracking, retomada, falha unregister individual/coletiva e retry, `register_class` que registra e lança (hipótese), alteração externa deixando tracking desatualizado (hipótese).
- **Batch/UI:** Todos incluindo ocultos, Visíveis por collections e não por objetos, pai oculto, deduplicação por múltiplas collections, tratamento de leitura defeituosa, idempotência, scene vazia, scene/view layer ausente, flags de render intocadas, três controles de UI/escopos corretos.

## Interpretação de PASS

Os casos que **identificam o limite do código** foram considerados PASS porque esperavam explicitamente esse limite no mock. `PASS` **não significa resolução** dos riscos A-E3-001/002/003/005, nem prova de que tais trajetórias são reproduzíveis na API nativa.

Não foi medido tempo, memória, dependências RNA, Undo real, existência das propriedades na versão exata do Blender ou capacidade de instalar extensão em Windows; estas lacunas estão no roteiro E4.
