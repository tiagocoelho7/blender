#!/usr/bin/env python3
"""Reproduce independent E3 harness solely in a disposable TemporaryDirectory.
No Blender required. Does not modify original archives.
"""
import hashlib
from io import BytesIO
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import zipfile

EVIDENCE=Path(__file__).resolve().parent
BUNDLE=EVIDENCE.parent
SOURCES=BUNDLE/'07_FONTES_CONGELADAS'
EXPECT={
 'REMESSA_A_E3_ORIGINAL.zip':'d622154d8351c446c5afc338110818500175e0dedf15b8e76df177a50bc09173',
 'tiago-tools-1.0.2.zip':'28cba4b80e058e726f1e802498588d80278897918a4163b554c6697edda5bad2',
 'tiago-tools-1.0.1.zip':'30dc30ec35dc2b8444366bf4faea40dbe4106176cdea68b2604ae0750f191548',
 'tiago-tools-1.0.0_HISTORICO.zip':'18f727f6cb58297e94ac14af4c656b7ae631e56f71076aaf68bf9bb863406e99',
}

def sha(blob):return hashlib.sha256(blob).hexdigest()
def read_zip_member_safely(zipf,member):
    p=PurePosixPath(member)
    if p.is_absolute() or '..' in p.parts or '\\' in member: raise RuntimeError('unsafe ZIP member: '+member)
    return zipf.read(member)

def main():
    for filename,expected in EXPECT.items():
        actual=sha((SOURCES/filename).read_bytes())
        if actual!=expected:raise RuntimeError(f'file altered: {filename}: {actual}')
    with tempfile.TemporaryDirectory(prefix='tiago_tools_e3_a_') as d:
        tmp=Path(d)
        for file in ('tiago-tools-1.0.2.zip','tiago-tools-1.0.1.zip','tiago-tools-1.0.0_HISTORICO.zip'):
            path=tmp/'sources'/file[:-4]
            with zipfile.ZipFile(SOURCES/file) as z:
                for i in z.infolist():
                    if i.is_dir():continue
                    dest=path/i.filename
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    dest.write_bytes(read_zip_member_safely(z,i.filename))
        with zipfile.ZipFile(SOURCES/'REMESSA_A_E3_ORIGINAL.zip') as outer:
            base=outer.read('01_E3_BASE_COMUM.zip')
        if sha(base)!='aa65457eb4ff6035976d4181e9627ea3f7d287b465fad2a4b1c082d21f5b96a8':
            raise RuntimeError('base SHA mismatch')
        with zipfile.ZipFile(BytesIO(base)) as inner:
            for i in inner.infolist():
                if not i.filename.startswith('07_DIFF/') or i.is_dir():continue
                dest=tmp/'received'/i.filename
                dest.parent.mkdir(parents=True,exist_ok=True)
                dest.write_bytes(read_zip_member_safely(inner,i.filename))
        shutil.copyfile(EVIDENCE/'04_HARNESS_A_INDEPENDENTE.py',tmp/'harness_a_independente.py')
        r=subprocess.run([sys.executable,'-B',str(tmp/'harness_a_independente.py')],cwd=tmp,capture_output=True,text=True)
        print(r.stdout,end='')
        if r.stderr: print(r.stderr,end='',file=sys.stderr)
        return r.returncode

if __name__=='__main__':sys.exit(main())
