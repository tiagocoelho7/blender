# E3 Auditor A — custódia e cadeia de hashes

Comando: `python -B 03_EVIDENCIAS_E_TESTES/10_VERIFICAR_CUSTODIA.py` dentro do bundle extraído. Log completo: `11_CUSTODIA_SAIDA.log`.

| ZIP/fonte | SHA256 efetivamente recalculado | Situação |
|---|---|---|
| Original externo `TIAGO_TOOLS_V1_0_2_AUDITOR_A_E3_2026-10-20(2).zip` (copiado em `07_FONTES_CONGELADAS/REMESSA_A_E3_ORIGINAL.zip`) | `d622154d8351c446c5afc338110818500175e0dedf15b8e76df177a50bc09173` | PASS |
| `01_E3_BASE_COMUM.zip` interno | `aa65457eb4ff6035976d4181e9627ea3f7d287b465fad2a4b1c082d21f5b96a8` | PASS |
| `01_CANDIDATA/tiago-tools-1.0.2.zip` | `28cba4b80e058e726f1e802498588d80278897918a4163b554c6697edda5bad2` | PASS |
| `02_BASELINE/tiago-tools-1.0.1.zip` | `30dc30ec35dc2b8444366bf4faea40dbe4106176cdea68b2604ae0750f191548` | PASS |
| `02_BASELINE/tiago-tools-1.0.0_HISTORICO.zip` | `18f727f6cb58297e94ac14af4c656b7ae631e56f71076aaf68bf9bb863406e99` | PASS |

- Manifesto externo: todos os 3 arquivos listados conferidos SHA256.
- Manifesto da base comum: todos os 13 arquivos listados conferidos SHA256.
- Dentro da candidata: `SHA256SUMS.txt` contém e confirma hashes 4/4 de `__init__.py`, `blender_manifest.toml`, `README.txt` e `CHANGELOG.txt`.
- Sem arquivo com caminho absoluto/`..`/drive do Windows, `symlink` ou ZIP criptografado; todos os arquivos examinados inferiores ao limite de tamanho configurado na verificação.
- Nenhuma alteração em `07_FONTES_CONGELADAS/`; cópias para teste são temporárias e destruídas após uso.
- Conteúdo do **outro Auditor** ausente da remessa e não consultado. `03_RELATORIO_AUTOR_NAO_INDEPENDENTE.md` e `04_TESTES_AUTOR` disponíveis na remessa apenas para conhecer alegações a contestar, jamais tratados como auditoria independente.

Duas saídas independentes do teste: execução original e reprodução portátil em diretório `TemporaryDirectory`; ambas com `59/59` testes simulados aprovados.
