#!/usr/bin/env python3
"""Verify received frozen E3 chain-of-custody, including manifest digests and safety.
Run on the delivered bundle; only reads ZIPs and prints evidence.
"""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
from zipfile import BadZipFile
import re
import stat

HERE=Path(__file__).resolve().parents[1]
FILES=HERE/'07_FONTES_CONGELADAS'
EXPECTED={'REMESSA_A_E3_ORIGINAL.zip':'d622154d8351c446c5afc338110818500175e0dedf15b8e76df177a50bc09173',
 'tiago-tools-1.0.2.zip':'28cba4b80e058e726f1e802498588d80278897918a4163b554c6697edda5bad2',
 'tiago-tools-1.0.1.zip':'30dc30ec35dc2b8444366bf4faea40dbe4106176cdea68b2604ae0750f191548',
 'tiago-tools-1.0.0_HISTORICO.zip':'18f727f6cb58297e94ac14af4c656b7ae631e56f71076aaf68bf9bb863406e99'}

def h(blob):return sha256(blob).hexdigest()
def scan(blob,label,validate_manifest=False):
    print(f'=== {label} sha256={h(blob)} ===')
    with ZipFile(BytesIO(blob)) as z:
        members=z.infolist()
        for i in members:
            name=i.filename
            assert not(name.startswith('/') or re.match(r'^[a-zA-Z]:',name) or '..' in name.split('/') or '\\' in name),name
            assert not(i.flag_bits&1),name
            assert (i.external_attr>>16)&0o170000 != stat.S_IFLNK,name
            assert i.file_size<20_000_000,name
            digest=h(z.read(name))
            print(f'{digest}  {name} size={i.file_size}')
        if validate_manifest:
            text=z.read('99_MANIFESTO_SHA256.txt').decode('utf-8')
            matched=0
            for line in text.splitlines():
                if line.startswith('#') or not line.strip():continue
                digest,name=line.split('  ',1)
                assert h(z.read(name))==digest,name
                matched+=1
            print('MANIFEST verified members:',matched)
            assert matched==len(members)-1
        print('ALL MEMBERS VALID:',len(members))

for name,expected in EXPECTED.items():
    raw=(FILES/name).read_bytes()
    assert h(raw)==expected,name
    print('FROZEN FILE PASS',name,'sha256='+h(raw))
with ZipFile(FILES/'REMESSA_A_E3_ORIGINAL.zip') as outer:
    raw=outer.read('01_E3_BASE_COMUM.zip')
    assert h(raw)=='aa65457eb4ff6035976d4181e9627ea3f7d287b465fad2a4b1c082d21f5b96a8'
    scan((FILES/'REMESSA_A_E3_ORIGINAL.zip').read_bytes(),'outer individual E3',True)
    scan(raw,'common E3',True)
with ZipFile(BytesIO(raw)) as inner:
    nested=[('01_CANDIDATA/tiago-tools-1.0.2.zip','tiago-tools-1.0.2.zip'),('02_BASELINE/tiago-tools-1.0.1.zip','tiago-tools-1.0.1.zip'),('02_BASELINE/tiago-tools-1.0.0_HISTORICO.zip','tiago-tools-1.0.0_HISTORICO.zip')]
    for path,name in nested:
        blob=inner.read(path)
        assert blob==(FILES/name).read_bytes(),path
        scan(blob,name)
        if name=='tiago-tools-1.0.2.zip':
            with ZipFile(BytesIO(blob)) as candidate:
                expected=candidate.read('SHA256SUMS.txt').decode().splitlines()
                matched=0
                for line in expected:
                    digest,file=line.split('  ',1)
                    assert h(candidate.read(file))==digest,file
                    matched+=1
                print('CANDIDATE SHA256SUMS VERIFIED',matched)
                assert matched==4
print('SUCCESS ALL CHAIN-OF-CUSTODY CHECKS')
