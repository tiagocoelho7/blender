#!/usr/bin/env python3
"""Auditor A E3, isolated offline harness; no Blender, no production IO.
Runs only inspected 1.0.2 addon source in memory with bpy mocks.
"""
from __future__ import annotations
import ast
import difflib
import hashlib
import io
import os
from pathlib import Path
import sys
import tomllib
import types
import unittest
from contextlib import redirect_stdout
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
SRC = HERE / 'sources' / 'tiago-tools-1.0.2'
OLD = HERE / 'sources' / 'tiago-tools-1.0.1'
BUNDLE = HERE / 'received'
SETTERS = ('show_viewport','show_render','levels','render_levels','show_in_editmode','show_on_cage')

def sha(data): return hashlib.sha256(data).hexdigest()

class MockModifier:
    def __init__(self, name, kind='SUBSURF', fail_setter=None, fail_after_write=False, show_viewport=True):
        object.__setattr__(self, 'name', name)
        object.__setattr__(self, 'type', kind)
        object.__setattr__(self, '_fail_setter', fail_setter)
        object.__setattr__(self, '_fail_after_write', fail_after_write)
        for key, val in {'show_viewport':show_viewport,'show_render':True,'levels':2,
                         'render_levels':2,'show_in_editmode':True,'show_on_cage':True}.items():
            object.__setattr__(self,key,val)
    def __setattr__(self, key, value):
        if key == self._fail_setter and not self._fail_after_write:
            raise RuntimeError(f'setter {key} BEFORE_WRITE')
        object.__setattr__(self,key,value)
        if key == self._fail_setter and self._fail_after_write:
            raise RuntimeError(f'setter {key} AFTER_WRITE')

class MockMods:
    def __init__(self, old=None, fail_setter=None, fail_after_write=False,
                 new_failure=None, remove_failure=None):
        self.items=list(old or [])
        self.fail_setter=fail_setter
        self.fail_after_write=fail_after_write
        self.new_failure=new_failure
        self.remove_failure=remove_failure
        self.created=[]
        self.removed=[]
        self.calls=[]
    def __iter__(self): return iter(self.items)
    def new(self, *, name, type):
        self.calls.append(('new',name,type))
        if self.new_failure == 'BEFORE_APPEND':
            raise RuntimeError('new failed before creating')
        x=MockModifier(name,type,self.fail_setter,self.fail_after_write)
        self.items.append(x);self.created.append(x)
        if self.new_failure == 'AFTER_APPEND':
            raise RuntimeError('new failed after appending without returning handle')
        return x
    def remove(self, modifier):
        self.calls.append(('remove',modifier))
        if self.remove_failure == 'BEFORE_REMOVE':
            raise RuntimeError('remove rejected request')
        if modifier not in self.items:raise RuntimeError('modifier is not in this object')
        self.items.remove(modifier)
        self.removed.append(modifier)
        if self.remove_failure == 'AFTER_REMOVE':
            raise RuntimeError('remove failed after side effect')

class Obj:
    def __init__(self,name='MESH', kind='MESH', modifiers=None, hidden=False):
        self.name=name
        self.type=kind
        self.modifiers=modifiers or MockMods()
        self.hidden=hidden

class FailingObj:
    name = 'broken'
    @property
    def modifiers(self):raise RuntimeError('no modifiers')

class Registry:
    def __init__(self, failure_register=None, side_effect_register=False, unregister_errors=None):
        self.classes=[]
        self.failure_register=failure_register
        self.side_effect_register=side_effect_register
        self.unregister_errors=dict(unregister_errors or {})
        self.register_calls=[]
        self.unregister_calls=[]
    def register_class(self,cls):
        idx={'TIAGO_OT_disable_modifiers':0,'TIAGO_OT_safe_add_subdivision':1,'VIEW3D_PT_tiago_tools':2}[cls.__name__]
        self.register_calls.append(cls.__name__)
        if self.failure_register == idx and not self.side_effect_register:
            raise RuntimeError(f'register failed {idx} BEFORE')
        if cls in self.classes:raise RuntimeError('duplicate')
        self.classes.append(cls)
        if self.failure_register == idx and self.side_effect_register:
            raise RuntimeError(f'register failed {idx} AFTER')
    def unregister_class(self,cls):
        idx={'TIAGO_OT_disable_modifiers':0,'TIAGO_OT_safe_add_subdivision':1,'VIEW3D_PT_tiago_tools':2}[cls.__name__]
        self.unregister_calls.append(cls.__name__)
        n=self.unregister_errors.get(idx,0)
        if n>0:
            self.unregister_errors[idx]=n-1
            raise RuntimeError(f'unregister failed {idx} BEFORE')
        if cls not in self.classes:raise RuntimeError('missing')
        self.classes.remove(cls)

class MockOp:
    def report(self,level,message):
        if not hasattr(self,'reported'):self.reported=[]
        self.reported.append((level,message))
class MockPanel:pass

class BpyModules:
    """Transient fake bpy modules. Save and restore sys.modules on exit."""
    def __init__(self,registry):self.registry=registry
    def __enter__(self):
        self.saved={key:sys.modules.get(key) for key in ('bpy','bpy.props','bpy.types')}
        bpy=types.ModuleType('bpy');props=types.ModuleType('bpy.props');btype=types.ModuleType('bpy.types')
        props.EnumProperty=lambda **kw:kw
        btype.Operator=MockOp; btype.Panel=MockPanel
        bpy.props=props;bpy.types=btype;bpy.utils=self.registry
        sys.modules.update({'bpy':bpy,'bpy.props':props,'bpy.types':btype})
        return bpy
    def __exit__(self,*args):
        for key,val in self.saved.items():
            if val is None:sys.modules.pop(key,None)
            else:sys.modules[key]=val

def load_addon(path=SRC/'__init__.py',registry=None):
    registry=registry or Registry()
    with BpyModules(registry):
        namespace={'__name__':'tiago_tools_e3_a_mock','__file__':'<INSPECTED_SOURCE_IN_MEMORY>'}
        # Only the addon source is executed: no author test script or Blender runtime.
        exec(compile(path.read_bytes(),str(path),'exec'),namespace)
    return namespace,registry

def op_run(namespace,mods=None,active_type='MESH',active=True):
    mods=mods or MockMods()
    ob=Obj('Cube',active_type,mods) if active else None
    op=namespace['TIAGO_OT_safe_add_subdivision']()
    status=op.execute(types.SimpleNamespace(active_object=ob))
    return status,op,mods

class TestStatic(unittest.TestCase):
    def test_source_compiles_without_bytecode_writes(self):
        compile((SRC/'__init__.py').read_bytes(),'<audited source>','exec')
    def test_toml_parses_and_metadata(self):
        m=tomllib.loads((SRC/'blender_manifest.toml').read_text())
        self.assertEqual(m['schema_version'],'1.0.0')
        self.assertEqual(m['version'],'1.0.2')
        self.assertEqual(m['id'],'tiago_tools')
        self.assertEqual(m['blender_version_min'],'5.0.0')
        self.assertEqual(m['type'],'add-on')
        self.assertEqual(m['license'],['SPDX:GPL-3.0-or-later'])
    def test_bl_info(self):
        n,_=load_addon()
        self.assertEqual(n['bl_info']['version'],(1,0,2))
        self.assertEqual(n['bl_info']['blender'],(5,0,0))
    def test_sha256sums(self):
        manifest=(SRC/'SHA256SUMS.txt').read_text().splitlines()
        self.assertEqual(len(manifest),4)
        for line in manifest:
            expected,name=line.split('  ',1)
            self.assertEqual(sha((SRC/name).read_bytes()),expected)
    def test_unchanged_batch_helper_panel_and_classes(self):
        new_tree=ast.parse((SRC/'__init__.py').read_text())
        old_tree=ast.parse((OLD/'__init__.py').read_text())
        names=('_collect_objects_from_visible_collections','TIAGO_OT_disable_modifiers','VIEW3D_PT_tiago_tools')
        for name in names:
            before=next(n for n in old_tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name)
            after=next(n for n in new_tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name)
            self.assertEqual(ast.dump(before,include_attributes=False),ast.dump(after,include_attributes=False),name)
        def classes(tree):
            n=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CLASSES' for t in n.targets))
            return ast.dump(n,include_attributes=False)
        self.assertEqual(classes(old_tree),classes(new_tree))
    def test_operator_identifiers_and_no_color_operator(self):
        n,_=load_addon()
        self.assertEqual([x.bl_idname for x in n['CLASSES'] if hasattr(x,'bl_idname')],
                         ['tiago.disable_modifiers','tiago.safe_add_subdivision','VIEW3D_PT_tiago_tools'])
        self.assertNotIn('TIAGO_OT_randomize_colors',n)
        self.assertNotIn('random', [i.names[0].name for i in ast.walk(ast.parse((SRC/'__init__.py').read_text())) if isinstance(i,ast.Import)])
    def test_diff_replayed_for_all_five_files(self):
        files=['__init__.py','blender_manifest.toml','README.txt','CHANGELOG.txt','SHA256SUMS.txt']
        patches=['__init___py.patch','blender_manifest_toml.patch','README_txt.patch','CHANGELOG_txt.patch','SHA256SUMS_txt.patch']
        for filename,patch in zip(files,patches):
            a=(OLD/filename).read_text().splitlines(keepends=True)
            b=(SRC/filename).read_text().splitlines(keepends=True)
            expected=''.join(difflib.unified_diff(a,b,fromfile='v1.0.1/'+filename,tofile='v1.0.2/'+filename))
            self.assertEqual(expected,(BUNDLE/'07_DIFF'/patch).read_text(),filename)
    def test_no_hidden_imports_writes_or_modification_apis(self):
        t=ast.parse((SRC/'__init__.py').read_text())
        imports=[n.module for n in ast.walk(t) if isinstance(n,ast.ImportFrom)]
        self.assertEqual(sorted(imports),['bpy.props','bpy.types'])
        self.assertEqual([a.name for x in ast.walk(t) if isinstance(x,ast.Import) for a in x.names],['bpy'])
        text=(SRC/'__init__.py').read_text()
        for call in ('bpy.ops','bpy.data','open(','exec(','eval(','requests','urllib','socket','subprocess','save_as_mainfile','bpy.app.handlers'):
            self.assertNotIn(call,text)

class TestSafeSub(unittest.TestCase):
    def setUp(self):self.n,_=load_addon()
    def test_poll_mesh_only(self):
        op=self.n['TIAGO_OT_safe_add_subdivision']
        self.assertTrue(op.poll(types.SimpleNamespace(active_object=Obj(kind='MESH'))))
        for kind in ('CURVE','EMPTY','FONT','ARMATURE'):
            self.assertFalse(op.poll(types.SimpleNamespace(active_object=Obj(kind=kind))))
        self.assertFalse(op.poll(types.SimpleNamespace(active_object=None)))
    def test_success_six_fields(self):
        mods=MockMods();status,op,m=op_run(self.n,mods)
        self.assertEqual(status,{'FINISHED'});self.assertEqual(len(m.items),1)
        self.assertEqual((m.items[0].type,m.calls[0][:2]),('SUBSURF',('new','Subdivision')))
        self.assertTrue(all(getattr(m.items[0],s) in (0,False) for s in SETTERS))
        self.assertEqual(op.reported[0][0],{'INFO'})
    def test_two_additions_intentional_and_existing_unchanged(self):
        prev=MockModifier('Keep')
        mods=MockMods(old=[prev]);snap=vars(prev).copy()
        for i in range(2):
            s,op,_=op_run(self.n,mods);self.assertEqual(s,{'FINISHED'})
        self.assertEqual(len(mods.items),3)
        self.assertIs(mods.items[0],prev)
        self.assertEqual(vars(prev),snap)
        self.assertNotEqual(mods.items[1],mods.items[2])
    def test_failure_on_new_before_creating(self):
        prev=MockModifier('Existing');mods=MockMods(old=[prev],new_failure='BEFORE_APPEND')
        s,op,_=op_run(self.n,mods)
        self.assertEqual(s,{'CANCELLED'});self.assertEqual(mods.items,[prev]);self.assertEqual(len(mods.removed),0)
        self.assertEqual(op.reported[0][0],{'ERROR'})
    def test_new_partial_side_effect_leak_known_gap(self):
        prev=MockModifier('Existing');mods=MockMods(old=[prev],new_failure='AFTER_APPEND')
        s,op,_=op_run(self.n,mods)
        self.assertEqual(s,{'CANCELLED'});self.assertEqual(len(mods.items),2)
        self.assertEqual(len(mods.removed),0)
        self.assertEqual(op.reported[0][0],{'ERROR'})
        # Synthetic injection, not proof Blender actually raises after append.
    def test_missing_active_object_direct_execute(self):
        s,op,_=op_run(self.n,active=False)
        self.assertEqual(s,{'CANCELLED'});self.assertEqual(op.reported[0][0],{'ERROR'})
    def test_edit_mode_not_guarded_by_code(self):
        op=self.n['TIAGO_OT_safe_add_subdivision']()
        obj=Obj();obj.mode='EDIT'
        self.assertTrue(op.poll(types.SimpleNamespace(active_object=obj)))
        self.assertEqual(op.execute(types.SimpleNamespace(active_object=obj)),{'FINISHED'})
    def test_remove_after_side_effect_gets_finished_warning(self):
        mods=MockMods(fail_setter='render_levels',remove_failure='AFTER_REMOVE')
        s,op,_=op_run(self.n,mods)
        self.assertEqual(s,{'FINISHED'});self.assertEqual(len(mods.items),0)
        self.assertEqual(op.reported[0][0],{'WARNING'})
        # Synthetic semantics; no claim that Blender does this.

# Expand parameterized cases into independent test methods with names in verbose logs.
for field in SETTERS:
    for after in (False,True):
        def create_test_setter(field=field,after=after):
            def testcase(self):
                prev=MockModifier('Existing');old=vars(prev).copy()
                mods=MockMods(old=[prev],fail_setter=field,fail_after_write=after)
                s,op,_=op_run(self.n,mods)
                self.assertEqual(s,{'CANCELLED'})
                self.assertEqual(mods.items,[prev])
                self.assertEqual(vars(prev),old)
                self.assertEqual(mods.removed,mods.created)
                self.assertEqual(op.reported[0][0],{'ERROR'})
            return testcase
        setattr(TestSafeSub,'test_setter_rollback_'+field+('_after' if after else '_before'),create_test_setter())
    for after in (False,True):
        def create_test_remove_error(field=field,after=after):
            def testcase(self):
                prev=MockModifier('Existing');old=vars(prev).copy()
                mods=MockMods(old=[prev],fail_setter=field,fail_after_write=after,remove_failure='BEFORE_REMOVE')
                with redirect_stdout(io.StringIO()) as out:
                    s,op,_=op_run(self.n,mods)
                self.assertEqual(s,{'FINISHED'})
                self.assertEqual(len(mods.items),2)
                self.assertIs(mods.items[0],prev)
                self.assertEqual(vars(prev),old)
                self.assertEqual(op.reported[0][0],{'WARNING'})
                self.assertIn('use Undo',op.reported[0][1])
                self.assertIn('erro de configuracao',out.getvalue())
                self.assertIn('erro ao remover',out.getvalue())
                self.assertEqual(mods.removed,[])
            return testcase
        setattr(TestSafeSub,'test_setter_cleanup_fails_'+field+('_after' if after else '_before'),create_test_remove_error())

class TestRegistration(unittest.TestCase):
    def test_normal_and_idempotent_double_register_unregister(self):
        n,r=load_addon()
        n['register']();self.assertEqual(r.classes,list(n['CLASSES']))
        n['register']();self.assertEqual(len(r.register_calls),3)
        n['unregister']();self.assertEqual(r.classes,[])
        n['unregister']();self.assertEqual(len(r.unregister_calls),3)
        self.assertEqual(n['_REGISTERED_CLASSES'],[])
    def test_register_order_and_reverse_unregistration(self):
        n,r=load_addon();n['register']();n['unregister']()
        self.assertEqual(r.register_calls,[c.__name__ for c in n['CLASSES']])
        self.assertEqual(r.unregister_calls,[c.__name__ for c in reversed(n['CLASSES'])])
    def test_unregister_when_nothing_registered_no_effect(self):
        n,r=load_addon();n['unregister']()
        self.assertEqual(r.unregister_calls,[])
    def test_all_register_failure_points_roll_back_without_leaks(self):
        for idx in range(3):
            with self.subTest(idx=idx):
                r=Registry(failure_register=idx);n,_=load_addon(registry=r)
                with self.assertRaisesRegex(RuntimeError,'register failed'):
                    n['register']()
                self.assertEqual(r.classes,[])
                self.assertEqual(n['_REGISTERED_CLASSES'],[])
                r.failure_register=None
                n['register']();self.assertEqual(r.classes,list(n['CLASSES']))
                n['unregister']();self.assertEqual(r.classes,[])
    def test_fail_during_rollback_preserve_tracked_handle(self):
        r=Registry(failure_register=2,unregister_errors={1:1});n,_=load_addon(registry=r)
        with redirect_stdout(io.StringIO()) as out:
            with self.assertRaises(RuntimeError):n['register']()
        self.assertEqual(r.classes,[n['CLASSES'][1]])
        self.assertEqual(n['_REGISTERED_CLASSES'],[n['CLASSES'][1]])
        self.assertIn('Erro ao reverter registro',out.getvalue())
        n['unregister']();self.assertEqual(r.classes,[])
    def test_fail_during_rollback_then_resume_registration(self):
        r=Registry(failure_register=2,unregister_errors={1:1});n,_=load_addon(registry=r)
        with redirect_stdout(io.StringIO()):
            with self.assertRaises(RuntimeError):n['register']()
        r.failure_register=None;n['register']();self.assertEqual(set(r.classes),set(n['CLASSES']))
        n['unregister']();self.assertEqual(r.classes,[])
    def test_unregister_multiple_failures_carries_every_pending(self):
        r=Registry(unregister_errors={0:1,2:1});n,_=load_addon(registry=r)
        n['register']()
        with redirect_stdout(io.StringIO()) as out:
            with self.assertRaisesRegex(RuntimeError,'classes ainda registradas'):n['unregister']()
        self.assertEqual(set(r.classes),{n['CLASSES'][0],n['CLASSES'][2]})
        self.assertEqual(set(n['_REGISTERED_CLASSES']),set(r.classes))
        self.assertEqual(len(r.unregister_calls),3)
        self.assertIn('Erro ao desregistrar',out.getvalue())
        n['unregister']();self.assertEqual(r.classes,[])
    def test_unregister_retry_each_failed_class(self):
        for idx in range(3):
            with self.subTest(idx=idx):
                r=Registry(unregister_errors={idx:1});n,_=load_addon(registry=r)
                n['register']()
                with redirect_stdout(io.StringIO()):
                    with self.assertRaisesRegex(RuntimeError,'classes ainda registradas'):n['unregister']()
                self.assertEqual(r.classes,[n['CLASSES'][idx]])
                self.assertEqual(n['_REGISTERED_CLASSES'],r.classes)
                n['unregister']();self.assertEqual(r.classes,[])
    def test_side_effect_register_error_orphans_class_known_gap(self):
        for idx in range(3):
            with self.subTest(idx=idx):
                r=Registry(failure_register=idx,side_effect_register=True);n,_=load_addon(registry=r)
                with self.assertRaisesRegex(RuntimeError,'AFTER'):n['register']()
                self.assertEqual(r.classes,[n['CLASSES'][idx]])
                self.assertEqual(n['_REGISTERED_CLASSES'],[])
                n['unregister']()  # Leaves class behind because it is untracked.
                self.assertEqual(r.classes,[n['CLASSES'][idx]])
                # Synthetic model. Blender side effects after exception NOT evidenced.
    def test_external_deregistration_stale_track_does_not_self_heal(self):
        n,r=load_addon();n['register']();r.classes.clear()
        n['register']() # Skips classes it thinks are registered.
        self.assertEqual(r.classes,[])
        with redirect_stdout(io.StringIO()):
            with self.assertRaises(RuntimeError):n['unregister']()
        self.assertEqual(len(n['_REGISTERED_CLASSES']),3)

class Scene:
    def __init__(self,objects):self.objects=objects
class CCollection:
    def __init__(self,objects):self.objects=objects
class CLayer:
    def __init__(self,visible=True,objects=(),children=()):
        self.is_visible=visible
        self.collection=CCollection(objects)
        self.children=list(children)

class TestBatch(unittest.TestCase):
    def setUp(self):self.n,_=load_addon()
    def run_batch(self,scope,scene,root,active_view_layer=True):
        op=self.n['TIAGO_OT_disable_modifiers']();op.scope=scope
        ctx=types.SimpleNamespace(scene=scene,view_layer=(types.SimpleNamespace(layer_collection=root) if active_view_layer else None))
        with redirect_stdout(io.StringIO()) as out:
            status=op.execute(ctx)
        return status,op,out.getvalue()
    def test_all_includes_hidden(self):
        a=Obj('A',modifiers=MockMods(old=[MockModifier('A')]));b=Obj('B',modifiers=MockMods(old=[MockModifier('B')]))
        s,op,_=self.run_batch('ALL',Scene([a,b]),CLayer(objects=[a],children=[CLayer(False,objects=[b])]))
        self.assertEqual(s,{'FINISHED'});self.assertFalse(a.modifiers.items[0].show_viewport)
        self.assertFalse(b.modifiers.items[0].show_viewport)
        self.assertTrue(a.modifiers.items[0].show_render);self.assertTrue(b.modifiers.items[0].show_render)
    def test_visible_only_per_collection_not_hidden_object(self):
        a=Obj('A',modifiers=MockMods(old=[MockModifier('A')]));b=Obj('B',modifiers=MockMods(old=[MockModifier('B')]));c=Obj('HiddenObj',hidden=True,modifiers=MockMods(old=[MockModifier('C')]))
        root=CLayer(objects=[],children=[CLayer(True,[a,c]),CLayer(False,[b])]);s,op,_=self.run_batch('VISIBLE_COLLECTIONS',Scene([a,b,c]),root)
        self.assertEqual(s,{'FINISHED'});self.assertFalse(a.modifiers.items[0].show_viewport)
        self.assertTrue(b.modifiers.items[0].show_viewport)
        self.assertFalse(c.modifiers.items[0].show_viewport)
        self.assertTrue(c.modifiers.items[0].show_render)
    def test_parent_hidden_prunes_descendants(self):
        a=Obj('A',modifiers=MockMods(old=[MockModifier('A')]))
        root=CLayer(True,children=[CLayer(False,children=[CLayer(True,[a])])])
        s,op,_=self.run_batch('VISIBLE_COLLECTIONS',Scene([a]),root)
        self.assertEqual(s,{'FINISHED'});self.assertTrue(a.modifiers.items[0].show_viewport)
    def test_multiple_links_unique_processing(self):
        a=Obj('A',modifiers=MockMods(old=[MockModifier('A')]))
        root=CLayer(True,children=[CLayer(True,[a]),CLayer(True,[a])])
        s,op,txt=self.run_batch('VISIBLE_COLLECTIONS',Scene([a]),root)
        self.assertEqual(s,{'FINISHED'});self.assertIn('Objetos encontrados: 1',txt)
    def test_read_fail_one_object_best_effort(self):
        a=FailingObj();b=Obj('Good',modifiers=MockMods(old=[MockModifier('B')]))
        s,op,txt=self.run_batch('ALL',Scene([a,b]),CLayer(True,[a,b]))
        self.assertEqual(s,{'FINISHED'});self.assertFalse(b.modifiers.items[0].show_viewport)
        self.assertEqual(op.reported[0][0],{'WARNING'});self.assertIn('Erros: 1',txt)
    def test_already_disabled_idempotent(self):
        a=Obj('A',modifiers=MockMods(old=[MockModifier('A',show_viewport=False)]))
        s,op,txt=self.run_batch('ALL',Scene([a]),CLayer(True,[a]))
        self.assertEqual(s,{'FINISHED'});self.assertIn('Ja desativados: 1',txt)
    def test_empty_scene(self):
        s,op,txt=self.run_batch('ALL',Scene([]),CLayer(True))
        self.assertEqual(s,{'FINISHED'});self.assertIn('Objetos encontrados: 0',txt)
    def test_missing_scene_or_view_layer_cancelled(self):
        for scene,ok in [(None,True),(Scene([]),False)]:
            s,op,_=self.run_batch('ALL',scene,CLayer(True),active_view_layer=ok)
            self.assertEqual(s,{'CANCELLED'})
            self.assertEqual(op.reported[0][0],{'ERROR'})

class FakeUI:
    def __init__(self, calls=None):self.calls=calls if calls is not None else []
    def box(self):return self
    def label(self,*,text,icon):self.calls.append(('label',text,icon))
    def row(self,**kwargs):return self
    def operator(self,identifier,**kwargs):
        o=types.SimpleNamespace();self.calls.append(('operator',identifier,kwargs,o));return o

class TestPanel(unittest.TestCase):
    def test_ui_two_batch_buttons_one_sub_no_colors(self):
        n,_=load_addon();panel=n['VIEW3D_PT_tiago_tools']();panel.layout=FakeUI()
        panel.draw(types.SimpleNamespace())
        ops=[entry for entry in panel.layout.calls if entry[0]=='operator']
        self.assertEqual([o[1] for o in ops],['tiago.disable_modifiers','tiago.disable_modifiers','tiago.safe_add_subdivision'])
        self.assertEqual([o[3].scope for o in ops[:2]],['ALL','VISIBLE_COLLECTIONS'])
        self.assertFalse(any('color' in o[1] for o in ops))

if __name__=='__main__':
    print('AUDITOR A E3 | independent isolated offline harness | Python',sys.version.split()[0], '| cwd',os.getcwd(),flush=True)
    suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result=unittest.TextTestRunner(stream=sys.stdout,verbosity=2).run(suite)
    print('SUMMARY:',f'run={result.testsRun} failures={len(result.failures)} errors={len(result.errors)} skipped={len(result.skipped)}')
    sys.exit(0 if result.wasSuccessful() else 1)
