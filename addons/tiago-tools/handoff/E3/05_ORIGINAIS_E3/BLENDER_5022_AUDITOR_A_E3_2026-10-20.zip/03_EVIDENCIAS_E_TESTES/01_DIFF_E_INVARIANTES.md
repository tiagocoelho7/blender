# Evidências: diffs e invariantes

Fonte: três ZIPs originais, conferidos no manifesto; comparação feita no harness independente com `difflib.unified_diff` exato contra os patches fornecidos, cinco arquivos.

## Cinco diffs conferidos (PASS)

1. `__init__.py`: versão bl_info `1.0.1`→`1.0.2`, `modifier = None`, remoção direcionada no rollback, fallback `FINISHED`+`WARNING`, rastreamento de registro, exceções no cleanup e unregister.
2. `blender_manifest.toml`: schema_version **`1.0.1`→`1.0.0`**, versão `1.0.1`→`1.0.2`, preserva `id`.
3. `README.txt`: documentação de status, fluxo de upgrade, limites de testes/undo.
4. `CHANGELOG.txt`: histórico e correções 1.0.2.
5. `SHA256SUMS.txt`: 4 hashes da candidata recalculados e corretos.

**AST igual 1.0.1 vs 1.0.2:** `_collect_objects_from_visible_collections`, `TIAGO_OT_disable_modifiers`, `VIEW3D_PT_tiago_tools` e `CLASSES`. Os testes capturam a equivalência estrutural da implementação para estes nós, não equivalência runtime Blender entre versões.

## Histórico 1.0.0

v1.0.0 continha `TIAGO_OT_random_colors` e 4 classes; v1.0.1 retirou Random Colors e contém 3 classes; v1.0.2 conserva apenas as 3. Mudança de cor não pertence ao delta E3.

## Índices de linha relevantes da v1.0.2

- `_collect_objects_from_visible_collections`: 23–32.
- `TIAGO_OT_disable_modifiers`: 40–129.
- `TIAGO_OT_safe_add_subdivision`: 137–197; `poll` 146–149; `new` 158; seis setters 159–164; exceções/rollback 165–191.
- `VIEW3D_PT_tiago_tools`: 205–237.
- `CLASSES`: 239–243.
- Rastreamento/registro: 246–293.
- `blender_manifest.toml`: linhas 1–12.

**Limite:** diff/AST não testa validade de registro no RNA, desempenho, depsgraph, rollback efetivo de `bpy.ops`, UI e instalação real.
