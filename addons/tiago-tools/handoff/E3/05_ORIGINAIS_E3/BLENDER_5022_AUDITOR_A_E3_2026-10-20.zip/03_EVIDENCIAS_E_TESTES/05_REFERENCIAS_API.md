# Referências Blender 5.0 / 5.2 LTS (documentação externa)

Consulta documental em 20/10/2026, **não confundir com validação dentro do Blender**. Textos indexados de referências oficiais foram conferidos; tentativas de abrir diretamente algumas páginas retornaram erro do mecanismo web, por isso não afirmamos ter executado validadores ou lido a totalidade dessas páginas.

1. **Blender 5.0 — extensões/manifesto:** https://docs.blender.org/manual/id/5.0/advanced/extensions/getting_started.html — schema_version `1.0.0` como versão de esquema; version independente; `blender_version_min` obrigatório.
2. **Blender 5.2 LTS — extensões/manifesto:** https://docs.blender.org/manual/ca/5.2/advanced/extensions/getting_started.html — mesmo exemplo e semântica básica. Compatibilidade de instalação pendente de validação pelo comando nativo.
3. **CLI 5.0/5.2:** https://docs.blender.org/manual/nl/5.0/advanced/command_line/extension_arguments.html e https://docs.blender.org/manual/sl/5.2/advanced/command_line/extension_arguments.html — `blender --command extension validate <ZIP>` valida metadados do pacote.
4. **Blender 5.0 ObjectModifiers:** https://docs.blender.org/api/5.0/bpy.types.ObjectModifiers.html — `new(name, type)` e `remove(modifier)`; modelo de objeto API, não garantia de rollback atômico.
5. **Blender 5.0 Modifier:** https://docs.blender.org/api/5.0/bpy.types.Modifier.html — flags `show_viewport`, `show_render`, `show_in_editmode`, `show_on_cage`.
6. **Blender 5.2 Modifier:** https://docs.blender.org/api/5.2/bpy.types.Modifier.html — mesmas quatro flags presentes.
7. **Blender 5.0 SubsurfModifier:** https://docs.blender.org/api/5.0/bpy.types.SubsurfModifier.html — `levels` e `render_levels` admitem `0`.
8. **Blender 5.2 Operator/Undo:** https://docs.blender.org/api/5.2/bpy.types.Operator.html — `{'FINISHED'}` com `'UNDO'` produz etapa de Undo na execução normal; `{'CANCELLED'}` não cria etapa. Limites de contexto/integração não testados.
9. **Blender 5.2 utils:** https://docs.blender.org/api/5.2/bpy.utils.html — `register_class`/`unregister_class`, ordem apropriada e callbacks de registro.
10. **Blender 5.2 visão geral de registro:** https://docs.blender.org/api/5.2/info_overview.html — `register`/`unregister` e ordem inversa.
11. **Blender 5.2 LayerCollection:** https://docs.blender.org/api/5.2/bpy.types.LayerCollection.html — `is_visible`, `collection`, `children`; página exata não foi recuperada integralmente pelo navegador, inferência apoiada por API similar 5.4 e pelo baseline funcional declarado, exigindo confirmação E4.

**Não foi encontrada evidência documental de quebra de API no conjunto efetivamente utilizado**, mas a consulta parcial e o mock não certificam funcionamento em Blender 5.2.2 exato.
