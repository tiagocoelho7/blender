# E4 — Roteiro de testes reais Blender 5.0.0 e 5.2.2 LTS (NÃO EXECUTADO)

**Executar somente com autorização do proprietário e perfis temporários isolados.** Não abrir, converter ou salvar `.blend` de produção. Manter os ZIPs congelados intactos; operar apenas em cópias para instalação/teste. Não usar o Work sem autorização.

## Preparação em Windows

- Registrar versão exata Blender 5.0.0 e 5.2.2 LTS, caminho de cada executável, build e Python embutido (`bpy.app.version_string`, `bpy.app.build_hash`, `sys.version`), Windows e SHA256 dos ZIPs.
- Usar perfis separados por versão com `BLENDER_USER_CONFIG`, `BLENDER_USER_SCRIPTS` apontando para diretórios temporários de teste; antes de instalar, salvar log da configuração. Confirmar via documentação/versão como separar `extensions` e caches se necessário. Não interferir na extensão `Tiago Global Scripts`.
- Validar em **cada** executável, com caminho completo do ZIP congelado copiado para fixtures:

```powershell
& 'CAMINHO_DO_BLENDER_5_0_0\blender.exe' --command extension validate 'CAMINHO_FIXTURE\tiago-tools-1.0.2.zip'
& 'CAMINHO_DO_BLENDER_5_2_2\blender.exe' --command extension validate 'CAMINHO_FIXTURE\tiago-tools-1.0.2.zip'
```

Salvar stdout/stderr, exit code e version; o validador é documental/metadata, não prova funcionamento.

## Matriz prática (repetir em ambas versões)

1. **Instalação/ciclo RNA:** instalar extensão v1.0.2 em perfil temporário, habilitar/desabilitar/rehabilitar 2x, fechar/reabrir Blender, verificar ausência de erros e classes/operadores órfãos. Em **outro perfil temporário** simular upgrade 1.0.1→1.0.2, garantindo que não há painel duplicado.
2. **UI:** abrir `3D Viewport > N > Tiago`: exatamente botões Todos, Visíveis e Safe Sub; nada de operador Random Colors. Testar `poll` mesh ativa, seleção vazia e objeto não-mesh.
3. **Batch Todos:** cena pequena descartável com coleções habilitadas/ocultas, objetos com um e vários modifiers, modifiers já desativados; garantir `show_viewport=False`, sem alterações de `show_render`, objetos nem coleções. Capturar contagens, log e Undo.
4. **Batch Visíveis:** collection visível, invisível, pai invisível e objeto individualmente oculto em collection visível; este último deve ser incluído segundo o contrato antigo. Link de mesmo objeto a duas collections visíveis: processar só uma vez.
5. **Safe Sub feliz:** mesh simples descartável e um modifier pré-existente; clicar uma vez, registrar seis propriedades/levels 0; clicar outra vez, verificar que adiciona segundo SUBSURF, não altera o antigo; testar Undo via `bpy.ops`/interface e retorno.
6. **Erros reais:** objeto linked/library override em fixture própria, modo Edit e contexto sem VIEW_3D; anotar se a API rejeita `new` antes de mutar, efeitos parciais e mensagens. **Não** manipular arquivos reais nem simular falhas com monkeypatch de C/RNA em produção.
7. **Undo após fallback:** se houver ocorrência espontânea/reprodutível de falha de setter+remoção, registrar estado antes/depois/Undo. Não afirmar que o mock prova Undo. Caso não seja possível provocar a dupla falha de modo seguro, marcar `NÃO PROVOCADO / LACUNA`.
8. **Desempenho:** primeiro fixture mesh mínima, depois fixture incremental também descartável. Monitorar memória/tempo e viewport quando `modifiers.new` ocorre antes de desativar `show_viewport`. Não começar com estatuária pesada.
9. **Persistência e versões:** salvar/reabrir só fixtures; não usar arquivo editado em 5.2.2 para presumir retrocompatibilidade 5.0.0. Guardar hash de entradas, saída e screenshots.
10. **Evidência:** logs completos, capturas das duas versões, ambiente, classificação PASS/FAIL/BLOCKED, comparação objetiva, parecer do Master e autorização do proprietário antes de qualquer GO produção.

## Critérios de HOLD em E4

- Falha de instalação/registro em qualquer versão alvo, classes/painéis órfãos, incompatibilidade RNA efetiva;
- Novo SUBSURF com viewport/render ligados após retorno normal sem aviso apropriado;
- `CANCELLED` após alteração residual real sem etapa de Undo, falha observável de undo ou alteração de modifiers anteriores;
- Mudança de flags não autorizadas por batch, processamento de collections ocultas em modo Visíveis, UI diferente do contrato;
- Queda/risco indevido, pico de memória inaceitável mesmo em fixtures pequenas.
