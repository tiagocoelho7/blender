# Ambiente e comandos da execução independente E3

- OS: Linux x86_64.
- Python (harness): CPython 3.13.5 (não Blender Python).
- Blender executável: `command -v blender` → nada retornado (não presente no PATH). Nenhuma execução Blender real.
- Original: `/mnt/data/TIAGO_TOOLS_V1_0_2_AUDITOR_A_E3_2026-10-20(2).zip` — leitura somente.
- Fonte v1.0.2: extraída **para cópia descartável** e carregada via `exec(compile(...))` em dicionário com `bpy`, `bpy.props`, `bpy.types` integralmente simulados. Operações apenas em objetos mock.

```sh
python --version
command -v blender
uname -sm
python -B /mnt/data/tiago_e3_a_20261020/harness_a_independente.py > /mnt/data/tiago_e3_a_20261020/testes_a_independente.log 2>&1
```

- `-B` impede escrita de `.pyc` do harness.
- Testes de SHA com `hashlib.sha256`; ZIP com Python `zipfile`; manifesto com `tomllib`; AST com `ast`; comparação exata dos patches com `difflib`.
- Não usados: install real, ZIP da candidata como ferramenta executada do sistema, scripts do autor, subprocessos externos do addon, uso de terminal/GUI de produção.

Para reprodução portátil do bundle completo, use `08_REPRODUZIR_E3.py` (cópias temporárias, extrai três ZIPs em nova pasta e executa harness).
