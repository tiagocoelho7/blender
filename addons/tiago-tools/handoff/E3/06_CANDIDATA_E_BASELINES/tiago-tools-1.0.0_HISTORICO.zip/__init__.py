# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "Tiago Tools",
    "author": "Tiago Coelho",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Tiago",
    "description": "Ferramentas pessoais para modifiers, subdivision e cores aleatorias",
    "category": "Object",
}

import random

import bpy
from bpy.props import EnumProperty
from bpy.types import Operator, Panel


# -----------------------------------------------------------------------------
# Utilitarios
# -----------------------------------------------------------------------------


def _collect_objects_from_visible_collections(layer_collection, result):
    """Coleta objetos ligados a collections efetivamente visiveis no View Layer."""
    if not layer_collection.is_visible:
        return

    for obj in layer_collection.collection.objects:
        result.add(obj)

    for child in layer_collection.children:
        _collect_objects_from_visible_collections(child, result)


def _ensure_principled_material(material):
    """Garante um Principled BSDF conectado a um Material Output."""
    material.use_nodes = True
    node_tree = material.node_tree
    nodes = node_tree.nodes
    links = node_tree.links

    principled = next((node for node in nodes if node.type == 'BSDF_PRINCIPLED'), None)
    output = next((node for node in nodes if node.type == 'OUTPUT_MATERIAL'), None)

    if principled is None:
        principled = nodes.new("ShaderNodeBsdfPrincipled")

    if output is None:
        output = nodes.new("ShaderNodeOutputMaterial")

    surface = output.inputs.get("Surface")
    bsdf_output = principled.outputs.get("BSDF")

    if surface is not None and bsdf_output is not None:
        if not any(link.to_socket == surface for link in surface.links):
            links.new(bsdf_output, surface)

    return principled


def _get_or_create_random_material(obj):
    """Reutiliza o material do Tiago Tools para evitar criar lixo a cada execucao."""
    if len(obj.material_slots) == 0:
        # Cria apenas o slot. O material sera ligado ao OBJETO, e nao ao Mesh.
        obj.data.materials.append(None)

    slot = obj.material_slots[0]
    slot.link = 'OBJECT'

    material = slot.material
    if material is None or not bool(material.get("tiago_tools_random_color", False)):
        material = bpy.data.materials.new(name=f"TT_COR_{obj.name[:48]}")
        material["tiago_tools_random_color"] = True
        slot.material = material

    return material


# -----------------------------------------------------------------------------
# 1) Desativar Modifiers
# -----------------------------------------------------------------------------


class TIAGO_OT_disable_modifiers(Operator):
    bl_idname = "tiago.disable_modifiers"
    bl_label = "Desativar Modifiers"
    bl_description = "Desativa modifiers no viewport sem alterar o estado das collections"
    bl_options = {'REGISTER', 'UNDO'}

    scope: EnumProperty(
        name="Escopo",
        items=(
            ('ALL', "Todos", "Todos os objetos da Scene, inclusive collections ocultas/desativadas"),
            ('VISIBLE_COLLECTIONS', "Collections visiveis", "Somente objetos ligados a collections visiveis no View Layer atual"),
        ),
        default='ALL',
    )

    def execute(self, context):
        scene = context.scene
        view_layer = context.view_layer

        if scene is None or view_layer is None:
            self.report({'ERROR'}, "Nenhuma Scene/View Layer ativa")
            return {'CANCELLED'}

        if self.scope == 'ALL':
            objects = list(scene.objects)
            mode_label = "todos os objetos"
        else:
            object_set = set()
            _collect_objects_from_visible_collections(view_layer.layer_collection, object_set)
            objects = list(object_set)
            mode_label = "collections visiveis"

        objects_with_modifiers = 0
        modifiers_found = 0
        changed = 0
        already_disabled = 0
        errors = 0

        for obj in objects:
            try:
                modifiers = list(obj.modifiers)
            except Exception as exc:
                errors += 1
                print(f'[Tiago Tools] ERRO ao ler modifiers de "{obj.name}": {exc}')
                continue

            if not modifiers:
                continue

            objects_with_modifiers += 1

            for modifier in modifiers:
                modifiers_found += 1
                try:
                    if modifier.show_viewport:
                        modifier.show_viewport = False
                        changed += 1
                    else:
                        already_disabled += 1
                except Exception as exc:
                    errors += 1
                    print(
                        f'[Tiago Tools] ERRO em "{obj.name}" > '
                        f'"{modifier.name}": {exc}'
                    )

        message = (
            f"{changed} desativado(s); {already_disabled} ja estavam desativados "
            f"({mode_label})"
        )
        if errors:
            message += f"; {errors} erro(s) - veja o Console"
            self.report({'WARNING'}, message)
        else:
            self.report({'INFO'}, message)

        print()
        print("=" * 60)
        print("TIAGO TOOLS - MODIFIERS DESATIVADOS")
        print("=" * 60)
        print(f"Modo: {mode_label}")
        print(f"Objetos encontrados: {len(objects)}")
        print(f"Objetos com modifiers: {objects_with_modifiers}")
        print(f"Modifiers encontrados: {modifiers_found}")
        print(f"Desativados agora: {changed}")
        print(f"Ja desativados: {already_disabled}")
        print(f"Erros: {errors}")
        print("=" * 60)

        return {'FINISHED'}


# -----------------------------------------------------------------------------
# 2) Safe Sub
# -----------------------------------------------------------------------------


class TIAGO_OT_safe_add_subdivision(Operator):
    bl_idname = "tiago.safe_add_subdivision"
    bl_label = "Adicionar Subdivision desativado"
    bl_description = (
        "Adiciona Subdivision Surface com viewport e render desligados "
        "e niveis 0 para reduzir o risco de avaliacao pesada"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        obj = context.active_object

        try:
            # A API cria o modifier primeiro; desligamos imediatamente, antes de
            # devolver o controle ao Blender/viewport.
            modifier = obj.modifiers.new(name="Subdivision", type='SUBSURF')
            modifier.show_viewport = False
            modifier.show_render = False
            modifier.levels = 0
            modifier.render_levels = 0
            modifier.show_in_editmode = False
            modifier.show_on_cage = False
        except Exception as exc:
            self.report({'ERROR'}, f"Nao foi possivel adicionar Subdivision: {exc}")
            return {'CANCELLED'}

        self.report(
            {'INFO'},
            f'Subdivision desativado adicionado a "{obj.name}"'
        )
        return {'FINISHED'}


# -----------------------------------------------------------------------------
# 3) Pintar cores aleatorias
# -----------------------------------------------------------------------------


class TIAGO_OT_random_colors(Operator):
    bl_idname = "tiago.random_colors"
    bl_label = "Pintar cores aleatorias"
    bl_description = (
        "Da uma cor aleatoria a cada objeto MESH da Scene usando material "
        "ligado ao objeto; materiais anteriores nao sao apagados"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if scene is None:
            self.report({'ERROR'}, "Nenhuma Scene ativa")
            return {'CANCELLED'}

        meshes = [obj for obj in scene.objects if obj.type == 'MESH' and obj.data is not None]
        changed = 0
        errors = 0

        # Uma Mesh compartilhada precisa ter todos os poligonos no slot 0 para
        # que cada objeto possa usar sua propria cor via MaterialSlot.link=OBJECT.
        prepared_meshes = set()

        for obj in meshes:
            try:
                mesh_ptr = obj.data.as_pointer()
                if mesh_ptr not in prepared_meshes:
                    for polygon in obj.data.polygons:
                        polygon.material_index = 0
                    prepared_meshes.add(mesh_ptr)

                material = _get_or_create_random_material(obj)
                principled = _ensure_principled_material(material)

                color = (
                    random.random(),
                    random.random(),
                    random.random(),
                    1.0,
                )

                base_color = principled.inputs.get("Base Color")
                roughness = principled.inputs.get("Roughness")

                if base_color is None:
                    raise RuntimeError('Entrada "Base Color" nao encontrada no Principled BSDF')

                base_color.default_value = color
                if roughness is not None:
                    roughness.default_value = 0.5

                # Ajuda tambem em modos de viewport que usam a cor do material.
                material.diffuse_color = color
                changed += 1

            except Exception as exc:
                errors += 1
                print(f'[Tiago Tools] ERRO ao pintar "{obj.name}": {exc}')

        if errors:
            self.report(
                {'WARNING'},
                f"{changed} mesh(es) pintadas; {errors} erro(s) - veja o Console"
            )
        else:
            self.report({'INFO'}, f"{changed} mesh(es) receberam cores aleatorias")

        return {'FINISHED'}


# -----------------------------------------------------------------------------
# Painel
# -----------------------------------------------------------------------------


class VIEW3D_PT_tiago_tools(Panel):
    bl_label = "Tiago Tools"
    bl_idname = "VIEW3D_PT_tiago_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tiago"

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Modifiers", icon='MODIFIER')

        row = box.row(align=True)
        op = row.operator(
            TIAGO_OT_disable_modifiers.bl_idname,
            text="Todos",
        )
        op.scope = 'ALL'

        op = row.operator(
            TIAGO_OT_disable_modifiers.bl_idname,
            text="Visiveis",
        )
        op.scope = 'VISIBLE_COLLECTIONS'

        box = layout.box()
        box.label(text="Subdivision", icon='MOD_SUBSURF')
        box.operator(
            TIAGO_OT_safe_add_subdivision.bl_idname,
            text="Adicionar desativado",
            icon='MOD_SUBSURF',
        )

        box = layout.box()
        box.label(text="Cores", icon='MATERIAL')
        box.operator(
            TIAGO_OT_random_colors.bl_idname,
            text="Pintar cores aleatorias",
            icon='MATERIAL',
        )
        box.label(text="Nao apaga materiais anteriores", icon='INFO')


CLASSES = (
    TIAGO_OT_disable_modifiers,
    TIAGO_OT_safe_add_subdivision,
    TIAGO_OT_random_colors,
    VIEW3D_PT_tiago_tools,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
