TIAGO TOOLS 1.0.0
=================

Blender minimo: 5.0.0

Ferramentas:
1. Desativar Modifiers
   - Todos: Scene inteira, inclusive collections ocultas/desativadas.
   - Visiveis: somente collections efetivamente visiveis no View Layer atual.
   - Nao altera visibilidade nem estado das collections.

2. Safe Sub
   - Adiciona Subdivision Surface ao objeto MESH ativo.
   - show_viewport = False
   - show_render = False
   - levels = 0
   - render_levels = 0

3. Pintar cores aleatorias
   - Processa todos os objetos MESH da Scene.
   - Cada objeto recebe uma cor/material proprio.
   - Usa material ligado ao objeto para funcionar tambem com Mesh Data compartilhado.
   - Preserva os materiais anteriores em vez de apaga-los.
   - Reutiliza o material criado pelo Tiago Tools em execucoes futuras.

INSTALACAO
----------
Edit > Preferences > Extensions > menu > Install from Disk
Selecione o ZIP tiago-tools-1.0.0.zip e ative Tiago Tools.

USO
---
3D Viewport > N > aba Tiago > Tiago Tools
