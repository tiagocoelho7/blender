TIAGO TOOLS 1.0.1
=================

Compatibilidade: Blender 5.0.0 ou superior (API alvo: 5.0.0).
Extensao atualizada a partir de Tiago Tools 1.0.0.

FERRAMENTAS
-----------
1. Desativar Modifiers (Viewport)
   - Todos: todos os objetos da Scene, incluindo collections ocultas.
   - Visiveis: objetos vinculados a collections visiveis no View Layer atual.
   - Nao altera o estado/visibilidade das collections.
   - So modifica modifier.show_viewport; nao modifica modifier.show_render.

2. Safe Sub
   - Adiciona um modifier Subdivision Surface ao objeto MESH ativo.
   - Cria o modifier e imediatamente define:
       show_viewport = False
       show_render = False
       levels = 0
       render_levels = 0
       show_in_editmode = False
       show_on_cage = False
   - Cria o modifier no objeto ativo; nao afeta outros objetos.

REMOVIDO NA 1.0.1
----------------
- 'Pintar cores aleatorias' foi totalmente removido (operador, painel,
  funcoes auxiliares e import random).
- Para cores distintas de exibicao sem alterar materiais: no 3D Viewport,
  abra o menu Shading (seta ao lado do icone Solid), selecione Color Type > Random.

ATUALIZAR DE 1.0.0
------------------
1. Salve seu trabalho.
2. Edit > Preferences > Extensions.
3. Desative/remova apenas 'Tiago Tools' 1.0.0 (nao 'Tiago Global Scripts').
4. Pelo menu de Extensions escolha Install from Disk e selecione
   tiago-tools-1.0.1.zip.
5. Habilite 'Tiago Tools', se necessario.
6. Volte a 3D Viewport > N > aba Tiago > painel Tiago Tools.
7. Verifique que existem apenas as secoes 'Modifiers' e 'Subdivision'.
8. Se o painel antigo permanecer, reinicie o Blender para limpar o registro.

NAO E NECESSARIO salvar o Startup File so para atualizar esta extensao.

RECOMENDACAO DE TESTE
--------------------
Teste em uma copia descartavel do seu .blend antes de usar em arquivos reais:
- Modifiers/Todos: todos os modifiers no viewport devem ficar desligados.
- Modifiers/Visiveis: collections ocultas nao devem ser processadas.
- Safe Sub: com uma mesh ativa, cria Subdivision com viewport/render desligados.
- A ferramenta de cores aleatorias nao deve aparecer.

Esta versao preserva a logica 1.0.0 das duas ferramentas remanescentes.
