# T7 Measures - Consolidacao Master SPEC-R8.1

**Data:** 2026-10-22. **Natureza:** auditoria documental + replays offline. **Alvo:** Blender 5.2.2 LTS.

## Resultado
- Auditor A: GO DOCUMENTAL CONDICIONADO, 0 BLOCKER / 0 HIGH / 5 MEDIUM / 2 LOW.
- Auditor B: GO DOCUMENTAL CONDICIONADO, 0 BLOCKER / 0 HIGH / 4 MEDIUM / 3 LOW.
- Master: GO DOCUMENTAL CONDICIONADO para encerramento da rodada e decisao do proprietario sobre Work M0 **exclusivamente offline**. Nao e homologacao de addon.
- **HOLD:** Work M0 ainda nao autorizado; M1/M2, Blender real, .blend do usuario, instalacao e producao em HOLD.
- Nenhuma mudanca na SPEC-R8 ou no adendo R8.1 original; clarificacoes no arquivo 03 sao PROPOSTAS, nao aprovacao unilateral.

## Comece pelos arquivos
- `01_PARECER_MASTER_R8_1.md`: conclusao, custodia, replays, limites e proximo gate.
- `02_MATRIZ_CONSOLIDADA_ACHADOS.md`: correlacao dos achados de A e B e destinacao.
- `03_NOTA_MASTER_CLARIFICACOES_PROPOSTAS.md`: corrigendas de leitura, sem alterar os originais.
- `04_DECISOES_PENDENTES_PROPRIETARIO.md`: limites propostos e autorizacoes necessarias.
- `05_PROMPT_WORK_M0_RASCUNHO_NAO_AUTORIZADO.md`: escopo futuro de implementacao offline; **NAO ENVIAR sem aprovacao**.
- `06_PROMPT_CONTINUIDADE_MASTER.md`: contexto para outro chat Master, se necessario.
- `07_LIMITES_DA_EVIDENCIA.md`: o que foi e nao foi comprovado.
- `entradas/`: ZIPs exatos A/B recebidos pelos auditores.
- `pareceres_originais/`: resultados originais A/B, sem qualquer alteracao.
- `base/`: documentos normativos congelados, matrizes e demonstradores.
- `evidencias/`: comparacoes de hashes, testes e contraprovas do Master.
- `tools/replay_offline.py`: reproduz suites sem Blender em diretorio temporario.
- `SHA256_MANIFEST.txt`: hashes SHA-256 de todos os arquivos do pacote, exceto o manifesto.

## Verificar e reproduzir
- Arquivos dentro do ZIP sao protegidos por manifesto e podem ser auditados sem depender deste chat.
- `python3 tools/replay_offline.py` no diretorio extraido, sem usar Blender.
- O script usa a biblioteca padrao Python e executa testes de auditores sobre copias temporarias dos arquivos. Leia o codigo antes de rodar scripts recebidos de terceiros.
- Logs e manifestos dos auditores sao preservados nos ZIPs de resultados originais.

Este pacote nao aciona Work, nao altera projetos Blender e nao ratifica constantes.
