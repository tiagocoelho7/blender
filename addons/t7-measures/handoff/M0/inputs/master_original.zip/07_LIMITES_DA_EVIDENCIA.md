# Evidencia e nao-evidencia (SPEC-R8.1)

### Comprovado neste gate documental/offline
- Documentos de entrada R8/R8.1 idênticos nos ZIPs originais de A e B.
- Manifestos inteiros dos resultados e entradas atuais coincidem; nenhuma candidata foi reescrita.
- Contratos didaticos reproduzidos em copias descartaveis: 22/22 R8.1, 30/30 R8, A 1.926/1.926, B 44/44.
- Assercoes negativas reproduzem defeitos do helper para valores finitos gigantes, flags truthy e aridade errada. `PASS` aqui significa observacao esperada, nao software correto.
- Parte substantiva da R8.1 foi considerada satisfatoria pelos auditores no papel, condicionalmente.

### Nao comprovado e ainda bloqueado
- Nao existe addon implementado/homologado nem certificados geometricos reais.
- Blender 5.2.2 LTS API, `bpy`, `bmesh`, pointers, modifiers, escolha de selecao, multi-area e GUI nao foram exercitados.
- Nao foi medida memoria RSS ou performance num `.blend` real. O estimador de 128 MiB nao e garantia.
- A politica D04=P nao equivale a aprovar constantes; thresholds atuais foram apenas propostos.
- Nao foi provado que nenhuma alteracao ocorra num `.blend` real (teste no-write futuro).
- Nao ha autorizacao para Work, M0, M1, M2, Blender real, instalacao nem uso.
