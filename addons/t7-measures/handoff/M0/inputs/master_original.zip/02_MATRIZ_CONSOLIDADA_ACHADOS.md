# T7 Measures - Matriz consolidada R8.1

| Grupo | IDs | Gravidade reportada | Materia | Tratamento Master | Gate |
|---|---|---|---|---|---|
| C01 | A81-M01 / B81-M01 | MEDIUM/MEDIUM | Helper `outward_bounds` levanta InvalidOperation para finite grande | Reproduzido; helper nao reutilizavel. Teste e preflight de dominio em M0 | Antes de aceitar helper como oraculo |
| C02 | A81-M02 / B81-L03 | MEDIUM/LOW | Nominal ausente x invalido x bounds ausentes | Redigir tabela de estados e ordem de precedencia | Na especificacao entregue a M0 |
| C03 | A81-M03 | MEDIUM | Modelo de sessao nao simula geracao/contexto completo e stale UX | Expandir state machine e teste futuro Blender | M0 abstrato; M1 real |
| C04 | B81-M03 | MEDIUM | EDIT_MESH invariavel e `mesh_select_mode` mutavel nao diferenciados | Permitir troca VERT/EDGE/FACE entre cliques, preservar contexto | Antes de adapter Blender |
| C05 | A81-M04 | MEDIUM | HALF_EVEN Q19 generalizado indevidamente; binary32 com cobertura estreita | Casos p=0/3/6 e bits reais | M0 QA; Blender real futuro |
| C06 | A81-M05 | MEDIUM | Circularidade: majorante de memoria antes do M0 que iria pesquisa-lo | Permitir M0 exploratorio; barrar runtime ate prova/refusa segura | Condicao M0/M1 |
| C07 | B81-M02 | MEDIUM | `mixed_face_state` aceita strings truthy e bounds de aridade errada | Tipar bool/tuple e validar erros; nao copiar helper | M0 QA |
| C08 | B81-M04 | MEDIUM | Frase de cegamento historico nao corresponde ao anexo R8 | Corrigir declaracao de independencia historica | Relatorio/continuidade |
| C09 | A81-L01 / B81-L02 | LOW/LOW | Vocabulário de estados nao univoco | Mapa logico/UI e aliases de helper | Antes de interface |
| C10 | A81-L02 | LOW | `-0.000` possivel na exibicao | Normalizar zero apenas visualmente | QA de interface |
| C11 | B81-L01 | LOW | Linha QA Q23 fora da tabela Markdown | Corrigir em documento derivado sem alterar R8.1 | Antes do handoff |

Todos os achados acima foram classificados pelos auditores como nao bloqueantes da consolidacao documental. Nada nesta tabela demonstra conformidade de addon inexistente.
