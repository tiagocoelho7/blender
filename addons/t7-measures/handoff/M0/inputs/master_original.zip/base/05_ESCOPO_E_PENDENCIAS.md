# Escopo, pendencias e criterios de gate (sem atribuicoes de auditor)

## Fechamento da R8

A SPEC-R8 original foi avaliada por dois auditores independentes: GO documental condicionado em ambos, zero HIGH ou BLOCKER. Os bloqueantes principais da R7 (SN06/SN07 sub-q e retencao da assinatura S_A) foram considerados fechados documentalmente. Resultados atuais A/B e logs detalhados ficam apenas com o Master; a nova revisao continua nao aprovada.

## Pendencias que o adendo R8.1 enfrenta

- Cobertura de V-F/E-F com face P e falha isolada de apresentacao de area.
- Estado A/B e memoria agregada entre multiplas janelas/areas; custo real de S_A+S1+S2.
- Validacao fail-closed de dados nao finitos, certificados invertidos/incoerentes no demonstrador didatico; evitar reuse do auxiliar R8 como codigo final.
- QA dos vizinhos binarios reais do HALF_EVEN, sem confundir decimal ideal com bits armazenados.
- Higiene documental de referencia R6 ausente e atribuicoes historicas nos materiais entregues a A/B.

## Gates separados

1. Auditorias documentais A/B da candidata R8.1, com parecer independente e hashes.
2. Consolidacao Master e ratificacao pelo proprietario dos parametros (incluindo um slot global). Nao presumir aprovacao.
3. Autorizacao expressa do Work M0: kernel/calculos/provas offline e plano de recursos; M1/M2 exigem novas autorizacoes conforme escopo.
4. Auditoria de codigo independente A/B, testes Blender 5.2.2 em copias descartaveis sob permissao separada, no-write e performance verificadas; so entao homologacao e uso pessoal.

**HOLD:** nenhum addon desenvolvido ou testado em Blender; nenhum arquivo `.blend` lido/alterado; nenhum Work acionado; nenhuma constante de tolerancia ratificada neste documento.
