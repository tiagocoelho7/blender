#!/usr/bin/env python3
"""R8: oraculo ILUSTRATIVO de contratos UX/ciclo de vida (nao e addon Blender).

Usa somente Python stdlib; executa testes locais abstratos, sem bpy, escrita em .blend
ou alegacao de conformidade Blender real. Serve para triagem documental cega A/B.
"""
from decimal import Decimal as D, ROUND_HALF_EVEN, ROUND_FLOOR, ROUND_CEILING
from pathlib import Path
import unittest


def quantum(p):
    if p not in range(7):
        raise ValueError("p precisa ser 0..6")
    return D(1).scaleb(-p)


def nominal_str(value, p):
    return str(D(value).quantize(quantum(p), rounding=ROUND_HALF_EVEN))


def format_outward(low, high, p):
    q = quantum(p)
    return (D(low).quantize(q, rounding=ROUND_FLOOR),
            D(high).quantize(q, rounding=ROUND_CEILING))


def decide_display(nominal, low, high, p, *, area_p_gate=True):
    """Maquina ABSTRATA: aplica apenas certificados fornecidos como premissas."""
    if low is None or high is None:
        return "SEM_FAIXA"
    low, high, nom = D(low), D(high), D(nominal)
    if not (D(0) <= low <= high and nom >= 0):
        return "SEM_FAIXA"
    if not area_p_gate:
        return "AREA_SEM_NOMINAL"
    if low == 0:
        return "INDETERMINADO_COM_FAIXA"
    if nominal_str(nom, p) == nominal_str(D(0), p) and high < quantum(p):
        return "SUB_Q_CERTIFICADO"
    return "POSITIVO_COM_FAIXA"


def compound_ff(geometry_ok, area_total_ok, distance_certified, interval_includes_zero=False):
    """Modelo de estado, nao computa uma distancia nem certifica uma face."""
    if not geometry_ok:
        return ("RECUSA", "SEM_DISTANCIA")
    area = "AREA_NOMINAL_PERMITIDA" if area_total_ok else "AREA_SEM_NOMINAL"
    if not distance_certified:
        return area, "DISTANCIA_INDETERMINADA"
    return area, "DISTANCIA_COM_FAIXA_INDETERMINADA" if interval_includes_zero else "DISTANCIA_CERTIFICADA_COM_FAIXA"


class CaptureModel:
    """Modelo ilustrativo sem objetos BMesh: compara bytes integrais entre cliques."""
    def __init__(self):
        self.a_bytes = None
        self.b_captured = False

    def take_a(self, s1, s2):
        assert isinstance(s1, bytes) and isinstance(s2, bytes)
        self.a_bytes = s1 if s1 == s2 else None
        self.b_captured = False
        return self.a_bytes is not None

    def take_b(self, s1, s2, fake_digest=None):
        del fake_digest  # colisao sintetica nao e certificado
        if self.a_bytes is None or s1 != s2 or s1 != self.a_bytes:
            self.clear()
            return False
        self.b_captured = True
        return True

    def calculate(self, s1, s2, fake_digest=None):
        del fake_digest
        valid = self.b_captured and self.a_bytes is not None and s1 == s2 == self.a_bytes
        self.clear()  # commit final ou invalidacao libera mem em ambos os casos
        return bool(valid)

    def clear(self):
        self.a_bytes = None
        self.b_captured = False


def peak_budget_ok(a_memory, s1_memory, s2_memory, other_memory, budget=128*1024*1024):
    return sum((a_memory, s1_memory, s2_memory, other_memory)) <= budget


class R8ContractTests(unittest.TestCase):
    def test_01_sn06_cross_q_p3(self):
        self.assertEqual(decide_display('0.0004','0.00025','0.00135',3),'POSITIVO_COM_FAIXA')

    def test_02_sn06_below_q(self):
        self.assertEqual(decide_display('0.0004','0.00025','0.0009',3),'SUB_Q_CERTIFICADO')

    def test_03_sn06_equal_upper_q(self):
        self.assertEqual(decide_display('0.0004','0.00025','0.001',3),'POSITIVO_COM_FAIXA')

    def test_04_sn06_p0(self):
        self.assertEqual(decide_display('0.4','0.25','1.35',0),'POSITIVO_COM_FAIXA')

    def test_05_sn06_p6(self):
        self.assertEqual(decide_display('0.0000004','0.00000025','0.00000135',6),'POSITIVO_COM_FAIXA')

    def test_06_area_none_cross_q(self):
        self.assertEqual(decide_display('0.4','0.25','1.35',0),'POSITIVO_COM_FAIXA')

    def test_07_area_gate_first(self):
        self.assertEqual(decide_display('0.0004','0.0003','0.0008',3,area_p_gate=False),'AREA_SEM_NOMINAL')

    def test_08_area_gate_allow(self):
        self.assertEqual(decide_display('0.0004','0.0003','0.0008',3,area_p_gate=True),'SUB_Q_CERTIFICADO')

    def test_09_zero_lower_not_proof_of_positive(self):
        self.assertEqual(decide_display('0.0004','0','0.0009',3),'INDETERMINADO_COM_FAIXA')

    def test_10_missing_upper_no_number(self):
        self.assertEqual(decide_display('0.0004','0.0003',None,3),'SEM_FAIXA')

    def test_11_half_even_ties_all_p(self):
        for p in [0,3,6]:
            with self.subTest(p=p):
                q=quantum(p)
                self.assertEqual(D(nominal_str(q/2,p)),D(0))
                self.assertEqual(D(nominal_str(q*D('1.5'),p)),q*2)

    def test_12_half_even_neighbors_all_p(self):
        for p in [0,3,6]:
            with self.subTest(p=p):
                q=quantum(p); eps=q/D(10000)
                self.assertEqual(D(nominal_str(q/2-eps,p)),D(0))
                self.assertEqual(D(nominal_str(q/2+eps,p)),q)

    def test_13_outward_independent_of_half_even(self):
        self.assertEqual(format_outward('0.00025','0.00135',3),(D('0.000'),D('0.002')))

    def test_14_capture_a_retained_after_commit(self):
        c=CaptureModel(); self.assertTrue(c.take_a(b'A',b'A')); self.assertEqual(c.a_bytes,b'A')

    def test_15_synthetic_digest_collision_between_cliques(self):
        c=CaptureModel(); c.take_a(b'A',b'A')
        self.assertFalse(c.take_b(b'B',b'B',fake_digest=b'FORCED_COLLISION'))

    def test_16_synthetic_digest_collision_calculate(self):
        c=CaptureModel(); c.take_a(b'A',b'A'); self.assertTrue(c.take_b(b'A',b'A'))
        self.assertFalse(c.calculate(b'B',b'B',fake_digest=b'FORCED_COLLISION'))

    def test_17_success_clears_capture_after_final_commit(self):
        c=CaptureModel(); c.take_a(b'A',b'A'); c.take_b(b'A',b'A')
        self.assertTrue(c.calculate(b'A',b'A')); self.assertIsNone(c.a_bytes)
        self.assertFalse(c.calculate(b'A',b'A'))

    def test_18_invalid_capture_clears_slots(self):
        c=CaptureModel(); c.take_a(b'A',b'A'); self.assertFalse(c.take_b(b'A',b'OTHER'))
        self.assertIsNone(c.a_bytes)

    def test_19_peak_budget_three_buffers(self):
        MiB=1024*1024
        self.assertFalse(peak_budget_ok(45*MiB,45*MiB,45*MiB,0))

    def test_20_peak_budget_under_threshold(self):
        MiB=1024*1024
        self.assertTrue(peak_budget_ok(30*MiB,30*MiB,30*MiB,20*MiB))

    def test_21_ff_total_area_gate_failure_distance_can_survive(self):
        self.assertEqual(compound_ff(True,False,True),('AREA_SEM_NOMINAL','DISTANCIA_CERTIFICADA_COM_FAIXA'))

    def test_22_ff_geometry_gate_failure_blocks_both(self):
        self.assertEqual(compound_ff(False,True,True),('RECUSA','SEM_DISTANCIA'))

    def test_23_ff_areas_valid_distance_not_certified(self):
        self.assertEqual(compound_ff(True,True,False),('AREA_NOMINAL_PERMITIDA','DISTANCIA_INDETERMINADA'))

    def test_24_ff_distance_includes_zero_indeterminate(self):
        self.assertEqual(compound_ff(True,True,True,True),('AREA_NOMINAL_PERMITIDA','DISTANCIA_COM_FAIXA_INDETERMINADA'))

    def test_25_no_rank_tie(self):
        low1,high1,low2,high2=D(1),D(2),D(1),D(2)
        self.assertFalse(high1<low2 or high2<low1)

    def test_26_R8_spec_declares_retained_bytes(self):
        spec=(Path(__file__).with_name('01_ESPECIFICACAO_R8.md')).read_text()
        self.assertIn('**os bytes canonicos COMPLETOS `S_A`**',spec)
        self.assertIn('pico simultaneo `S_A + S1 + S2`',spec)

    def test_27_R8_QA_SN_require_certificates(self):
        qa=(Path(__file__).with_name('02_MATRIZ_QA_R8.md')).read_text()
        sn06=next(ln for ln in qa.splitlines() if ln.startswith('| SN06 |'))
        sn07=next(ln for ln in qa.splitlines() if ln.startswith('| SN07 |'))
        self.assertIn('0<d_L<=d_U<q',sn06)
        self.assertIn('0<A_L<=A_U<q',sn07)
        self.assertIn('D801',qa)

    def test_28_unit_milli_and_none_disambiguation(self):
        spec=(Path(__file__).with_name('01_ESPECIFICACAO_R8.md')).read_text()
        self.assertIn('BU',spec)
        self.assertIn('mm²',spec)
        self.assertIn('Blender **5.2.2 LTS**',spec)

    def test_29_fail_closed_if_inverted_bounds(self):
        self.assertEqual(decide_display('.0001','.001','.0001',3),'SEM_FAIXA')

    def test_30_no_geometry_code_imported(self):
        self.assertNotIn('bpy',globals())


if __name__ == '__main__':
    unittest.main(verbosity=2)
