#!/usr/bin/env python3
"""T7 Measures R8.1 - demonstrador de QA stdlib OFFLINE (NAO e addon Blender).

O helper ilustra validacao de certificados fornecidos por hipotese; NAO calcula
certificados nem prova geometria, memoria real, versao API, ou ausencia de escrita.
"""
from decimal import Decimal as D, InvalidOperation, ROUND_HALF_EVEN, ROUND_CEILING, ROUND_FLOOR, localcontext
import math
import struct
import unittest

MiB = 1024 * 1024


def q(p):
    if type(p) is not int or not (0 <= p <= 6):
        raise ValueError('precision 0..6')
    return D(1).scaleb(-p)


def to_decimal_exactly(value):
    """Do not turn a binary floating-point input into a rounded decimal string."""
    if value is None or isinstance(value, bool):
        raise ValueError('absent or invalid')
    if isinstance(value, float):
        return D.from_float(value)
    if isinstance(value, (D, int, str)):
        return D(value)
    raise ValueError('unsupported')


def checked_interval(low, high, p):
    """For interval-only display. Never certifies an exact point or contact."""
    try:
        _=q(p)
        lo, hi=to_decimal_exactly(low),to_decimal_exactly(high)
        if not (lo.is_finite() and hi.is_finite() and D(0) <= lo <= hi):
            return ('SEM_FAIXA',None)
        return ('INDETERMINADO_COM_FAIXA' if lo == 0 else 'POSITIVO_COM_FAIXA',(lo,hi))
    except (ValueError, TypeError, InvalidOperation, OverflowError, ArithmeticError):
        return ('SEM_FAIXA',None)


def checked_nominal(nominal, low, high, p, *, area_gate=True):
    """Validates an externally certified range for SAME quantity as nominal.

    A missing nominal is an error ONLY FOR this nominal-specific helper: use
    checked_interval for legitimate range-only results without a nominal.
    """
    try:
        quantum=q(p)
        nom,lo,hi = [to_decimal_exactly(x) for x in (nominal,low,high)]
        if not (nom.is_finite() and lo.is_finite() and hi.is_finite()):
            return 'SEM_FAIXA'
        if not (D(0) <= lo <= nom <= hi):
            return 'SEM_FAIXA'
        if not area_gate:
            return 'AREA_SEM_NOMINAL'
        if lo == 0:
            return 'INDETERMINADO_COM_FAIXA'
        with localcontext() as ctx:
            ctx.prec = max(50, len(nom.as_tuple().digits) + 15)
            nom_display=nom.quantize(quantum,rounding=ROUND_HALF_EVEN)
        if nom_display == 0 and hi < quantum:
            return 'SUB_Q_CERTIFICADO'
        return 'POSITIVO_COM_FAIXA'
    except (ValueError, TypeError, InvalidOperation, OverflowError, ArithmeticError):
        return 'SEM_FAIXA'


def outward_bounds(low,high,p):
    state,rng=checked_interval(low,high,p)
    if state=='SEM_FAIXA':return None
    lo,hi=rng; quantum=q(p)
    with localcontext() as ctx:
        ctx.prec=max(50,len(lo.as_tuple().digits)+len(hi.as_tuple().digits)+15)
        return lo.quantize(quantum,rounding=ROUND_FLOOR),hi.quantize(quantum,rounding=ROUND_CEILING)


def mixed_face_state(geometry_ok,area_total_ok,distance_bounds):
    """No calculation of area or distance; abstract gate/state illustration."""
    if not geometry_ok:
        return ('RECUSA','SEM_DISTANCIA')
    area='AREA_NOMINAL_PERMITIDO' if area_total_ok else 'AREA_SEM_NOMINAL'
    if distance_bounds is None:
        return (area,'INDETERMINADO_SEM_FAIXA')
    decision,_=checked_interval(*distance_bounds,p=3)
    return area,decision if decision!='SEM_FAIXA' else 'INDETERMINADO_SEM_FAIXA'


class GlobalSessionModel:
    """Only a state machine. Has no bpy imports, handlers, or real allocations."""
    def __init__(self):
        self.owner=None
        self.sa=None
        self.b=None
    def clear(self):
        self.owner=None; self.sa=None; self.b=None
    def capture_a(self, owner, s1, s2):
        self.clear()
        if type(s1) is not bytes or type(s2) is not bytes or s1!=s2:return False
        self.owner=owner; self.sa=s1; return True
    def capture_b(self, owner,s1,s2):
        if self.sa is None or self.owner!=owner or s1!=s2 or s1!=self.sa:
            self.clear();return False
        self.b=s1;return True
    def calculate(self,owner,s1,s2):
        good=self.sa is not None and self.b is not None and owner==self.owner and s1==s2==self.sa==self.b
        self.clear();return good


def budget_triple(a,s1,s2,other,limit=128*MiB):
    if any(type(x) is not int or x<0 for x in (a,s1,s2,other,limit)):
        return False
    return sum((a,s1,s2,other)) <= limit


class R81OfflineQA(unittest.TestCase):
    def test_invalid_nan_and_inf(self):
        for bad in ('NaN','Infinity','-Infinity',D('NaN'),float('inf'),float('nan')):
            for x in range(3):
                args=['.0004','.0002','.0009'];args[x]=bad
                with self.subTest(bad=str(bad),i=x):
                    self.assertEqual(checked_nominal(*args,p=3),'SEM_FAIXA')
    def test_invalid_types(self):
        for bad in (None,object(),True,{},'silly-number'):
            self.assertEqual(checked_nominal(bad,'.0002','.0009',3),'SEM_FAIXA')
    def test_inverted_and_negative(self):
        self.assertEqual(checked_nominal('.0004','.0009','.0002',3),'SEM_FAIXA')
        self.assertEqual(checked_nominal('.0004','-.0001','.0009',3),'SEM_FAIXA')
    def test_nominal_incompatible_with_certificate(self):
        self.assertEqual(checked_nominal('1.5','0.1','0.2',0),'SEM_FAIXA')
    def test_bad_precision(self):
        for p in (-1,7,True,'3',3.0,None):
            self.assertEqual(checked_nominal('.0004','.0002','.0009',p),'SEM_FAIXA')
    def test_r8_positive_crosses_quantum(self):
        self.assertEqual(checked_nominal('.0004','.00025','.00135',3),'POSITIVO_COM_FAIXA')
        self.assertEqual(outward_bounds('.00025','.00135',3),(D('0.000'),D('0.002')))
    def test_strict_subquantum(self):
        self.assertEqual(checked_nominal('.0004','.00025','.0009',3),'SUB_Q_CERTIFICADO')
        self.assertEqual(checked_nominal('.0004','.00025','.001',3),'POSITIVO_COM_FAIXA')
    def test_zero_lower_never_contact(self):
        self.assertEqual(checked_nominal('0','0','.0004',3),'INDETERMINADO_COM_FAIXA')
        self.assertEqual(checked_interval('0','.0004',3)[0],'INDETERMINADO_COM_FAIXA')
    def test_interval_only_can_be_positive(self):
        self.assertEqual(checked_interval('4.9998','5.0002',3)[0],'POSITIVO_COM_FAIXA')
        self.assertEqual(checked_nominal(None,'4.9998','5.0002',3),'SEM_FAIXA')
    def test_area_total_gate(self):
        self.assertEqual(checked_nominal('.0004','.00025','.0009',3,area_gate=False),'AREA_SEM_NOMINAL')
    def test_mixed_face_area_total_fail(self):
        self.assertEqual(mixed_face_state(True,False,('4.9998','5.0002')),('AREA_SEM_NOMINAL','POSITIVO_COM_FAIXA'))
        self.assertEqual(mixed_face_state(True,False,('0','.0004')),('AREA_SEM_NOMINAL','INDETERMINADO_COM_FAIXA'))
    def test_mixed_face_geometry_fail(self):
        self.assertEqual(mixed_face_state(False,True,('5','5')),('RECUSA','SEM_DISTANCIA'))
    def test_mixed_face_distance_no_cert(self):
        self.assertEqual(mixed_face_state(True,False,None),('AREA_SEM_NOMINAL','INDETERMINADO_SEM_FAIXA'))
    def test_global_slot_cross_area_invalidation(self):
        s=GlobalSessionModel()
        self.assertTrue(s.capture_a('area1',b'a',b'a'))
        self.assertTrue(s.capture_a('area2',b'b',b'b'))
        self.assertEqual(s.owner,'area2')
        self.assertFalse(s.capture_b('area1',b'b',b'b'))
        self.assertIsNone(s.sa)
    def test_global_slot_b_old_cleared_on_a(self):
        s=GlobalSessionModel();s.capture_a('a',b'x',b'x');s.capture_b('a',b'x',b'x')
        self.assertTrue(s.capture_a('a',b'y',b'y'))
        self.assertIsNone(s.b)
        self.assertFalse(s.calculate('a',b'y',b'y'))
    def test_global_slot_no_cross_context_b(self):
        s=GlobalSessionModel();s.capture_a('a',b'x',b'x')
        self.assertFalse(s.capture_b('b',b'x',b'x'))
    def test_global_slot_clears_on_calculation(self):
        s=GlobalSessionModel();s.capture_a('a',b'x',b'x');s.capture_b('a',b'x',b'x')
        self.assertTrue(s.calculate('a',b'x',b'x'))
        self.assertIsNone(s.sa)
    def test_peak_budget(self):
        self.assertFalse(budget_triple(45*MiB,45*MiB,45*MiB,0))
        self.assertTrue(budget_triple(30*MiB,30*MiB,30*MiB,20*MiB))
    def test_nominal_binary64_neighbor_values(self):
        for p in (0,3,6):
            with self.subTest(p=p):
                t=q(p)/2
                f=float(t)
                left=math.nextafter(f,-math.inf)
                right=math.nextafter(f,math.inf)
                self.assertLess(D.from_float(left),t)
                self.assertGreater(D.from_float(right),t)
                # actual float exactness preserved: a nominal on the left/right
                self.assertEqual(D.from_float(left).quantize(q(p),rounding=ROUND_HALF_EVEN),D(0))
                self.assertEqual(D.from_float(right).quantize(q(p),rounding=ROUND_HALF_EVEN),q(p))
    def test_nominal_float_vs_decimal(self):
        self.assertEqual(D('.0005').quantize(q(3),rounding=ROUND_HALF_EVEN),D('0.000'))
        self.assertEqual(to_decimal_exactly(float(.0005)).quantize(q(3),rounding=ROUND_HALF_EVEN),D('0.001'))
    def test_binary32_stored_value_sample(self):
        original=8192.0002
        stored=struct.unpack('<f',struct.pack('<f',original))[0]
        self.assertEqual(stored,8192.0)
        self.assertNotEqual(stored,original)
    def test_no_blender_or_mutating_calls(self):
        self.assertNotIn('bpy',globals())
        self.assertNotIn('bmesh',globals())


if __name__=='__main__':
    unittest.main(verbosity=2)
