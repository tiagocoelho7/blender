# T7 Measures - Parecer consolidado do Chat Master - SPEC-R8.1

**Data:** 2026-10-22 | **Revisao analisada:** SPEC-R8 congelada + adendo candidato R8.1 | **Versao-alvo:** Blender 5.2.2 LTS.

## 1. Veredito e gate

**GO DOCUMENTAL CONDICIONADO** para **encerrar a rodada A/B R8.1 e submeter o plano do primeiro Work M0 ao proprietario**. Nao existe GO automatico para implementar. O futuro Work M0, se autorizado, ficara restrito a pesquisa, kernel de geometria e QA offline sobre fixtures sinteticos/copiados. Blender real, integracao, uso de .blend do proprietario, instalacao e producao continuam em HOLD.

- Auditor A: 0 BLOCKER, 0 HIGH, 5 MEDIUM, 2 LOW, GO DOCUMENTAL CONDICIONADO.
- Auditor B: 0 BLOCKER, 0 HIGH, 4 MEDIUM, 3 LOW, GO DOCUMENTAL CONDICIONADO.
- 14 apontamentos individuais nao significam 14 defeitos distintos. Ha sobreposicoes entre os relatos.
- D04=P esta aprovada apenas **conceitualmente**: area de face quase plana pode ser aproximada com limite e aviso; nunca inferir contato falso.
- Constantes, politica de slot unico e orcamento de memoria ainda NAO foram ratificados.

## 2. Custodia verificada pelo Master

- ZIP A resultado: `473d2e1984b002eada76b453744dbc92134c7d95f7ae09bc6b8218a1ecfd7366` (71.833 bytes), ZIP/CRC OK, **16/16** hashes internos validos.
- ZIP B resultado: `5a01c30230e77c946ca0a1efa229e012ac6d326227eace477ff8bb32f233b3f9` (159.660 bytes), ZIP/CRC OK, **28/28** hashes internos validos.
- ZIP original A: `1c28624acff0b26d307c54ba90cb8aa2b1de42de5189d0adb8406676b2bb4e75`; original B: `6afe556e9615db725fb4ea3e36d5420431f239f7281c6889805d0441d72fa174`. Ambos batem, byte a byte, com os ZIPs de entrada atualmente preservados no projeto.
- Manifestos dos pacotes de origem: **9/9** validos cada. Cinco arquivos nucleares compartilhados R8/R8.1/QA/helper tem SHA-256 identico entre A e B.
- SPEC-R8 SHA-256 `a942cffff35e4e732fda5dabf20ffd8319696afe5086590f3dd4aba031467f68`. Adendo R8.1 SHA-256 `458c6b78fb9ee55cd15fc4d1399beea3534e2fc1fe98587c420dc041ebbf558e`. QA R8.1 SHA-256 `5c2ca454e0da45b4449c19d4827c2ab4bcb9a0ca5992e5f24c5cbe64e51a48a9`.
- Integridade de hashes prova correspondencia ao material recebido; nao prova autoria externa ou que auditores nunca leram material historico. A R8 contem atribuicoes historicas A/B de rodadas anteriores, mas nao foi encontrado parecer R8.1 atual do par nos insumos individuais.

## 3. Reproducao independente em copia descartavel

| Suite | Execucao Master | Interpretacao |
|---|---:|---|
| Runner didatico R8.1 | 22/22 PASS | Regras abstratas, nao kernel |
| Runner didatico R8 | 30/30 PASS | Regressao documental, nao addon |
| Independente do Auditor A | 1.926/1.926 assercoes conforme esperado | Inclui 4 negativos intencionais |
| Independente do Auditor B | 44/44 testes conforme esperado | Inclui 8 negativos/observacoes intencionais |
| Contraprovas adicionais Master | 12/12 observacoes esperadas | Diversas reproduzem falhas do helper |

A primeira execucao do runner B independente na estrutura adaptada falhou por arquivo auxiliar localizado em pasta incorreta. Corrigimos somente o arranjo do diretorio descartavel, sem mudar um byte dos scripts, e a reexecucao resultou 44/44. A estrutura final portatil consta em `tools/replay_offline.py`. Os replays R8 (30) e R8.1 (22) foram executados com sucesso em ambas as copias de trabalho.

Nao houve execucao de Blender ou acesso a arquivos `.blend` do proprietario. Testes didaticos positivos nao validam kernel geometrico nao implementado, integracao UI, medida com modifiers, snapshot, no-write ou consumo real de memoria.

## 4. Consolidacao tecnica

As correcoes normativas nucleares R8.1 foram aceitas documentalmente por ambos, sem novos HIGH/BLOCKER. Ainda exigem trabalho antes de integrar:

1. **Demonstradores auxiliares, nao codigo de addon:** `outward_bounds` em quantias finitas muito grandes lanca `decimal.InvalidOperation`; `mixed_face_state` interpreta string `'False'` como verdade e lanca `TypeError` para tuple de tamanho 3. Nunca reutilizar o helper como software produtivo. Em M0, tipar parametros e limites, tratar todos os erros sem excecao nao controlada e usar oraculo de teste revisado.
2. **Nominal opcional:** intervalo certificado valido sem nominal pode ser mostrado como faixa + estado; nominal **fornecido e invalido** nao pode ser transformado silenciosamente em ausente. Ausencia de limites obrigatorios falha fechada.
3. **Contexto A/B:** `context.mode=EDIT_MESH` permanece; `mesh_select_mode` de VERT/EDGE/FACE pode mudar entre A e B para permitir modalidades mistas. Proprietario de janela/area, Scene/objeto/mesh, geracao e snapshot integro precisam ser revalidados. O modelo do helper nao prova essas transicoes reais.
4. **Arredondamento:** corrigir a interpretacao de Q19 para p=3: float(q/2) esta acima do empate decimal. Para p=0 coincide exatamente; para p=6 fica abaixo. Testar bits binary32, extremos e formatação com `-0` normalizado visualmente.
5. **Memoria:** M0 pode **pesquisar** majorantes e estimadores de memoria. Limite defendivel, recusa segura e benchmarks precedem etapas que executem consultas sobre malhas reais; o teto de 128 MiB proposto e orcamento de projeto, nao garantia medida de RSS.
6. **Processo/documentos:** corrigir frase de cegamento historico; o auditor do presente ciclo nao recebeu parecer atual do par, mas recebeu SPEC-R8 com referencias A/B anteriores. Corrigir linha Q23 separada da tabela; mapear nomes dos estados em um contrato unico.

As recomendacoes estao detalhadas em `02_MATRIZ_CONSOLIDADA_ACHADOS.md` e `03_NOTA_MASTER_CLARIFICACOES_PROPOSTAS.md`.

## 5. Recomendacao ao proprietario

**Nao abrir outra auditoria extensa so para erros do helper didatico e clarezas editoriais.** Preservar a R8/R8.1 congeladas e registrar as interpretacoes propostas do Master com proveniencia. Submeter um unico pacote de decisao: ratificacao provisoria dos parametros para pesquisa e autorizacao especifica de Work M0 offline. A/B voltam a auditar o codigo produzido por Work e qualquer mudanca semantica de matematica, limites ou seguranca.

Nenhuma decisao do proprietario e inferida do recebimento deste bundle. **Work M0, Blender real, M1/M2, instalacao e producao continuam HOLD.**
