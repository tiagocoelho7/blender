#!/usr/bin/env python3
"""Portable R8.1 replay, all work in ephemeral dirs; stdlib only.
Runs original third-party auditor scripts; review before executing.
No Blender or user .blend files are accessed.
"""
import pathlib,zipfile,hashlib,io,tempfile,shutil,subprocess,sys,json
ROOT=pathlib.Path(__file__).resolve().parent.parent

def verify_manifest(root):
 count=0
 for line in (root/'SHA256_MANIFEST.txt').read_text().splitlines():
  if not line.strip() or line.startswith('#'):continue
  expected,name=line.split(None,1)
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
  count+=1
 return count

def unpack(path,target):
 blob=path.read_bytes()
 with zipfile.ZipFile(io.BytesIO(blob)) as z:
  assert z.testzip() is None
  for p in z.namelist():
   q=pathlib.PurePosixPath(p)
   assert not q.is_absolute() and '..' not in q.parts,p
  z.extractall(target)

def run(cwd,args,markers):
 p=subprocess.run([sys.executable,'-B',*args],cwd=cwd,capture_output=True,text=True)
 if p.returncode or any(s not in p.stdout+p.stderr for s in markers):
  raise RuntimeError(str(args)+'\n'+p.stdout+'\n'+p.stderr)

print('Bundle SHA256 OK:',verify_manifest(ROOT))
with tempfile.TemporaryDirectory(prefix='t7_r81_replay_') as work:
 w=pathlib.Path(work)
 A=w/'A';B=w/'B';A.mkdir();B.mkdir()
 unpack(ROOT/'entradas/T7_MEASURES_SPEC_R8_1_AUDITOR_A_2026-10-22.zip',A/'origin')
 unpack(ROOT/'entradas/T7_MEASURES_SPEC_R8_1_AUDITOR_B_2026-10-22.zip',B/'source')
 oa=w/'oa';ob=w/'ob'
 unpack(ROOT/'pareceres_originais/T7_MEASURES_AUDITOR_A_SPEC_R8_1_RESULTADO_2026-10-22.zip',oa)
 unpack(ROOT/'pareceres_originais/T7_MEASURES_AUDITOR_B_SPEC_R81_RESULTADO_2026-10-22.zip',ob)
 for d in (A,B):
  shutil.copy2(A/'origin'/'qa_r81_contracts_offline.py',d/'qa_r81_contracts_offline.py')
  shutil.copy2(A/'origin'/'ORIGINAL_R8'/'qa_r8_delta_contracts.py',d/'qa_r8_delta_contracts.py')
 for n in ['01_ESPECIFICACAO_R8.md','02_MATRIZ_QA_R8.md']:
  for d in (A,B):shutil.copy2(A/'origin'/'ORIGINAL_R8'/n,d/n)
 shutil.copy2(oa/'EVIDENCIAS'/'auditor_a_indep_r81.py',A/'auditor_a_indep_r81.py')
 (B/'run').mkdir();(B/'evidence').mkdir()
 shutil.copy2(B/'qa_r81_contracts_offline.py',B/'run'/'qa_r81_contracts_offline.py')
 shutil.copy2(ob/'evidence'/'AUDITOR_B_QA_INDEPENDENTE_R81.py',B/'evidence'/'AUDITOR_B_QA_INDEPENDENTE_R81.py')
 for name,d in [('A',A),('B',B)]:
  run(d,['qa_r81_contracts_offline.py'],['Ran 22 tests','OK'])
  run(d,['qa_r8_delta_contracts.py'],['Ran 30 tests','OK'])
  print(name,'R8.1 22/22 and R8 30/30')
 run(A,['auditor_a_indep_r81.py','--helper','qa_r81_contracts_offline.py','--json','A_results.json'],['1926'])
 assert json.loads((A/'A_results.json').read_text())['assertions']==1926
 run(B,['evidence/AUDITOR_B_QA_INDEPENDENTE_R81.py'],['Ran 44 tests','OK'])
 print('A 1926/1926; B 44/44 expected checks (intentional negative cases included)')
 shutil.copy2(ROOT/'evidencias'/'MASTER_ADVERSARIAL_CHECKS.py',w/'master_adversarial_checks.py')
 run(w,['master_adversarial_checks.py'],['REPRODUCED 12'])
 assert json.loads((w/'MASTER_COUNTEREXAMPLES.json').read_text())['total_checks']==12
 print('Master 12/12 expected observations (some reproduce helper flaws)')
 print('No Blender or .blend used.')
