#!/usr/bin/env python3
"""Reproduce documented R8.1 demonstrator gaps, OFFLINE, stdlib only.
Passing checks means the expected *defect* was reproduced, not compliance.
No Blender imports and no user geometry or external I/O.
"""
import pathlib, json, sys, importlib.util, decimal, fractions
from decimal import Decimal
here=pathlib.Path(__file__).resolve().parent
root=here/'A'
spec=importlib.util.spec_from_file_location('illustrative_only',root/'qa_r81_contracts_offline.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
report={}
def record(label,expect,got):
 report[label]={'expected':str(expect),'observed':str(got),'reproduced':expect==got}
 assert expect==got,(label,expect,got)
# Known failing demonstrator behaviors.
for exponent,p in [(50,3),(60,6),(100,3)]:
 value='1E'+str(exponent)
 try:
  m.outward_bounds(value,value,p)
  got='NO_EXCEPTION'
 except Exception as exc:
  got=exc.__class__.__name__
 record('helper_outward_large_'+str(exponent)+'_p'+str(p),'InvalidOperation',got)
record('helper_accepts_string_flags',('AREA_NOMINAL_PERMITIDO','POSITIVO_COM_FAIXA'), m.mixed_face_state('False','False',('4.9998','5.0002')))
try:
 m.mixed_face_state(True,False,('4.9998','5.0002','extra'))
 got='NO_EXCEPTION'
except Exception as exc:
 got=exc.__class__.__name__
record('helper_invalid_bounds_arity','TypeError',got)
# Use arithmetic independent of the helper for tie position.
for p,expected in [(0,'equal'),(3,'above'),(6,'below')]:
 q=fractions.Fraction(1,10**p)
 f=fractions.Fraction.from_float(float(q/2))
 got='above' if f>q/2 else 'below' if f<q/2 else 'equal'
 record('float_half_even_tie_p'+str(p),expected,got)
# Optional nominal case: valid interval but no nominal may still be displayed as range.
record('interval_without_nominal','POSITIVO_COM_FAIXA',m.checked_interval('4.9998','5.0002',3)[0])
record('demonstrator_nominal_none','SEM_FAIXA',m.checked_nominal(None,'4.9998','5.0002',3))
low,up=m.outward_bounds('-0','.0001',3)
record('negative_zero_display',True,str(low).startswith('-0'))
qa=(here/'B'/'source'/'02_MATRIZ_QA_R8_1.md').read_text(encoding='utf-8')
record('Q23_table_split',True,'\n\n' in qa.split('| R81-Q22 |',1)[1].split('| R81-Q23 |',1)[0])
report['total_checks']=len(report)
(here/'MASTER_COUNTEREXAMPLES.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('REPRODUCED',len(report)-1,'expected observations (some are defects)')
