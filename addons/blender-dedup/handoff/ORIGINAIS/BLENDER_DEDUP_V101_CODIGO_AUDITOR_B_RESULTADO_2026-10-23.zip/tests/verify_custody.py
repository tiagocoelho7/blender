"""Verify original v1.0.1 package embedded in this B audit bundle (read only)."""
from pathlib import Path
import json,hashlib,zipfile,sys
R=Path(__file__).resolve().parents[1]
p=R/'input'
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
m=json.loads((p/'MANIFESTO.json').read_text())
sums={name:h for h,name in (line.strip().split('  ',1) for line in (p/'SHA256SUMS.txt').read_text().splitlines() if '  ' in line)}
errors=[]
for e in m['entries']:
 f=p/e['path']
 if not f.exists() or sha(f)!=e['sha256'] or sha(f)!=sums.get(e['path']) or f.stat().st_size!=e['bytes']:
  errors.append('entry: '+e['path'])
filepaths={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()}
listed={e['path'] for e in m['entries']}|{'MANIFESTO.json','SHA256SUMS.txt'}
if listed!=filepaths:errors.append('entries differ: '+repr(listed^filepaths))
master=p/'originais/master_r2'
mm=json.loads((master/'MANIFESTO.json').read_text())
msums={name:h for h,name in (line.strip().split('  ',1) for line in (master/'SHA256SUMS.txt').read_text().splitlines() if '  ' in line)}
for e in mm['files']:
 f=master/e['path']
 if not f.exists() or sha(f)!=e['sha256'] or sha(f)!=msums.get(e['path']) or f.stat().st_size!=e['bytes']:
  errors.append('Master file: '+e['path'])
for z in (master/'ORIGINAIS').glob('*.zip'):
 with zipfile.ZipFile(z) as f:
  if f.testzip() is not None: errors.append('CRC ZIP '+z.name)
fixed={'src/remover_duplicatas_blend_v1_0_1.py':'1d4175b1190732ea6077232b32d4fd632021f99c9ccb80e5ba15dd5e4dcb9956',
'originais/remover_duplicatas_blend_v1.py':'f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3',
'originais/master_r2/CONGELADOS/ESPECIFICACAO_R1_R5.md':'2d1aa740b4ec7a42307dcec253fbce23f452ad45249fa35585bd12a6da0d3653'}
for name,h in fixed.items():
 if sha(p/name)!=h: errors.append('pin '+name)
output={'gate':'custody','original_entries_verified':len(m['entries'])-len([x for x in errors if x.startswith('entry')]),'original_total':len(m['entries']),
 'nested_master_entries_verified':len(mm['files'])-len([x for x in errors if x.startswith('Master')]),'nested_master_total':len(mm['files']),
 'pinned_hashes':fixed, 'nested_zips_crc_ok':2,'errors':errors}
print(json.dumps(output,ensure_ascii=False,indent=2))
if errors:sys.exit(2)
