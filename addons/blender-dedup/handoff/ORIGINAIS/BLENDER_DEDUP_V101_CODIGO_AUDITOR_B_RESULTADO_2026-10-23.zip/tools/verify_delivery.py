"""Verify this B result directory against SHA256SUMS.txt without writing to it."""
import hashlib,sys
from pathlib import Path
base=Path(__file__).resolve().parents[1]
sums=base/'SHA256SUMS.txt'
problems=[];rows=0
for line in sums.read_text().splitlines():
    h,name=line.split('  ',1)
    f=base/name
    if not f.is_file():problems.append('MISSING '+name)
    elif hashlib.sha256(f.read_bytes()).hexdigest()!=h:problems.append('SHA '+name)
    rows+=1
print('Delivery verified entries:',rows-len(problems),'/',rows,'errors:',problems)
if problems:sys.exit(2)
