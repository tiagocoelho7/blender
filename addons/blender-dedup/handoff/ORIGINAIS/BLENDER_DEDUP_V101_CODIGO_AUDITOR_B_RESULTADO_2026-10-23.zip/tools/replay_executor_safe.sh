#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/evidencias"
cp -a "$here/input/src" "$here/input/qa" "$here/input/originais" "$tmp/"
cd "$tmp"
export PYTHONDONTWRITEBYTECODE=1
python -m unittest discover -s qa -p 'test_candidate_v101.py' -v
python qa/oracle_A_adapted_to_candidate.py src/remover_duplicatas_blend_v1_0_1.py "$tmp/oracle_A_replay.json"
python qa/audit_A_geometry_adapted.py src/remover_duplicatas_blend_v1_0_1.py
python qa/verify_B_graph32_on_candidate.py
BENCH_VERTICES=1000000 python qa/benchmark_v101.py
printf '\nReplay completed strictly in disposable offline sandbox.\n'
