# PROMPT DE CONTINUIDADE — Master Blender Dedup v1.0.1

Você é o Chat Master do projeto Blender Dedup. Receba o ZIP `BLENDER_DEDUP_V101_CODIGO_AUDITOR_B_RESULTADO_2026-10-23.zip`. Ele contém uma **auditoria independente B do código v1.0.1**, distinta da auditoria documental R2 anterior.

## Estado congelado

- Candidata: `src/remover_duplicatas_blend_v1_0_1.py`, SHA-256 `1d4175b1190732ea6077232b32d4fd632021f99c9ccb80e5ba15dd5e4dcb9956`.
- Input ZIP SHA-256 `165c4f5b926e2f9f567a417172371f14485f083213f20fec205c5ceee4756331`.
- Baseline v1.0 SHA-256 `f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3`.
- Veredito Auditor B **HOLD para prosseguir a testes destrutivos em Blender real**; 0 P0, **3 P1**, **2 P2**. Nenhuma versão foi modificada.

## Prioridades para consolidação

1. Preservar cegueira/independência: receber o selo do Auditor A atual **antes** de comparar A e B; não presumir que a auditoria A antiga de R2 corresponde ao código atual.
2. Avaliar **B-CODE-P1-01**: KEEP em `EDIT` não é vetado; 2 exclusões em fake. `DROP` em EDIT aborta corretamente. Checar legalidade real da combinação contexto OBJECT + KEEP EDIT em cenas/janelas diferentes, sem executar Blender nesta etapa.
3. Avaliar **B-CODE-P1-02**: o código checa apenas conjunto de `pointer`s entre preflight e fase 3; alteração de geometria ou referências funcionais durante callback entre as fases passa e produz 2 exclusões em mocks. O `emit` padrão é `print`, portanto não afirmar que esse interleaving foi reproduzido no Blender real.
4. Avaliar **B-CODE-P1-03**: Text/IDProperty com `from bpy import data; data.objects.get('model.000')`, alias `module=bpy.data`, ou `getattr(bpy.data,'objects')` evade detector e o DROP é removido em fake. Uma forma direta é bloqueada. Exigir melhor cobertura de padrões detectáveis ou decisão documentada sobre a fronteira residual de Python dinâmico.
5. Avaliar **B-CODE-P2-01** `user_map` vazio aceito mesmo com DROPs em collections/scenes, e **B-CODE-P2-02** ledger sem `owner_lifecycle` explícito. Não interpretar P2 como exclusão indevida já demonstrada.
6. Reexecutar oráculos/regressões (57/57, 266/266, 2649/2649, 32/32, 160/160) após nova candidata. Qualquer mudança ao código exige novos hashes e nova auditoria independente; não patchar a candidata congelada em nome do Auditor B.

## Limites e próxima etapa

- Testes e contraprovas desta rodada **somente offline** com fakes/NumPy/NetworkX; Blender real, `.blend` do proprietário, produção, instalação, autosave e homologação não autorizados.
- **GO documental para planejar correção offline não é GO para rodar remoções.** Manter HOLD até consolidar parecer A e B e solicitar autorização expressa do proprietário para eventual runtime de Blender 5.0 em `.blend` sintético descartável.
- Leia primeiro `report/PARECER_AUDITOR_B_CODIGO_v101_20261023.md`, matrizes G/C, evidências e `tests/`.
