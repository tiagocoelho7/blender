# AUDITOR B — Auditoria independente CEGA do CÓDIGO Blender Dedup v1.0.1

Você é o Auditor B independente. Esta é uma **nova implementação executável**, não uma análise documental do plano. Faça auditoria adversarial da exclusão automática, sem acessar o Auditor A desta rodada.

## Entrada e custódia

1. Leia `README.md`, `docs/MATRIZ_G01_G14_CANDIDATA.md`, `docs/COBERTURA_RNA.md`, `docs/CROSSWALK_C01_C24.md`.
2. Confira `src/remover_duplicatas_blend_v1_0_1.py`, `docs/DIFF_V1_V101.patch`, especificação R1–R5 e adendo R2 em `originais/master_r2/CONGELADOS/`.
3. Valide `SHA256SUMS.txt`/`MANIFESTO.json` e integridade dos originais. Não modifique a candidata congelada.

## Missão primária

Audite G01/G02/G03/G04/G08/G09/G10/G13: verificabilidade do inventário RNA, IDProperties aninhadas, drivers em Materials/World, owners non-Object, Nodes/NodeTree embedded/shared/orphan, Geometry Nodes, Scene/Collection, `user_map(subset=...)` e references não mapeadas. Teste especialmente se **qualquer** owner sobrevivente pode referenciar um DROP e o programa excluí-lo silenciosamente, e se simples membership em cenas/collections é indevidamente tratada como dependência funcional.

Atacar casos C01–C24, F01–F32, parent/children, modifier/constraint target, instancing transitivo, linked/local, override, readonly, editor EDIT, shape keys vs modifiers, Mesh datablock compartilhado e classificação de KEEP sem reranking por elegibilidade. Examine RNA Blender 5.0 na documentação **sem executar Blender real**; tipos RNA inacessíveis devem tornar o plano inconclusivo em vez de seguros.

Audite ledger, garantias de ZERO remove em qualquer falha da fase 1/2, erro logger, KeyboardInterrupt, falha antes/depois de side effect do `objects.remove`, sessão UID/rename/reuse, handlers que alteram dependências. Verifique `no autosave` e ausência de remapeamento de ponteiros. Procure bypasses de acessos dinâmicos a nomes em scripts internos/exteriores e relate explicitamente que inspeção estática não é prova perfeita.

Não aceite placeholders, uma exceção como confirmação de segurança, ou teste fake como demonstração de que API real existe. Reexecute as suítes do executor em cópia, e escreva contraprovas próprias. Distingua um falso positivo de um ABORTO conservador.

## Não autorizado

NÃO executar bpy/Blender real, `.blend` do proprietário, exclusão real, salvar, instalar, alterar originais ou ler auditoria atual A. Prova Blender real é etapa futura sob autorização explícita.

## Saídas

Retorne **ZIP autossuficiente**, parecer **GO/HOLD/INCONCLUSIVO para prosseguir a testes**, severidades P0/P1/P2, testes/logs/código de contraprovas, matriz G01–G14 e C01–C24, custódia/hashes e prompt de continuidade ao Chat Master. Não dar GO para produção nem homologação real.
