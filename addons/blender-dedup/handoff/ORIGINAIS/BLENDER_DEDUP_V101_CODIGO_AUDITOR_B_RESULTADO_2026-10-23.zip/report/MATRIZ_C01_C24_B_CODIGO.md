# Matriz C01–C24 — Auditor B código novo

A base C01–C24 provém do kit documental antigo e foi reexecutada parcialmente via F01–F32 do executor. A coluna `Resultado` distingue presença de prova sintética e novas falhas B. Nenhuma linha é homologação Blender 5.0.

| C | Escopo verificado / ponte para QA | Resultado B |
|---|---|---|
| C01 | Remoção básica/ranking F01 | PASS-SYN |
| C02 | Multi-scene F03 | PASS-SYN |
| C03 | Filho → pai DROP F04 | PASS-SYN |
| C04 | Constraint para DROP F05 | PASS-SYN |
| C05 | Driver Material F06 | PASS-SYN |
| C06 | Modifier.object apontando DROP F08 | PASS-SYN; **B03** adiciona após preflight sem novo bloqueio |
| C07 | IDProperties aninhadas com ID pointer F07 | PASS-SYN; **B09** bypass de STRING com alias |
| C08 | Owner non-MESH F30 | PASS-SYN |
| C09 | `Scene.camera` MESH/TimelineMarker.camera e legalidade do RNA | **INCONCLUSIVO REAL**, fixture não homologada |
| C10 | Collection instanciada F09 | PASS-SYN |
| C11 | Collection Info via NodeTree F10 | PASS-SYN; tipos reais não verificados |
| C12 | Outgoing DROP → KEEP F14 | PASS-SYN |
| C13 | DROP linked F18 | PASS-SYN |
| C14 | DROP override F20 | PASS-SYN |
| C15 | DROP readonly F19 | PASS-SYN |
| C16 | Mesh compartilhada F23 | PASS-SYN, remove apenas Object no mock |
| C17 | Grupo inseguro depois de seguro F25 | PASS-SYN, preflight integral impede parcial de fase 1/2 |
| C18 | Budget patológico Rook × Shrikhande | PASS-SYN (INCONCLUSIVO tipado, não falso igual) |
| C19 | DROP em EDIT F24 | PASS-SYN; **B01** demonstra KEEP em EDIT não validado |
| C20 | `user_map` divergente F29 | PASS-SYN; **B08** mapeamento vazio aceito apesar dos owners conhecidos |
| C21 | KEEP linked/readonly F22 | PASS-SYN condicional; runner real pendente |
| C22 | Text lookup F17 + teste alias do executor | **HOLD**: **B05–B07/B09** encontram aliases não detectados |
| C23 | Falha `remove` após side effect; KeyboardInterrupt | PASS-SYN; rollback não prometido |
| C24 | Falha na última remoção, ledger parcial | PASS-SYN; reconciliação real pendente |

Legenda: **PASS-SYN** = esperado em harness sintético; não é prova de Python API Blender. **Bxx** = contraprova independente nova. Para rastreabilidade, ver `evidence/*` e `tests/*`.
