# Custódia, delimitação e procedimento

## Originais

1. Recebida a entrada `/mnt/data/BLENDER_DEDUP_V101_CODIGO_AUDITOR_B_2026-10-22.zip`, SHA-256 `165c4f5b926e2f9f567a417172371f14485f083213f20fec205c5ceee4756331`.
2. Extração controlada para `input/` sem links simbólicos, paths absolutos ou `..`.
3. `MANIFESTO.json` e `SHA256SUMS.txt` conferidos. Resultado: 62/62; `originais/master_r2/MANIFESTO.json` interno 33/33; dois ZIPs internos CRC OK.
4. O diff `docs/DIFF_V1_V101.patch` foi aplicado apenas em cópia da baseline, reconstruindo o SHA-256 exato da candidata `1d4175b1190732ea6077232b32d4fd632021f99c9ccb80e5ba15dd5e4dcb9956`.
5. Os testes do executor foram reexecutados em `replay/` temporário com cópias do `src/`, `qa/` e `originais/`; estes arquivos temporários não integram o bundle final.
6. Contraprovas do Auditor B residem em `tests/`, evidências em `evidence/`. O código de candidato em `input/src` foi apenas importado em ambiente offline e não recebeu patch.

## Limitações metodológicas

- Não usamos `bpy`, Blender 5.0 real, interface GUI, arquivos `.blend` do proprietário ou testes destrutivos reais.
- As classes Blender fake usadas em testes B vieram do harness que acompanha a candidata; **os oráculos e asserts novos são independentes, mas a compatibilidade legal dos mocks com Blender 5.0 segue não demonstrada**.
- O teste adversarial de mutação usa o callback `emit`, que o executor deixa injetável para QA; isso mostra a ausência de proteção sob alteração adversarial, não prova que `print()` modifica Blender real.
- Não lemos auditoria A da atual rodada de código. A R2 documental anterior está preservada no kit, mas não foi usada como prova da implementação.
- O sucesso da bateria automática representa apenas os casos cobertos. Uma falha de runtime ainda pode ser conservadora (aborto sem exclusão) em vez de bug de exclusão indevida.

## Referências API Blender 5.0 consultadas (sem executar)

- `BlendData.user_map`: https://docs.blender.org/api/5.0/bpy.types.BlendData.html
- `BlendDataObjects.remove`: https://docs.blender.org/api/5.0/bpy.types.BlendDataObjects.html
- `ID.session_uid`, `ID.is_editable`: https://docs.blender.org/api/5.0/bpy.types.ID.html
- `Context.mode`: https://docs.blender.org/api/5.0/bpy.types.Context.html
