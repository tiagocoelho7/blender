# Matriz G01–G14 — Auditor B, implementação v1.0.1

**Estado principal:** `PASS-OFFLINE` valida lógica simulada/estática, **não** API Blender real. `HOLD` = falta requisito relevante para avançar ao runtime. `PARCIAL` = a prova em mocks não generaliza ao runtime.

| Gate | Estado | Prova nova / observação de independência |
|---|---|---|
| G01 Inventário incoming | **HOLD / PARCIAL** | Referências diretas, IDProps e coleções bloqueadas nos mocks; **B03/B04** demonstram mutação de entrada depois do inventário, sem recheck |
| G02 Membership/instancing | **PASS-OFFLINE; REAL PENDENTE** | F02/F03/F09/F11/F31 do executor reexecutados; falso positivo de membership não visto em mocks |
| G03 RNA nested, NodeTree, user_map | **PARCIAL** | Driver, nodes orphan, IDProperties exercitados; **B08** aceita `user_map={}` sem provar corroborar DROPs com owners; RNA efetivo não validado |
| G04 Ausência de remap | **PASS-ESTÁTICO** | Script chama `blend_data.objects.remove(obj, do_unlink=True)` sem implementar remapeamento explícito; documentação API preservada |
| G05 Comparação exata/topologia | **PASS-OFFLINE** | Oráculo A 266/266; geometria A 2649/2649; oráculo independente B 160/160, vértices coincidentes |
| G06 Budget/fail-closed | **PASS-OFFLINE; REAL PENDENTE** | Rook vs Shrikhande inconclusivo por limite, sem falso positivo; crescimento RSS/tempo não são hard caps; benchmark sintético 1M vértices |
| G07 C01–C24 e negativos | **PARCIAL** | 32/32 F01–F32 executor; C09 hipotético, C22 contornado em B05–B07/B09 |
| G08 Ranking absoluto | **PASS-OFFLINE** | Prioridade modifiers > shape keys > nome; KEEP não é reranqueado por elegibilidade |
| G09 Eligibility/modes/linked/shared | **HOLD** | O DROP em EDIT aborta; **B01** KEEP em EDIT com `context_mode='OBJECT'` passa em mock |
| G10 Ledger/partial/reconciliation | **HOLD / PARCIAL** | Exceções simuladas do executor passam, porém B02–B04 mostram plano obsoleto não detectado na janela pré-remover; ledger carece de `owner_lifecycle` explícito |
| G11 Cadeia de custódia | **PASS** | Input 62/62; Master R2 33/33; dois ZIPs internos CRC OK; diff reconstruído igual ao source exato |
| G12 Float32/NaN/Inf/overflow | **PASS-OFFLINE** | QA e oráculos validados, sem alegar equivalência na precisão nativa |
| G13 Lookup dinâmico em Text/IDProps | **HOLD** | Padrão direto bloqueado, aliases triviais contornam; cobertura perfeita de scripts externos assumida impossível |
| G14 Proibição de Blender real | **PASS** | Todos os ensaios usaram Python fake/NumPy; código original não executado em Blender real |

**Gate agregado: HOLD para avançar a testes destrutivos no Blender real**. Permanece autorizado apenas diagnóstico offline, com futura nova candidata sob decisão do Master.
