# PARECER INDEPENDENTE B — Blender Dedup v1.0.1 — CÓDIGO

Data da rechecagem: **23/10/2026**. Papel: **Auditor B independente (somente leitura)**.

## 1. Veredito

**HOLD para avançar ao gate de testes destrutivos no Blender 5.0.0, mesmo em `.blend` descartáveis, nesta candidata tal como recebida.**

- **P0 confirmado:** 0.
- **P1 (requer correção/reavaliação):** 3 achados, com as hipóteses de alcance claramente delimitadas abaixo.
- **P2 (melhorias de verificabilidade):** 2 achados.
- **GO restrito:** é possível continuar auditoria e testes offline, sem modificar originais nem executar `bpy.data.objects.remove` no Blender real.
- **Produção:** HOLD, sem autorização implícita.

As 3 contraprovas P1 foram reproduzidas *contra o código v1.0.1 efetivo*, não apenas contra o plano documental. Todas as chamadas de remoção das contraprovas se deram em estruturas **fake de Python**, não no Blender; essa distinção é essencial. Os casos de alteração durante o ledger requerem condição externa de mutação/callback, e sua plausibilidade e comportamento físico no Blender real permanecem não validados.

## 2. Custódia e baseline

- Arquivo fornecido: `BLENDER_DEDUP_V101_CODIGO_AUDITOR_B_2026-10-22.zip`.
- SHA-256 do arquivo fornecido: `165c4f5b926e2f9f567a417172371f14485f083213f20fec205c5ceee4756331`.
- Manifesto da entrada: **62/62 arquivos conferidos** quanto a nome, tamanho e SHA-256; `SHA256SUMS.txt` concordante; total 64 entradas incluindo manifesto e sums.
- Handoff Master R2 interno: **33/33 entradas conferidas**, dois ZIPs de auditoria anteriores sem falha de CRC.
- Baseline v1.0 preservada: `f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3`.
- Especificação R1–R5: `2d1aa740b4ec7a42307dcec253fbce23f452ad45249fa35585bd12a6da0d3653`.
- Candidata v1.0.1: `1d4175b1190732ea6077232b32d4fd632021f99c9ccb80e5ba15dd5e4dcb9956`.
- O diff fornecido, aplicado **somente à cópia** da baseline, reproduziu exatamente os bytes e o hash da candidata.
- Os arquivos originais dentro do ZIP do proprietário não foram editados, e a candidata não foi patched.

Reprodução: `python tests/verify_custody.py`; evidência: `evidence/custody_verification.json`, `evidence/reconstruct_patch.log`.

## 3. Achados bloqueantes / P1

### B-CODE-P1-01 — KEEP em EDIT não recebe veto de segurança

**Local:** `src/remover_duplicatas_blend_v1_0_1.py`, `_check_object_flags` (aprox. linhas 1036–1063), `preflight` (aprox. 1176–1200).

**Contrato:** AD-R2-04 requer aborto quando objeto candidato afetado está em EDIT ou seus dados estão potencialmente desatualizados; o gate G09 exige classificar KEEP/DROP/Mesh. O script verifica `mode != 'OBJECT'` **apenas para DROP**. A checagem `context_mode == 'OBJECT'` não equivale a checar o estado de todos os candidatos globalmente.

**Contraprova B01:** no mock, marcar o KEEP vencedor `model.001` como `mode='EDIT'`, manter os dois DROPs `OBJECT` e `context_mode='OBJECT'`. Resultado observado: `REMOVOES_CONFIRMADAS` e **2 chamadas `objects.remove`**. Controle positivo: marcar DROP `model.000` como `EDIT` gera aborto com **0** chamadas.

**Risco:** a malha base consultada pode não refletir o estado real de edição do vencedor, ou a combinação ser operacionalmente inválida; a regra de seguro global não está implementada no código. **Limite:** ainda não provamos que Blender 5.0 permite `bpy.context.mode='OBJECT'` enquanto um KEEP de outra cena permanece em `EDIT`; o teste mostra divergência lógica da validação e exige pesquisa/teste autorizado do estado real, não prova dano real.

**Correção exigida à equipe:** determinar e validar política de modo coerente para todos os MESH candidatos (KEEP e DROP), inclusive múltiplas cenas/view layers; abortar quando estado não confiável. Sem reordenar a prioridade absoluta R2.

### B-CODE-P1-02 — Janela entre preflight e remove não garante estabilidade das dependências/geometria

**Local:** `execute` (aprox. linhas 1252–1284). Depois de `emit('[T7-DEDUP-LEDGER-PRE]', plan)`, o script reenumera **somente** os `pointer` de `bpy.data.objects`. Não revalida grafo de referências, flags, dados da malha nem snapshots completos.

**Contraprovas B02, B03 e B04:** callback sintético `emit` altera, respectivamente, coordenadas da malha do DROP; um `Modifier.object` de EMPTY sobrevivente para apontar ao DROP; e `Object.parent` de EMPTY sobrevivente para apontar ao DROP. Nenhuma dessas alterações muda o conjunto de ponteiros dos Objects. Resultado observado em todos os três: **2 chamadas `remove` e `REMOVOES_CONFIRMADAS`**, embora o plano inicial já não represente o estado usado na exclusão.

**Risco:** exclusão de malha que deixou de ser duplicada ou `do_unlink=True` anulando dependência funcional criada após a avaliação. **Limite importante:** `emit` do `run_blender()` real é impressão em console e **não modifica o arquivo**. Os testes provam que a guarda de ponteiros é insuficiente sob *mutação reentrante/injetada*, mas **não demonstram** que handlers normais do Blender realizam esse interleaving. O risco já era listado como residual na documentação R2, porém o campo do preflight que afirma detectar “mutation before deletion” é mais amplo do que a checagem realizada.

**Correção exigida:** especificar fronteira de mutação/reentrância e implementar revalidação efetiva dos invariantes críticos imediatamente antes do primeiro `remove` (e, se relevante, entre chamadas), ou formular um contrato explícito de execução exclusiva, com plano de teste de handlers no Blender sob futura autorização. Não afirmar atomicidade impossível.

### B-CODE-P1-03 — Bypasses triviais no detector de referências por nome

**Local:** `_DANGEROUS_NAME_LOOKUP` e `_text_lookup_risk`, aproximadamente linhas 741–821; `_scan_text`, 993–1009; `_scan_idprops`, 883–924.

**Contraprovas B05–B07 e B09:** o Text ou IDProperty armazena código que consulta `model.000` por:

```python
module = bpy.data
ref = module.objects.get('model.000')
```

```python
from bpy import data
ref = data.objects.get('model.000')
```

```python
ref = getattr(bpy.data, 'objects').get('model.000')
```

Em todos esses casos, `_text_lookup_risk` retornou `False` e a candidata chegou a **2 remoções**. A forma direta `bpy.data.objects['model.000']` foi bloqueada com **0** remoções (controle B-CTRL-DIRECT). O mesmo alias `from bpy import data; data.objects.get('model.000')` em **IDProperty aninhada** também passou (B09).

**Risco:** scripts armazenados no `.blend` ou metadata de automações podem referir-se por nome a DROPs; excluir o objeto altera sua semântica. **Limite:** inspeção estática finita não consegue capturar acesso arbitrário via Python externo; isso já era um risco aceito documentalmente, e código num Text não é necessariamente executado. Este achado é **mais restrito**: variantes sintáticas simples do padrão detectado escapam à regra declarada de “incerto detectável ⇒ aborto”, o que precisa de decisão explícita.

**Correção exigida:** ampliar o detector de aliases conhecidos sem alegar completude para Python arbitrário, ou vetar preventivamente documentos contendo padrões de acesso a objetos que não se pode resolver; manter risco residual de scripts externos aberto ao proprietário.

## 4. Achados de verificabilidade / P2

### B-CODE-P2-01 — Cruzamento `user_map` aceita mapeamento vazio apesar de DROP com users descobertos

**Local:** `_user_map_corroborate`, aprox. linhas 1119–1137.

Em B08, o fake `user_map(subset=drops)` retornou `{}` apesar de collections e scenes observadas pelo scanner. O código só itera entradas devolvidas, não exige evidência para cada DROP; resultou **2 remoções confirmadas**. **Não** é demonstração isolada de referência funcional perdida: as referências funcionais detectadas no scanner continuam abortando, independentemente de `user_map`. É lacuna de rigor da validação cruzada G03, cuja semântica efetiva da API precisa ser confirmada em Blender real.

**Ação:** exigir coerência entre conjunto esperado de chaves/usuários documentado pela API e saída real, distinguindo legítimos IDs sem usuários de resultado truncado/falso.

### B-CODE-P2-02 — Ledger de owners incompleto para contrato R2

**Local:** `Reference.record` aprox. 721–741, `_ledger` aprox. 1153–1175.

O relatório de referências inclui `owner` e `target` em snapshots, caminho, superfície e categoria, porém não apresenta **campo explícito `owner_lifecycle`** (KEEP/SURVIVE/DROP), `drop_key` nem evidência completa de cobertura observável *antes de abortos*. `inventory.uninspected` inicia e retorna lista vazia, enquanto `excluded_by_assumption` registra hipóteses. Isto prejudica rastreabilidade de G01 e revisão externa da taxonomia; não é, por si só, prova de exclusão insegura.

**Ação:** alinhar esquema do ledger ao AD-R2-01, emitir resumo de motivo/owner/alvo para abortos antes de remover e deixar clara a diferença entre `uninspected` vazio e cobertura efetivamente comprovada no Blender.

## 5. Testes efetivamente executados

| Ensaio | Evidência | Resultado |
|---|---|---|
| Executor unittest sintético | `evidence/qa_executor_replay.log` | **57/57** PASS |
| Oráculo independente A adaptado à candidata | `evidence/oracle_A_replay.log` e `.json` | **266/266** PASS |
| Geometria antiga A adaptada à candidata | `evidence/geometry_A_replay.log` | **2.649/2.649** PASS |
| Contratos de grafo B R2 sobre candidata | `evidence/B_graph32_replay.log` e `.json` | **32/32** PASS |
| Adversarial independente B (efeitos/aliases/KEEP) | `evidence/independent_B_adversarial.log` | **11/11 ensaios executados; 7 demonstram condições problemáticas, 4 são controles** |
| Rechecagem B `user_map`/IDProperties | `evidence/independent_B_crosscheck.log` | **2/2 ensaios executados, ambos revelam lacunas** |
| Oráculo independente NetworkX, vértices coincidentes | `evidence/independent_B_geometry_oracle.log` | **160/160** concordâncias |
| Benchmark NumPy (1M vértices cada, sem faces) | `evidence/benchmark_1M_replay.log` | Igualdade após reindexação; 0,771s nesta execução, sintético |
| Adversarial Rook vs Shrikhande | mesmo log | **ABORT_INCONCLUSIVE_NO_DELETE** após limite de 751 estados; **não é falso PASS** |
| Custódia e reconstrução do diff | `evidence/custody_verification.json`, `evidence/reconstruct_patch.log` | Manifestos conferidos; diff byte-identical |

**Atenção:** “11/11” e “2/2” indicam testes que executaram suas asserções com sucesso, **não** ausência de vulnerabilidades. Eles foram escritos para comprovar efeitos observados, inclusive os inseguros. Simulações em fake não validam RNA ou operação do Blender 5.0.

## 6. Gates e C01–C24

Ver `MATRIZ_G01_G14_B_CODIGO.md` e `MATRIZ_C01_C24_B_CODIGO.md`.

- G05, G06, G08, G11, G12: resultados offline positivos.
- G01, G09, G10, G13: bloqueios/pendências por P1 em código.
- G03/G07: parte da descoberta e cruzamento permanecem não verificados no Blender real, com P2 do `user_map` e C09 hipotético.
- G02/G04/G14: coerentes em revisão estática/sintética com limitações declaradas.
- C22 possui teste executor que passa no caso fácil, mas **não** cobre B05–B07/B09.

## 7. Garantias NÃO demonstradas nesta rodada

1. Propriedades RNA e legalidade de `Scene.camera`, `TimelineMarker.camera`, `NodeTree` embedded, sockets de Geometry Nodes e IDs órfãos **em Blender 5.0 real**; mocks não provam estrutura real.
2. Integridade em presença de handlers/callbacks que alteram a cena entre planejamento e remoção.
3. Detecção perfeita de scripts internos/externos e aliases arbitrários; impossível prometer.
4. Tempo/memória efetivos em `.blend` volumosos; benchmark NumPy não é equivalência de performance real.
5. Rollback, atomicidade, recuperação automática de uma remoção parcial; não implementados e não prometidos.

Documentação oficial de API consultada (sem execução):
- https://docs.blender.org/api/5.0/bpy.types.BlendData.html (semântica de `user_map`)
- https://docs.blender.org/api/5.0/bpy.types.BlendDataObjects.html (`remove(do_unlink=True)`)
- https://docs.blender.org/api/5.0/bpy.types.ID.html (`session_uid`, `is_editable`)
- https://docs.blender.org/api/5.0/bpy.types.Context.html (escopo de `Context.mode`)

## 8. Orientação ao Chat Master

1. Manter a v1.0.1 congelada; remeter B-CODE-P1-01/02/03 ao executor para nova proposta com código e casos regressivos específicos, e B-CODE-P2-01/02 para melhoria de prova/ledger.
2. Não combinar auditoria deste Auditor B com a do Auditor A atual **antes de preservar a independência/seus selos**.
3. Depois da nova candidata, realizar reauditoria cega A/B com provas próprias. GO offline não é homologação de Blender real.
4. Solicitar autorização futura específica do proprietário para teste de Blender 5.0 somente em `.blend` sintéticos e descartáveis; produção continua HOLD.

**Declaração de independência:** auditoria desta rodada não leu qualquer parecer do Auditor A sobre esta candidata de código v1.0.1. A presença de A R2 documental antigo no pacote original não o torna “auditoria A atual”. Nenhum arquivo `.blend` do proprietário foi aberto, salvo ou modificado. Nenhuma chamada real a `bpy` foi realizada.
