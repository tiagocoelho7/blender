# AUDITOR B — Blender Dedup v1.0.1 — Código (23/10/2026)

**VEREDITO: HOLD** para avançar a testes destrutivos no Blender 5.0.0. Nenhuma execução em Blender real ou arquivo `.blend` do proprietário foi realizada.

O pacote contém:

- `input/`: **cópia bit a bit dos 64 arquivos extraídos** do ZIP original, incluindo fontes, manifestos, QA, documentação e referências históricas. Não modificar.
- `report/PARECER_AUDITOR_B_CODIGO_v101_20261023.md`: conclusões e achados **3× P1**, **2× P2**.
- `report/MATRIZ_G01_G14_B_CODIGO.md`: 14 gates.
- `report/MATRIZ_C01_C24_B_CODIGO.md`: 24 contratos.
- `report/CUSTODIA_E_METODOLOGIA.md`: procedimento e limitações.
- `tests/`: 13 contraprovas/controlos de segurança, oráculo 160 casos, verificador de custódia.
- `evidence/`: logs do replay 57 + 266 + 2.649 + 32, contraprovas B, benchmark e custódia.
- `tools/`: reexecução em cópia temporária e verificação do pacote de saída.
- `PROMPT_CONTINUIDADE_MASTER.md`: encaminhamento ao Master.
- `FINDINGS.json`: sumário legível por máquina.
- `SHA256SUMS.txt`/`MANIFESTO_AUDITOR_B.json`: hashes e inventário.

## Como reproduzir sem tocar nos originais

Requisitos: Python 3.10+, NumPy; para o oráculo independente e benchmark, NetworkX. O código da candidata é importado sem `bpy`.

```bash
PYTHONDONTWRITEBYTECODE=1 python tests/verify_custody.py
PYTHONDONTWRITEBYTECODE=1 python tests/independent_B_adversarial.py -v
PYTHONDONTWRITEBYTECODE=1 python tests/independent_B_crosscheck.py -v
PYTHONDONTWRITEBYTECODE=1 python tests/independent_B_geometry_oracle.py
PYTHONDONTWRITEBYTECODE=1 python tools/verify_delivery.py
bash tools/replay_executor_safe.sh
```

O script replay cria um diretório descartável, copia apenas os arquivos necessários, executa as cinco suítes do executor, exibe os resultados e remove o diretório temporário. Não importa `bpy` real e não salva arquivos `.blend`.

**NÃO executar** `input/src/remover_duplicatas_blend_v1_0_1.py` dentro do Blender; no runtime real ele remove objetos MESH automaticamente após preflight.

## Principais resultados

- **11/11** testes adversariais B executados com sucesso: **7 confirmaram comportamentos que exigem correção/reavaliação**, e 4 validaram controles seguros.
- **2/2** testes adicionais de `user_map` e IDProperties: ambos confirmaram lacunas.
- **160/160** verificações geométricas adicionais concordaram com NetworkX.
- Testes fornecidos pelo executor reexecutados: **57/57; 266/266; 2.649/2.649; 32/32**.
- Benchmark sintético de 1 milhão de vértices por malha: reindexação correta; Rook×Shrikhande inconclusivo seguro por budget.
- Custódia: 62/62 manifestos da candidata, 33/33 do Master R2, diff reconstituído exatamente.

**Limite:** testes fake não comprovam reachability no Blender real de `context_mode=OBJECT` enquanto um KEEP está em EDIT, tampouco mutação via callbacks durante o ledger. O HOLD evita interpretar testes sintéticos como autorização de exclusões reais.
