# AUDITOR A — Auditoria independente CEGA do CÓDIGO Blender Dedup v1.0.1

Você é o Auditor A independente. Esta é uma **nova implementação executável**, não uma análise documental do plano. Faça auditoria hostil à segurança de uma candidata para Blender 5.0.0, sem acessar outros auditores ou seus resultados desta rodada.

## Entrada e custódia

1. Leia `README.md` e `docs/MATRIZ_G01_G14_CANDIDATA.md`, `docs/PARECER_EXECUTOR.md`, `docs/LIMITES_E_RISCOS.md`.
2. Leia `originais/master_r2/CONGELADOS/ESPECIFICACAO_R1_R5.md`, plano R1, adendo Master R2, e compare `src/remover_duplicatas_blend_v1_0_1.py` com `originais/remover_duplicatas_blend_v1.py` por hash+diff.
3. Confira integralmente `MANIFESTO.json`/`SHA256SUMS.txt`, inclusive origem da baseline congelada. Preserve todos os arquivos originais. Nunca altere a candidata no lugar.

## Missão primária

Audite G05/G06/G07/G12: isomorfismo por bijeção **global** dos vértices após quantização float32 em cinco casas, faces orientadas modulo rotação cíclica, arestas não direcionadas e multiplicidades. Atacar falso negativo por renumeração, falso positivo por posição coincidente com topologia distinta, n-gons 14/17+, 2 ciclos, arestas duplicadas/soltas, face-only hypergraph, orientação SEM-01, 6+8 versus 7+7 e Rook versus Shrikhande. Comparar com oráculo matemático INDEPENDENTE, não derivado do código de produção.

Investigue limites de tempo/memória: pré-alocações, NP/NumPy, backtracking, número de estados/pares, orçamentos per-pair/global, RSS e falhas antes do primeiro delete. Se o algoritmo não puder concluir um par, deve abortar o arquivo inteiro com ZERO chamadas a `objects.remove`, nunca responder `False` só por timeout. Verifique normalização de coordenadas, NaN/Inf/overflow inclusive shared pointer.

Avalie o impacto em milhões de vértices e meshes com topology/quantização patológica, distinguindo valores de CPU/RSS em fake de Blender real. Execute os testes que couberem OFFLINE em cópias, adaptando fixtures adicionais próprios. Não assuma que os números QA do executor são evidência suficiente; reexecute e ataque.

## Não autorizou

NÃO executar Blender real, bpy real, `.blend` de usuário, deleções reais, salvar projeto, modificar candidato ou usar conclusões do Auditor B. Não modificar os hashes congelados. Nunca instalar esta candidata em produção.

## Saídas

Retorne um **ZIP próprio autossuficiente** com relatório técnico completo e veredito **GO/HOLD/INCONCLUSIVO apenas PARA AVANÇAR À ETAPA SEGUINTE DE TESTES**, severidade P0/P1/P2, contraprovas/minimal repros e oráculos independentes, logs e hashes. Separe claramente QA sintético de teste Blender (não realizado); inclua prompt de continuidade ao Master. Não proclame homologação do código apenas por passar em 2.649/266 testes preexistentes.
