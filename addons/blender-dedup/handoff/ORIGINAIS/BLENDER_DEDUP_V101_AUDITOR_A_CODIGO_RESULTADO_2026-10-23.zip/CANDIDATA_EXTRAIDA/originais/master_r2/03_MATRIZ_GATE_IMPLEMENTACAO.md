# Matriz Master G01-G14 para a futura candidata

Situacao atual: 14/14 SUFICIENTE DOCUMENTAL pelos auditores A e B; ZERO evidencias de execucao da candidata v1.0.1. Esta matriz nao e declaracao de PASS funcional.

| Gate | Aceite de implementacao (exigir logs/testes) |
|---|---|
| G01 | Inventario de incoming references por DROP/owner/lifecycle/RNA-path/tipo; desconhecido/incompleto => zero remove |
| G02 | Membership simples em multi-collection/multi-scene e permitido; Collection instanciada/consumida por sobrevivente bloqueia transitivamente |
| G03 | RNA nested, drivers Materials e outros IDs, IDProperties nested, NodeTrees embedded/shared/orphan e user_map cruzado |
| G04 | Zero remapeamento de referencias por equivalencia da geometria |
| G05 | Bijeção global de vertices, faces orientadas, SEM-01 valido e winding distinto negativo |
| G06 | Budgets quantitativos de tempo/estados/memoria global/par, checagem antes das alocacoes, inconclusivo => aborto |
| G07 | Oraculo independente, contraexemplos, n-gons grandes, vertice coincidente, C01-C24 e regressao A/B na nova candidata |
| G08 | Ranking absoluto modifiers > shape keys > nome, sem trocar KEEP por elegibilidade |
| G09 | KEEP/DROP/Mesh com linked/readonly/override/indirect/EDIT/shared mesh/multi-scene classificados corretamente |
| G10 | Ledger pre-delete; reconciliacao tripla e parada da fase 3 em excecoes antes/depois de efeito |
| G11 | Baseline/R1-R5/R1/R2 intocados; nova candidata + diff + hashes; Blender real separado |
| G12 | Quantizacao float32/np.rint 5 casas, fronteiras, NaN/Inf/overflow, alias de Mesh |
| G13 | Text/driver dinamico detectavel incerto => aborto; risco de scripts externos residual e documentado |
| G14 | Runtime Blender 5.0 real requer autorizacao explicita; nesta fase nenhum acesso |

Nao aceitar resultados sinteticos dos auditores anteriores como provas da nova candidata.
