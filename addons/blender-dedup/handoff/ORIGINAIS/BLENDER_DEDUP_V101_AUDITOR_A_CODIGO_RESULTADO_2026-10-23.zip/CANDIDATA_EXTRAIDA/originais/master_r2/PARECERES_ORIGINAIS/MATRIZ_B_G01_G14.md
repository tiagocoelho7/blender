# Matriz de aceitacao G01-G14 - Auditor B - Plano R2

**Legenda:** `S-DOC` = suficiente como CONTRATO DOCUMENTAL, ainda nao executado em candidata v1.0.1. `N/A` = nenhuma evidencia funcional nova de Blender/codigo. Todas as localizacoes referem-se a `02_ADENDO_MASTER_R2_PLANO_V101.md` dentro de `ORIGINAIS/EXTRAIDOS/`.

| Gate | Status | Localizador R2 | Obrigacao de evidencia na futura candidata |
|---|---|---|---|
| G01 | S-DOC | L9-L15, L23-L28 | Inventario por drop/owner/ID/path/status e lista de fontes nao cobertas; unknown => zero remove |
| G02 | S-DOC | L16-L21, L27, L31 | Membership simples liberado; Empty/Geometry Nodes/instancing transitivo consumido por survivor bloqueia; consumidor removido vs vivo |
| G03 | S-DOC | L18, L21, L24-L28, L31 | Material driver, IDProperty nested, NodeTree embedded, owners nao-Object, falha de introspeccao global |
| G04 | S-DOC | L29 | Zero remapeamento geometrico de ponteiros a keep (G/R/S podem diferir) |
| G05 | S-DOC | L33-L41, L105 | Oraculo de bijecao global e ciclos orientados, SEM-01 e reverse de coords distintas; decisao sobre regra mais estrita pendente se pedida |
| G06 | S-DOC | L43-L65 | Limites numericos globais/par por tempo/estados/pares/bucket/memoria; erro tipado, zero remove no timeout tardio |
| G07 | S-DOC | L31, L65, L93, L97-L99 | Positivos e negativos certificados, n-gons, regularidade, C01-C24 e suites A/B antigas rodadas na NOVA candidata |
| G08 | S-DOC | L69-L81 | Modifiers > shape keys > nome, KEEP nao trocado por editabilidade |
| G09 | S-DOC | L69-L81 | KEEP/DROP, linked, readonly, indirect, override, runtime, shared Mesh, multi-scene, EDIT; statuses contraditorios unknown |
| G10 | S-DOC | L83-L93 | Ledger antes de delete; excecao antes/depois do efeito; reenumeracao segura; INDETERMINADO; nunca rollback ficticio |
| G11 | S-DOC | L100-L101 | Baseline/especificacao/plano imutaveis, candidato novo + diff + hashes; Blender real so autorizacao expressa |
| G12 | S-DOC | L41, L65 | float32 -> np.rint(x*100000), fronteiras, NaN/Inf/overflow abortam sem falso negativo |
| G13 | S-DOC | L25-L26, L103-L106 | Text/driver dinamicos detectaveis como unknown, limites nao observaveis assumidos como residual externo informado |
| G14 | S-DOC | L101 | Nenhum Blender/bpy/.blend nesta rodada; testes reais apenas futuros com permissao |

**Contagem: 14/14 S-DOC, 0/14 evidencias funcionais da v1.0.1, 0/14 Blender real.**

## Contraprovas prioritarias para o executor

- F02/F03/F31: Collections ordinarias nao podem bloquear dedup apenas por membership.
- F09/F10/F11/F28: consumo funcional, inclusive transitivo e por NodeTree compartilhada, bloqueia globalmente.
- F12/F27: referencia proveniente APENAS de Object drop pode ser segura; nao supor o mesmo de IDs nao-Object persistentes.
- F13: NodeTree orfao que permanece deve ser classificado conservadoramente; desconhecido = abortar.
- F06/F07/F32: driver e ponteiros em IDs nao-Object, inclusive nested RNA, bloqueiam quando relevantes.
- F15/F16/F17/F29: user incompreendido, varredura incompleta e acesso dinamico detectavel abortam todo arquivo.
- F18-F24: elegibilidade por papeis, shared Mesh, linked keep e EDIT.
- F25/F26: um grupo inseguro ou budget tardio => zero chamadas remove mesmo para grupos seguros anteriores.
- Sem01: invertido por permutacao de vertices coincidentes pode equivaler matematicamente; com coordenadas distintas nao.

`EVIDENCIAS/testes_grafo_R2.json` descreve 32 cenarios do modelo independente. **Sao fixtures futuras; nao provas da implementacao inexistente.**
