# Referencias publicas da API Blender 5.0 (consulta documental)

Somente leitura da documentacao; Blender e bpy NAO executados.

1. `bpy.data.user_map()` retorna datablock-ID para conjunto de IDs que usam o alvo. Nao fornece automaticamente RNA paths da propriedade ou classificacao semantica. Fonte: https://docs.blender.org/api/5.0/bpy.types.BlendData.html
2. `bpy.types.ID`: `is_embedded_data` indica sub-ID como node tree raiz/collection master; `is_evaluated`, `is_editable`, `is_library_indirect`, `library` e `override_library` sao propriedades relevantes. `user_of_id` conta referencias. `session_uid` e identificador unico de sessao documentado como estavel entre renomes/reallocacoes; validar comportamento concreto da versao instalada antes de usar para reconciliacao. Fonte: https://docs.blender.org/api/5.0/bpy.types.ID.html
3. `bpy.data.objects.remove(obj, do_unlink=True)` desvincula usos do Object antes de deletar, nao documenta rollback ou transacao. Fonte: https://docs.blender.org/api/5.0/bpy.types.BlendDataObjects.html
4. `Object.instance_collection` vincula a uma Collection instanciada, motivando gate funcional indireto. Fonte: https://docs.blender.org/api/5.0/bpy.types.Object.html

As regras e testes de eficacia ainda dependem de futuro Blender 5.0 real em copia autorizada.
