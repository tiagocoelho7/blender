# PROMPT FUTURO - Auditor B da candidata Blender Dedup v1.0.1

USAR SOMENTE DEPOIS QUE O MASTER ENTREGAR A NOVA CANDIDATA CONGELADA, HASHES E QA.

Sua missao e auditoria cega independente, apenas offline, sobre a candidata v1.0.1 nova. Nao consultar parecer futuro A e nao editar candidato. Leia baseline, R1-R5, R1/R2, Master R2, diff e testes.

Foco: cobertura de incoming references e liveness de owners em bpy/RNA, incluindo IDProperties, drivers Materials, Nodes/NodeTree orphan/shared/embedded, collections comuns vs instancing funcional transitivo, user_map sem falsa prova de path; KEEP/DROP/linked/readonly/override/EDIT/shared Mesh e ranking modifiers antes de shape keys. Testar fail-closed global/zero chamada remove para toda falha preflight e excecoes em fase 3 com reconciliacao PRESENTE/REMOVIDO/INDETERMINADO. Rodar C01-C24/32 scenarios quando adaptados a candidata, mas nao confundir mocks com Blender real.

Entregar ZIP autonomo com hashes, matriz G01-G14, achados e evidencias, veredito GO/HOLD/INCONCLUSIVO **somente para codigo offline**. Nao homologar Blender real nem producao.
