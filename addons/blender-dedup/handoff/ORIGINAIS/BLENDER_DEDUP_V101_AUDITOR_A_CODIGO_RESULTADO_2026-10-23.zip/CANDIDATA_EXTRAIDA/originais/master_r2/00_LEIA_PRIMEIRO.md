# Blender Dedup v1.0.1 - Handoff Master R2

Data documental: 22/10/2026. Entrada: 2 resultados independentes de rechecagem do plano R2.

## Decisao

**GO DOCUMENTAL PARA IMPLEMENTAR** a versao v1.0.1 em arquivo NOVO, sob controle de escopo.
**INCONCLUSIVO** quanto a funcionalidade/seguranca do codigo futuro, porque v1.0.1 ainda nao existe.
**HOLD** para abrir `.blend` real, executar `bpy`, testes no Blender e uso em producao, ate nova autorizacao expressa do proprietario.

Este ZIP NAO contem candidata v1.0.1 e NAO autoriza executar o script v1.0 de baseline.

## Leitura recomendada

1. `01_PARECER_MASTER_R2_FINAL.md` - conclusao consolidada.
2. `02_PROMPT_EXECUTOR_V101.md` - tarefa para um executor offline; nenhuma execucao foi solicitada neste handoff.
3. `03_MATRIZ_GATE_IMPLEMENTACAO.md` - G01-G14 e evidencias necessarias.
4. `04_RISCOS_RESIDUAIS.md` - riscos e testes explicitamente exigidos.
5. `05_CADEIA_CUSTODIA.md` - origem, hashes e replays.
6. `ORIGINAIS/` - ambos os retornos completos em ZIP imutavel.
7. `CONGELADOS/` - baseline v1.0, R1-R5, plano R1 e adendo R2 bit a bit preservados.
8. `QA_REFERENCIA/` e `EVIDENCIAS_MASTER/` - fixtures e replays offline.

Uma reauditoria cega A/B sera necessaria apos a congelacao da nova candidata.
A aprovacao de um plano nao e aprovacao de codigo.
