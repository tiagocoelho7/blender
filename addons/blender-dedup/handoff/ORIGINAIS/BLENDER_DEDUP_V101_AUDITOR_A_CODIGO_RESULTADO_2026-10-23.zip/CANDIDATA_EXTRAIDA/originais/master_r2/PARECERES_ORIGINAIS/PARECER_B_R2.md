# BLENDER DEDUP v1.0.1 - Parecer independente B - Revisao documental R2

**Data:** 22/10/2026  
**Papel:** Auditor B, somente leitura, foco dependencias de IDs e seguranca de exclusao  
**Artefato principal:** `02_ADENDO_MASTER_R2_PLANO_V101.md`  
**SHA-256 R2:** `be7a28d2f0f052e3e421dbc6900515f203d26e64f2cd85e61b7d941f0a66048b`  
**VEREDITO:** **GO DOCUMENTAL PARA IMPLEMENTAR**. **NAO E GO para Blender real, candidata v1.0.1 ou producao.**

## 1. Sumario decisorio

O R2 fecha, em nivel de contrato de desenvolvimento, os 6 achados anteriores do B (B-H01, B-H02, B-M01, B-M02, B-M03, B-L01). A matriz G01-G14 apresenta **14/14 criterios SUFICIENTES DOCUMENTAIS**, com ressalvas operacionais registradas abaixo. Nenhum achado atual impede a IMPLEMENTACAO de uma v1.0.1 em novo arquivo. Todo teste funcional da futura candidata permanece pendente.

O adendo nao foi ratificado pelo proprietario, nao muda R1-R5, e nao concede autorizacao para abrir, executar, salvar ou alterar `.blend` real. A implementacao deve ser coordenada pelo Master com nova candidata congelada e auditoria A/B independente.

**Evidencias novas nesta rodada:** 9/9 hashes de entrada validos; 32/32 hashes internos da auditoria B anterior validos (verificacao recursiva, nao novos testes funcionais); 14 metodos offline PASS, abrangendo 32 contratos sinteticos de grafo com resultados esperados concordantes; comparador matematico independente de baixa escala; nenhuma chamada a bpy. **Os 32 casos sao oraculos simulados pelo proprio auditor e nao constituem 32 testes da inexistente v1.0.1.**

## 2. Integridade e procedencia

- Pacote original: `BLENDER_DEDUP_V101_RECHECK_PLANO_R2_AUDITOR_B_2026-10-22.zip`, SHA-256 `47abd6dbef92c2b8ec5e21ab334bafa7c38c232c9b63f205241d16cb04c04255`.
- Manifesto de entrada `SHA256SUMS.txt`: 9/9 membros verificados; nenhum divergente.
- Baseline v1.0: `BASELINE/remover_duplicatas_blend_v1.py`, SHA `f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3`.
- Especificacao congelada: SHA `2d1aa740b4ec7a42307dcec253fbce23f452ad45249fa35585bd12a6da0d3653`.
- Plano R1: SHA `593ab739ebfbbbfa32e7d2f99dd568f56463081fb72c16cf53ba42cc46d2a839`.
- Retorno B anterior incluido: SHA `798adf9ce864254c2b336e4405dfc297d246e1245b7a1091b6d1824ffd7bc2fc`; manifesto interno 32/32.
- R2 Master: SHA `be7a28d2f0f052e3e421dbc6900515f203d26e64f2cd85e61b7d941f0a66048b`.
- Nao consultei resultado novo do Auditor A, nao editei originais, nao executei Blender/bpy nem li `.blend`.

## 3. Encerramento dos achados B anteriores

| ID anterior | Status R2 | Evidencia documental | Condicao para futura candidata |
|---|---|---|---|
| B-H01 (HIGH) - descoberta/cobertura incompletas | **FECHADO DOCUMENTALMENTE** | R2 L9-L31 define IDs de todos os tipos, RNA aninhado, IDProperties, drivers, user_map como cruzamento, DESCONHECIDA e aborto global | Listar fontes visitadas, desconhecidas e excluir zero no arquivo inteiro se incompleto; provas Blender real futuras |
| B-H02 (HIGH) - Collection consumida indiretamente | **FECHADO DOCUMENTALMENTE** | R2 L16-L21 e L27-L31 separam membership simples de consumo por instancing/Geometry Nodes e exigem fecho transitivo | Casos Empty/Collection Info/colecao aninhada, com consumidor sobrevivente ou removido |
| B-M01 - elegibilidade de KEEP/DROP/Mesh | **FECHADO DOCUMENTALMENTE** | R2 L67-L81, ranking absoluto e tabela linked/override/readonly/edit/multi-scene/shared Mesh | Testes matrix KEEP/DROP e IDs especiais; nao fazer limpeza de Mesh |
| B-M02 - budgets imprecisos | **FECHADO DOCUMENTALMENTE** | R2 L43-L65 defaults numericos, limites globais/par, MemoryError, ComplexityBudgetExceeded e zero remove na preflight | Medir e calibrar; nao chamar timeout/OOM de prova de seguranca fisica |
| B-M03 - lista exata em falha parcial | **FECHADO DOCUMENTALMENTE** | R2 L83-L93 exige ledger e reconciliacao com PRESENTE/REMOVIDO/INDETERMINADO, sem rollback ficticio | Validar snapshots e excecoes antes/depois de efeito; testar session_uid quando disponivel |
| B-L01 - caminho baseline inconsistente | **FECHADO NO ADENDO** | R2 L100 explicita `BASELINE/...` | Nao editar texto R1 congelado; usar caminho correto no novo roteiro |

Nao chamar esses itens de "corrigidos no codigo". Ainda nao existe codigo novo.

## 4. Revisao adversarial dirigida

### 4.1 Referencias e users de ID

**Aderente documentalmente:** o R2 nao supoe que `bpy.data.user_map()` forneca `rna_path`, nem que `ID.user_of_id()` identifique significado da dependencia. Exige enumeracao de estruturas RNA e classificacao unknown quando usuario nao seja explicado (R2 L23-L28). Documentar inclusao de subestruturas `is_embedded_data`, node groups, IDs nao-Object e overrides na implementacao. Uma divergencia entre mapa agregado e visita RNA e **DESCOBERTA_INCOMPLETA**, nao "seguro".

**Contraprova:** `Material` sobrevivente contem driver com alvo ao drop, mesmo sem Object sobrevivente apontando diretamente. Politica R2 = ABORTO GLOBAL. F06 e F07 representam esse contrato em modelo sintetico.

### 4.2 Collection sem falsa equivalencia entre pertencimento e uso

**Permite** drop em collections/scenes comuns sem instancing funcional: F02, F03, F31. **Bloqueia** Collection consumida por Empty vivo, NodeTree efetivamente usada por survivor ou cadeia de collections: F09, F10, F11. **Permite**, quando comprovado e sem outros consumidores, consumo originado somente em outro Object drop: F12. **Bloqueia** se NodeTree compartilhada tambem pertence a survivor (F28). Um NodeTree ID orfao que permanece no blend deve ser avaliado conservadoramente; nao o classificar automaticamente como "sera removido" (F13).

O oraculo de grafo NAO executa Collection Info ou `do_unlink` reais. A implementacao precisara provar quais IDs sobrevivem e quais sao apenas partes internas, especialmente node groups independentes ou embedded, antes de permitir `INTERNA_A_REMOVIDOS`.

### 4.3 Matriz e ranking

R2 L69-L81 impediu uma interpretacao indevida: nao trocar KEEP vencedor por DROP mais facil de excluir. Mais modifiers tem precedencia ABSOLUTA sobre mais shape keys e nome. Um KEEP linked/readonly pode permanecer intocado, mas DROP linked/override/indirect/readonly desconhecido deve abortar. Dados Mesh compartilhados podem permanecer; remover apenas Object comprovado seguro.

### 4.4 Preflight, complexidade e reconcilicao

R2 L60-L65 delimita as tres fases e exige global-zero-delete caso qualquer cluster tardio, varredura, alocacao ou budget falhe. Uma excecao **depois de o `remove()` modificar o estado** nao implica que o objeto esteja presente; R2 L87-L93 exige interrupcao, reenumeracao e `INDETERMINADO` onde necessario. O `ID.session_uid` e documentado na API Blender 5.0, e vale considerar seu uso com validacao de unicidade em sessao, sem extrapolar garantia de rollback ou acesso a proxy invalido. Nao confiar somente em name/pointer e no contador de retornos.

### 4.5 Exatidão da topologia e SEM-01

R2 L33-L41 preserva a regra de bijecao global de vertices com coordenadas quantizadas em 5 casas, arestas com multiplicidades, faces como ciclos orientados modulo rotacao e sem operacao de reverse. Oraculo independente pequeno confirmou: triangulo de coordenadas distintas com winding invertido = NEGATIVO; triangulo com tres vertices coincidentes e faces invertidas = POSITIVO sob permutacao valida; 6-ciclo e dois triangulos = NEGATIVO; 17-gon reindexado = POSITIVO. Estes sao casos matematicos, nao testes da candidata.

**Politica SEM-01:** interpretacao consistente com R1, mas se o proprietario desejar proibir toda reversao aparente em caso simetrico/coincidente, e necessario RATIFICAR essa mudanca antes de producao. Nao promover a mudanca silenciosamente no codigo.

## 5. Riscos residuais - NAO bloqueiam GO documental

**R2-B-OBS01 [MEDIUM, implementacao futura] - liveness de ID nao-Object e RNA embedded.** Um NodeTree/Material sem usuarios atuais pode continuar como ID no arquivo. "Consumidor Object removido" nao prova que NodeTree/material serao removidos. Exigir classificacao explicita e fail-closed em caso incerto, com fixtures de orphan/shared/embedded e cadeia de usuario completa. Fundamentacao: R2 L20, L23-L28.

**R2-B-OBS02 [MEDIUM, fronteira externa] - scripts dinamicos/textos/nome.** Nao ha descoberta perfeita de toda automacao Python, principalmente externa. Fazer conservadorismo verificavel para referencias detectaveis e apresentar risco externo ao proprietario antes de producao; uma varredura textual nao e comprovacao negativa. R2 L25-L26 e L103-L106 ja admite explicitamente esse limite. Nao constitui bug provado da futura candidata.

**R2-B-OBS03 [LOW, fortalecimento] - identificador de sessao.** Avaliar `bpy.types.ID.session_uid` para reconciliacao apos remocao, com teste real de disponibilidade e comportamento. O R2 ja permite declarar estado INDETERMINADO quando nao comprovado; isto e melhoria de evidencia, nao bloqueio (R2 L85-L93).

**R2-B-OBS04 [LOW, calibracao] - orcamentos nao garantem hardware.** Defaults 300s/45s/2e6 estados e estimativas 2 GiB nao formam limite fisico de RSS nem parada preemptiva de NumPy nativo. Documentacao R2 L45-L65 reconhece tal limite; medir memoria e tempo em hardware representativo, abortando sem exclusoes quando inconclusivo.

Nao foram detectados novos bloqueadores HIGH desta revisao documental. A ausencia de defeitos documentais conhecidos NAO e prova de seguranca operacional.

## 6. Matriz de gates G01-G14

**14/14 SUFICIENTE DOCUMENTAL PARA IMPLEMENTAR**, sujeitos aos ensaios e condicoes especificados em `MATRIZ_G01_G14.md`. Cada gate e um requisito **a verificar sobre a futura candidata**, nao uma linha de teste Blender aprovada.

## 7. Ensaios realizados nesta rodada

Script: `QA/qa_contratos_documentais_R2.py`. Saidas: `EVIDENCIAS/qa_contratos_R2.json`, `EVIDENCIAS/qa_contratos_R2.log` e `EVIDENCIAS/testes_grafo_R2.json`.

- 14 metodos unittest PASS, incluindo 32 cenarios de grafo sinteticos (32/32 concordantes com o oraculo proposto), ataques a politica ingênua de direct-only e de membership-always-block, controles de coerencia textual e pequenos casos de isomorfismo matematico.
- Nao testou `bpy.data.user_map`, RNA real, integridade de arquivos `.blend`, eventos/handlers, `do_unlink` real, tempo/memoria da implementacao nem Blender 5.0.
- A validacao dos 32/32 hashes internos do retorno B anterior e auditoria de integridade, nao 32 testes adicionais de codigo.
- Nenhum `.blend` foi aberto, lido ou salvo; nenhuma mutacao na baseline; nenhuma candidata nova foi criada.

## 8. Passagem para Master e portas de aprovacao

1. **Gate atual: GO DOCUMENTAL PARA IMPLEMENTAR** adendo R2 como contrato, em arquivo novo v1.0.1. Registrar eventual ratificacao de interpretacoes do proprietario (SEM-01 e risco residual scripts externos) antes de producao, nao presumir silencio como aprovacao.
2. **Gate implementacao:** gerar script candidato independente da v1.0, diff, manifesto de hashes, QA completo A/B com C01-C24, 32 testemunhas de grafo aqui incluidas quando adaptaveis, benchmarks/budgets e zero mutacao em qualquer erro de preflight. Descrever superficies RNA enumeradas e ausentes de modo audivel.
3. **Gate auditoria cega:** congelar candidata e auditar A/B independentemente; resultados sinteticos do auditor nao equivalem a homologacao.
4. **Gate Blender 5.0:** apenas futuro, somente apos AUTORIZACAO EXPLICITA do proprietario, em `.blend` sintetico/descartavel e com verificacao de efeitos. **Producao HOLD.**

## 9. Fontes documentais

- Originais: `ORIGINAIS/EXTRAIDOS/02_ADENDO_MASTER_R2_PLANO_V101.md`, `ESPECIFICACAO_CONGELADA.md`, `PLANO_R1_V101.md`, `03_MATRIZ_GATE_R2.md`, ZIP do B anterior e v1.0 imutavel.
- API oficial Blender 5.0: `https://docs.blender.org/api/5.0/bpy.types.BlendData.html` (user_map); `https://docs.blender.org/api/5.0/bpy.types.ID.html` (session_uid/flags/user_of_id); `https://docs.blender.org/api/5.0/bpy.types.BlendDataObjects.html` (remove/do_unlink). Os textos nao substituem teste real.
