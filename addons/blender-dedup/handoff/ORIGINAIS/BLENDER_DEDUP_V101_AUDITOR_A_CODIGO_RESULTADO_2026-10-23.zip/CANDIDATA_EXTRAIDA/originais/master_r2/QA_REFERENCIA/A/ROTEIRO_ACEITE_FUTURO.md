# Roteiro obrigatório de testes futuros — arquivo novo v1.0.1 (não executado)

Este roteiro descreve os casos a **executar quando existir** candidato SHA-pinado; nesta rodada apenas a baseline v1.0 foi testada offline.

| ID | Preparação | Esperado sobre FUTURA candidata |
|---|---|---|
| A-R2-01 | Dois Objects com MESMO datablock Mesh contendo `NaN` | Exceção tipada global pré-remove, 0 chamadas. Bloquear short-circuit por identidade |
| A-R2-02 | Idem com `Inf` e coordenada cujo `abs*1e5` excede limite int64 | Aborto pré-remove, zero |
| A-R2-03 | Par duplicado seguro primeiro, par intratável por budget por último | 0 `remove` no arquivo inteiro; retorno `INCONCLUSIVO` distinguível |
| A-R2-04 | Bucket com 6 e 8 não equivalentes sob mesmo coarse hash | Contabilizar respectivamente até 15 e 28 comparações, sem converter timeout em `False` |
| A-R2-05 | Bucket acima de máximo sem prova de separação por invariante necessário | Aborto global, zero exclusões |
| A-R2-06 | NaN/Inf em malha não avaliada escondida/outra Scene | Sem atalho de visibilidade, abortar quando universo/critério assim exigir |
| A-R2-07 | Um DROP membro simples de múltiplas Collection/Scenes, sem consumo funcional | Auto-remove Object seguro, membership simples não bloqueia |
| A-R2-08 | DROP é membro de Collection instanciada via EMPTY ou Geometry Nodes sobrevivente | ABORT global, 0 chamadas; registrar caminho transitivo |
| A-R2-09 | DROP é target de parent/constraint/Material driver/nested IDProperty de surviving ID | ABORT global, 0 chamadas; owner/key/path identificados ou UNKNOWN fechado |
| A-R2-10 | Referência de DROP para KEEP, sem dependência reversa/funcional em survivors | Permitir remoção do DROP com prova; não retargetar outros IDs |
| A-R2-11 | RNA inacessível ou Text/driver dinâmico detectável capaz de consultar DROP por nome | ABORT antes da 1ª chamada; `user_map()` sozinho é insuficiente |
| A-R2-12 | KEEP de biblioteca/readonly e DROP local; inverter mantendo ranking | Quando admissível, KEEP read-only pode ficar; DROP linked/readonly aborta, sem mudar R2 |
| A-R2-13 | Exceção FAKE após efeito parcial na 1ª/2ª/última exclusão | Interromper, reconsultar IDs, triestado e `FALHA_PARCIAL_POSSIVEL`; sem autosave |
| A-R2-14 | Exceção após início fase 3 durante print/log/cancelamento | Interromper chamadas futuras, reconciliar, não alegar rollback |
| A-R2-15 | Vertices coincidentes SEM-01; faces orientadas e n-gons rotacionados | Testemunha global; SEM-01 pode ser isomorfo, winding distinto é negativo |
| A-R2-16 | Faces conectam vertices com array edges vazio em mock | Algoritmo de componentes considera incidência de faces; validar admissibilidade bpy separadamente |
| A-R2-17 | Rook vs Shrikhande e 6+8 vs 7+7 | `NOT_EQUAL` somente após oráculo exato ou `INCONCLUSIVO`; nunca falso negativo silencioso |
| A-R2-18 | Erro MemoryError, overflow, KeyboardInterrupt no preflight/inventário e hash lento | 0 remove, status tipado e logs com fase/código |

**Reprodutibilidade da bateria atual (baseline v1.0):**

```bash
python EVIDENCIAS/teste_oraculo_independente_r2_a.py ORIGINAIS/BASELINE/remover_duplicatas_blend_v1.py EVIDENCIAS/oraculo_resultados.json
python EVIDENCIAS/teste_riscos_regressao_r2_a.py ORIGINAIS/BASELINE/remover_duplicatas_blend_v1.py EVIDENCIAS/risco_regressao_resultados.json
sha256sum -c SHA256SUMS.txt
```

O teste utiliza Python+NumPy, não importa `bpy`, nem carrega `.blend`. Não execute scripts com Blender nesta fase.
