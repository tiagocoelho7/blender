# Matriz de riscos e observacoes residuais R2

Nao sao bloqueantes para iniciar desenvolvimento offline, mas sao itens de QA ou de decisao posterior.

| ID | Severidade do auditor | Risco / requisito concreto | Responsavel/fase |
|---|---|---|---|
| A-R2-M01 | MEDIUM | Alias/same-pointer Mesh com NaN pode contornar quantizacao na baseline v1.0; validar antes de todo atalho | Executor + auditoria codigo |
| A-R2-M02 | MEDIUM | Estimativa de memoria temporaria e tempo nao garante RSS/OOM; contabilizar antes de alocacoes; medir RSS | Executor + calibracao hardware futura |
| A-R2-L03 | LOW | `do_unlink=True` altera membership de scene/collection inevitavelmente; distinguir isso de edicao proibida de outros IDs | Executor |
| A-R2-L04 | LOW | Erros de logger/snapshot/KeyboardInterrupt apos primeira exclusao precisam reconciliacao e stop | Executor |
| B-R2-OBS01 | MEDIUM | IDs nao-Object/NodeTree orphan/embedded sobrevivem sem Objects e podem conter dependencias | Executor + QA futuro Blender |
| B-R2-OBS02 | MEDIUM | Scripts externos e lookup por nome podem escapar de varredura completa; risco residual nao pode ser declarado inexistente | Master/proprietario antes de producao |
| B-R2-OBS03 | LOW | `ID.session_uid` pode auxiliar reconciliação, mas depende de verificacao real | Executor + QA futuro Blender |
| B-R2-OBS04 | LOW | Defaults numericos de budget sao tentativos, nao hardware limits fisicos | Executor + QA hardware |

**SEM-01**: ambiguidades de winding em vertices coincidentes sao interpretadas pela bijecao global. A opcao semanticamente mais estrita NAO e autorizada automaticamente. Manter R1-R5; se alteracao for desejada, coletar decisao expressa do proprietario, preferencialmente antes de producao.

**Falhas**: abortar por inconclusivo nao e falso negativo silencioso; o programa deve informar que NAO concluiu e garantir zero exclusoes se a falha ocorreu durante o preflight.
