# Parecer Master FINAL - Rechecagem documental R2 do Blender Dedup v1.0.1

Data: 2026-10-22. Escopo: apenas ZIPs recebidos dos auditores A e B, seus documentos, arquivos de referencia e replays em copias isoladas. Nao houve Blender, `bpy`, `.blend` de producao ou nova candidata.

## 1. Veredito

**GO DOCUMENTAL PARA IMPLEMENTAR** uma v1.0.1 NOVA. Os dois auditores independentes encerraram seus bloqueantes documentais da rodada R1. Ambos reportaram 14/14 gates documentais suficientes (G01-G14), sem HIGH novo bloqueante para iniciar desenvolvimento. A aprovacao e limitada ao contrato de projeto; nao homologa comportamento de Blender real nem software ainda inexistente.

- Codigo v1.0.1: **INCONCLUSIVO / INEXISTENTE NESTA ENTREGA**.
- Testes em Blender 5.0.0 e arquivos `.blend`: **HOLD**, autorizacao futura necessaria.
- Producao: **HOLD**.
- Especificacao de usuario R1-R5: **congelada, inalterada**.
- Adendo R2: aceito pelo Master COMO INSTRUCAO TECNICA PARA IMPLEMENTACAO, sem alteracao silenciosa das decisoes do proprietario e sem supor ratificacao de casos semanticos novos.

## 2. Integridade

| Prova | Master |
|---|---|
| ZIP A externo / ZIP B externo | CRC integral OK para ambos |
| Manifesto do resultado A | 21/21 hashes e tamanhos corretos |
| SHA256SUMS do resultado A | 21/21 corretos |
| Manifesto do resultado B | 23/23 hashes e tamanhos corretos |
| SHA256SUMS do resultado B | 24/24 corretos, inclui MANIFESTO.json |
| ZIP de entrada R2 preservado no resultado A | 9/9 hashes corretos |
| ZIP de entrada R2 preservado no resultado B | 9/9 hashes corretos |
| Manifesto do retorno B anterior aninhado | 32/32 corretos |
| Baseline v1.0, especificacao, plano R1, adendo R2 e matriz | Bytes identicos entre A e B |

Nota de escopo: os manifests externos nao incluem seus proprios arquivos de SHA; os arquivos `ORIGINAIS/.../SHA256SUMS.txt` preservados sao cobertos pelo ZIP original e por seu proprio checksum, nao precisam ser contabilizados como achados de alteracao.

Referencias SHA-256:
- baseline v1.0: `f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3`
- R1-R5: `2d1aa740b4ec7a42307dcec253fbce23f452ad45249fa35585bd12a6da0d3653`
- plano R1: `593ab739ebfbbbfa32e7d2f99dd568f56463081fb72c16cf53ba42cc46d2a839`
- adendo Master R2: `be7a28d2f0f052e3e421dbc6900515f203d26e64f2cd85e61b7d941f0a66048b`
- ZIP retorno A: `6997ad1f81e8854b65abd96b82e2830574f1042514a556b3f7b0a03d217d9ae8`
- ZIP retorno B: `281bda9ea4edb10d76ef730125415a9df2220601e253ad5d56bc4ccd14d30853`

## 3. Reproducao independente Master, offline em copias isoladas

| Experimento | Resultado | Limite |
|---|---|---|
| Oracle independente A contra baseline v1.0 | **266/266 PASS** | testa somente a v1.0 nao Blender |
| Contraprovas A: atalho NaN e contagens de budget | **PASS / risco reproduzido** | exige teste futuro v1.0.1 |
| Suite B de contrato documental | **14/14 metodos PASS** | modelo matematico/sintetico |
| Cenários de grafo dentro do teste B | **32/32 concordantes** | NAO testam `bpy` |

Logs completos no diretorio `EVIDENCIAS_MASTER/`. Nenhuma exclusao real foi executada. A contagem 32/32 de hash do retorno anterior B nao e contagem de casos de software.

## 4. Correspondencia e divergencias

Convergencia: ambos aprovam G01-G14 como plano de implementacao; mantem R1-R5, proibe remapeamento geometrico de referencias, exige fail-closed global antes de exclusao, preserva prioridade absoluta de modifiers sobre shape keys, distingue membership de consumo funcional e requer ledger de falha parcial. Nao ha contradição material entre os pareceres no gate documental.

Detalhes adicionais do Auditor A: A-R2-M01 (malha com NaN, alias/shared pointer), A-R2-M02 (orçamento fisico/RSS), A-R2-L03 (unlink inerente permitido) e A-R2-L04 (falhas de fase 3 fora da chamada remove).

Detalhes adicionais do Auditor B: B-R2-OBS01 (ID nao-Object/NodeTree persistente/embedded), OBS02 (scripts dinamicos e referencias por nomes externas), OBS03 (`ID.session_uid` como possivel fonte auxiliar de evidencia) e OBS04 (limites numericos nao garantem recursos fisicos).

Os itens adicionais sao exigencias da implementacao/teste ou riscos residuais, nao impeditivos de escrever uma nova candidata offline. SEM-01 deve permanecer com interpretacao matematica da bijecao global, sem alterar winding arbitrariamente; eventual semantica mais estrita requer decisao do proprietario, nao e alteracao autorizada.

## 5. Proximo gate

Encaminhar `02_PROMPT_EXECUTOR_V101.md` junto deste ZIP ao executor offline para desenvolver arquivo novo `remover_duplicatas_blend_v1_0_1.py`. Deve entregar codigo, diff, hashes, QA independente, traces e relatorio, sem executar Blender real ou modificar originais. O Master congelara e conferira a candidata. Depois dois auditores A/B a examinarao cegamente. Homologacao em Blender real depende de autorizacao separada.

Parecer Master: **GO DOCUMENTAL PARA IMPLEMENTAR / HOLD CODIGO E PRODUCAO**.
