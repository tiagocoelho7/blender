# Cadeia de custodia verificada - Master R2

Data documental 2026-10-22. Analise offline. ZIPs originais inteiros copiados com os mesmos bytes e preservados em `ORIGINAIS/`. A e B foram consultados somente depois das auditorias independentes, neste trabalho Master.

| Item | SHA-256 |
|---|---|
| ZIP resultado A R2 | `6997ad1f81e8854b65abd96b82e2830574f1042514a556b3f7b0a03d217d9ae8` |
| ZIP resultado B R2 | `281bda9ea4edb10d76ef730125415a9df2220601e253ad5d56bc4ccd14d30853` |
| v1.0 congelado | `f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3` |
| Especificacao proprietario R1-R5 | `2d1aa740b4ec7a42307dcec253fbce23f452ad45249fa35585bd12a6da0d3653` |
| Plano R1 v1.0.1 | `593ab739ebfbbbfa32e7d2f99dd568f56463081fb72c16cf53ba42cc46d2a839` |
| Adendo Master R2 | `be7a28d2f0f052e3e421dbc6900515f203d26e64f2cd85e61b7d941f0a66048b` |
| Matriz gate R2 | `34c5fe1c8d38a3f06dcfcacb314b4b428d247639b7a792096b744fe2946725cd` |

Verificacoes realizadas: ZIP A 24 membros/CRC OK; ZIP B 26 membros/CRC OK. Manifesto A 21/21; checksum A 21/21. Manifesto B 23/23; checksum B 24/24, incluindo MANIFESTO. Todos os hashes e tamanhos dessas listas conferidos com bytes reais. ZIP de entrada R2 aninhado A 9/9 e B 9/9; auditoria antiga B aninhada `MANIFESTO_SHA256.txt` 32/32.

A/B bytes IDENTICOS nos arquivos nucleares baseline, especificacao R1-R5, plano R1, adendo R2 e matriz G01-G14; sem diff desses cinco conteudos.

Master fez replay em COPIAS isoladas do conteudo dos auditores: A 266/266 comparacoes contra v1.0; A teste NaN alias e relacao de budget PASS; B 14/14 unittest com 32/32 cenarios sinteticos concordantes. Logs em `EVIDENCIAS_MASTER/`. Nada em `.blend`, nenhuma chamada de exclusao real, nenhuma candidata v1.0.1.

Anomalia de escopo nao bloqueante: Manifestos SHA do resultado principal nao listam os arquivos SHA aninhados como membros de seu proprio inventario; os ZIPs originais correspondentes preservam seus controles 9/9. Nao classificar como falha de hash.
