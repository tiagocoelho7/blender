# PROMPT DE EXECUCAO - Blender Dedup v1.0.1 - somente offline

Voce e o executor tecnico da nova candidata Blender Dedup v1.0.1. O Chat Master consolidou A/B da rechecagem R2 com GO DOCUMENTAL PARA IMPLEMENTAR. Este nao e um GO de runtime/Blender e nao significa autorizacao para mexer em arquivos `.blend` reais.

**Leia todos os arquivos de `CONGELADOS/`, `01_PARECER_MASTER_R2_FINAL.md`, `03_MATRIZ_GATE_IMPLEMENTACAO.md`, `04_RISCOS_RESIDUAIS.md`, as auditorias A/B integrais em `ORIGINAIS/` e os fixtures em `QA_REFERENCIA/`.** Os originais devem permanecer imutaveis.

## Objetivo

Implementar uma candidata nova `remover_duplicatas_blend_v1_0_1.py` que detecte malhas-base MESH duplicadas em todos os objetos de `bpy.data.objects` (independente de cena/collection), priorize KEEP por mais modifiers, depois mais shape key blocks, depois nome alfabetico, e remova automaticamente os DROPs comprovadamente seguros sem salvar o arquivo. Priorizar fidelidade a R1-R5. Materiais, UV, animacoes, transformacoes G/R/S, collections, modifiers e shape keys nao determinam equivalencia geometrica; modificacao destrutiva que altera a malha-base importa. Quantizacao: 5 casas sobre float32. **Nao suprimir falsos negativos por reindexacao** e nao transformar timeout em nao-duplicado.

## Exigencias bloqueantes

1. **Comparador exato**: bijecao GLOBAL de vertices apos quantizacao, multiconjunto de edges nao orientadas com multiplicidade, multiconjunto de faces como ciclos orientados modulo rotacao sem permitir reverse. N-gons 14/17+, vertice coincidente, faces/arestas duplicadas, edge solta, hipergrafo face-only e grafos simetricos. Filtros de contagem/WL/hashes sao apenas necessarios/rapidos, NUNCA prova positiva. A malha original nao avaliada e comparada, nao o resultado visual de modifier.
2. **Validade numerica sem atalhos**: validar todas as coordenadas, inclusive quando dois objetos compartilham o MESMO datablock Mesh/pointer. NaN, Inf e overflow causam ABORTO GLOBAL preflight, nunca igualdade automaticamente, nem retorno `False`.
3. **Planejamento em duas fases sem mutacao**: FASE 1 determina todos os clusters e KEEP/DROPs; FASE 2 inventaria todas as referencias/owners relevantes e elegibilidade. Qualquer inconclusivo, introspeccao nao suportada, memoria insuficiente ou budget estourado aborta ANTES da primeira chamada `objects.remove`, inclusive erro no ultimo bucket.
4. **Inventario de dependencias funcional**: varrer IDs acessiveis em `bpy.data` com RNA aninhado, references em IDProperties, drivers (tambem em Materials), modifiers, constraints, parents, nodes/NodeTrees, collections instanciadas e Geometry Nodes. Diferenciar simples membership de conteudo consumido de forma transitiva por sobreviventes. Usar `user_map` somente como cruzamento, jamais como prova unica de caminho/semantica. Desconhecido ou cobertura incompleta = ABORTO GLOBAL. IDs nao-Object que persistem, mesmo orphan, requerem classificacao conservadora; nao presumir que somem com o DROP.
5. **Nao remapear pointers** a KEEP apenas por geometria. KEEP e DROP podem ter G/R/S diferentes. Nao modificar outros IDs semanticamente; apenas os unlinks inerentes de `objects.remove(...,do_unlink=True)` sao permitidos para remocao aprovada.
6. **Ranking e elegibilidade**: modifiers > shape key blocks > nome; NUNCA mudar vencedor por dificuldade de remover. KEEP linked/readonly pode permanecer intacto se seguro; DROP linked/indirect/readonly/override/EDIT/estado desconhecido ou referencia insegura aborta globalmente. Mesh compartilhado so perde Object, jamais apagar diretamente Mesh datablock.
7. **Budgets e falha fechada**: implementar BudgetContext compartilhado com tempo total/par, comparacoes, estados totais/par, memoria temporaria por par/total e bucket. Defaults R2 apenas PROPOSTOS (300s,45s,50000,2e6,250000,2GiB,512MiB,2048), documentar configuracao, medicao RSS, estimativas por alocacao/liberacao, verificacao antes de grandes alocacoes e after-check de NumPy; limites nao sao hard cap do SO. `ComplexityBudgetExceeded`, `MemoryError`, interrupcao preflight e scan incompleto = ABORTO, ZERO remove. Nunca converter inconclusivo em duplicata ou nao-duplicata.
8. **Fase de exclusao e ledger**: gerar plano completo e log antes do delete; FASE 3 remove sequencialmente sem confirmacao e SEM AUTOSAVE. Se `remove` ou logger ou handler falhar, parar novas remocoes e reconciliar `CONFIRMADO_REMOVIDO`/`CONFIRMADO_PRESENTE`/`INDETERMINADO`. Nao acessar proxy bpy invalido, nao prometer rollback; inclui KeyboardInterrupt e erro de snapshot apos primeiro remove.
9. **Nomes e scripts externos**: varrer strings/Texts/expressions detectaveis no blend com potencial de acesso dinamico, e abortar quando incerto e plausivelmente ligado a DROP. Nao alegar descoberta perfeita de Python externo; documentar risco residual para futura decisao do proprietario antes da producao.
10. **Semantica SEM-01**: preservar interpretacao R2 do oraculo de bijecao global; 3 vertices coincidentes com winding aparente invertido podem ser equivalentes se houver bijecao. Nao criar uma nova regra de winding sem autorizacao do proprietario.

## Testes exigidos

- Adaptar ao NOVO codigo os 266 casos A, 32 cenarios de grafo B, suites antigas A/B e C01-C24, distinguindo quando mocks nao representam legalmente APIs Blender reais. Adicionar testes propriamente novos para todos G01-G14.
- Testes NaN/Inf/overflow em alias de Mesh, quantizacao nas fronteiras, diferenciacao SEM-01/winding, F02/F03/F31 e F09/F10/F11/F28, F06/F07/F32, NodeTree orphan/embedded, IDProperty nested, unknown/unscannable owners, DROP linked/readonly/override/indirect/edit, KEEP vinculado, Mesh compartilhado, timeout tardio, erro de logger e excecoes antes/depois de efeitos da fase de delete.
- Teste automatico de **zero chamadas remove** para cada falha de preflight. Positivos/negativos certificados por oraculo independente; logs de performance/CPU/RSS e crescimento de memoria em malhas sinteticas grandes. Os scripts/fakes originais NAO sao evidencia de codigo novo ate adaptados e reexecutados.
- Registrar limitacoes e matriz de cobertura RNA; nao inventar testabilidade de Blender sem runtime autorizado.

## Nao autorizacoes

NAO executar Blender 5.0.0 real, `bpy` real, `.blend` real, qualquer exclusao em arquivos do usuario ou salvamento. NAO alterar v1.0 original, adendo R2, R1-R5, suites ou auditorias originais. Usar somente copias sinteticas offline e novos arquivos isolados. Nao envolver ChatGPT Work sem autorizacao separada se esta tarefa for passada a um agente de custo alto.

## Entregaveis

Um novo ZIP **autossuficiente**, contendo: (a) candidata `.py` nova, (b) `diff -u` contra baseline e fontes adicionais quando necessario, (c) README de uso/limites/gates, (d) suites QA adaptadas e independentes, (e) evidencias de execucao offline e traces, (f) benchmarks, (g) matriz G01-G14 com PASS/FAIL/INCONCLUSIVO/N-A e evidencias, (h) tabela de superficies bpy/RNA cobertas/desconhecidas, (i) SHA256SUMS+MANIFESTO, (j) parecer do executor que nao se autohomologa, (k) prompt de encaminhamento aos auditores A/B, (l) todos os originais de referencia necessarios preservados.

Ponto de parada: entregar ZIP e relatorio para revisao do Chat Master. **Nao declarar GO para Blender nem producao.**

Hashes imutaveis: baseline `f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3`; requisitos `2d1aa740b4ec7a42307dcec253fbce23f452ad45249fa35585bd12a6da0d3653`; plano R1 `593ab739ebfbbbfa32e7d2f99dd568f56463081fb72c16cf53ba42cc46d2a839`; adendo R2 `be7a28d2f0f052e3e421dbc6900515f203d26e64f2cd85e61b7d941f0a66048b`.
