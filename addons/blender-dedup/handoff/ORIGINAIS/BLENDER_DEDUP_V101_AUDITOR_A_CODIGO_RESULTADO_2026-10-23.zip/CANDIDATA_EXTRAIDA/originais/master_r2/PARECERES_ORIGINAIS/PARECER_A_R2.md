# AUDITOR A — Rechecagem documental R2 do plano Blender Dedup v1.0.1

**Data:** 22/10/2026  
**Escopo:** exame independente apenas do adendo `02_ADENDO_MASTER_R2_PLANO_V101.md`, contra requisitos R1–R5, plano R1, baseline congelada v1.0 e parecer ANTERIOR do próprio Auditor A. Não houve acesso a parecer B desta rodada.  
**Veredito:** **GO DOCUMENTAL PARA IMPLEMENTAR** (com recomendações e testes obrigatórios enumerados abaixo).  
**Gates independentes:** código v1.0.1 **INEXISTENTE/NÃO TESTADO**; Blender 5.0.0 **NÃO AUTORIZADO/NÃO EXECUTADO**; produção **HOLD**. O adendo continua *rascunho não ratificado*, devendo ser incorporado/aceito pelo Master no fluxo de governança e subordinado a R1–R5.

## 1. Conclusão executiva

O adendo R2 **resolve em nível documental** os sete achados A101-H01, H02, H03, M04, M05, M06 e L07 que sustentaram o HOLD anterior. Ele define inventário de incoming references e closures indiretas com aborto global para fontes incompreendidas; enuncia oráculo de bijeção global de vértices com faces orientadas, multiplicidades e SEM-01; apresenta budgets configuráveis numéricos, total e por par, com erro tipado e duas fases de planejamento imutável; fixa elegibilidade KEEP/DROP/Mesh e ledger/reconciliação pós-erro; lista testemunhas e mantém a cadeia de custódia.

**Não há P0 documental novo comprovado** nesta rechecagem. Essa aprovação é de suficiência do plano para iniciar implementação em arquivo NOVO, não de executabilidade, integridade do `bpy` ou qualidade do futuro patch. Os seguintes pontos devem ser incluídos na matriz de aceite do futuro código, sem demandar outra rodada de reescrita documental R2 como requisito de avanço:

- **R2A-M01 (médio / regressão de segurança):** atalho de identidade de Mesh compartilhado da baseline v1.0 contorna `NaN`. Adendo R2 já veta não finitos, mas o desenvolvedor deve adicionar teste específico de **duas instâncias Object apontando para o mesmo Mesh** com `NaN`/`Inf`/overflow e provar aborto global antes de qualquer `remove`.
- **R2A-M02 (médio / validação de recurso):** os valores de tempo, estados e memória são defaults propostos e não limites físicos. Exigir de implementação contabilidade de alocação/liberação, estimativas por operação (inclusive indexação, NumPy e RNA scans), verificações *antes* de reservar memória e observação de RSS em processo controlado; OOM não capturável é risco declarado, não uma falsa garantia.
- **R2A-L03 (baixo / redação):** `AD-R2-01` proíbe editar outros IDs, mas `objects.remove(..., do_unlink=True)` necessariamente desfaz membership em Scene/Collection. Esclarecer que **somente** esses efeitos inerentes/autorizados de unlink são exceção; não retargetar, migrar ou editar semanticamente outros datablocks.
- **R2A-L04 (baixo / estado terminal):** explicitar em QA que `KeyboardInterrupt`, erro de logger, perda de snapshot ou exceção entre chamadas da FASE 3 também são eventos pós-início da remoção que precisam parar novas chamadas e reconciliar em três estados. Não confundir com falha preflight (zero chamadas).

Nenhuma recomendação permite relaxar aborto global em erro, aprovar `False` como substituto de `INCONCLUSIVO`, remapear referências, trocar ranking ou acessar Blender real.

## 2. Cadeia de custódia e execução independente

- ZIP original: SHA-256 `0ed7fd89390f4e1b9d56c1c825c7d0a9a15b232d3c97aebc4c26e0aae593eeaf`.
- Verificação `sha256sum -c SHA256SUMS.txt`: **9/9 OK**; inclui baseline, adendo, R1, requisitos e ZIP anterior A. Registros em `EVIDENCIAS/validacao_entrada_9_de_9.log`.
- Baseline v1.0: SHA-256 `f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3`.
- Especificação R1–R5: SHA-256 `2d1aa740b4ec7a42307dcec253fbce23f452ad45249fa35585bd12a6da0d3653`.
- Plano R1: SHA-256 `593ab739ebfbbbfa32e7d2f99dd568f56463081fb72c16cf53ba42cc46d2a839`.
- Testes novos: **266/266 oráculos da baseline v1.0 em Python offline**, com enumeração independente de permutações para tamanhos pequenos, mais verificação de hiperarestas, winding, multiplicidade e 17-gon. Tudo isso testa somente a semântica da baseline e a utilidade de fixtures; **não** testa aplicação do adendo num código inexistente.
- Contraprova separada: `meshes_equal(mesh,mesh)` com coordenadas `NaN` retorna `True` no v1.0; `quantized_vertices(mesh)` lança `ValueError`. O contrato v1.0.1 deve eliminar esse desvio. Cálculos de limite: 6 candidatos não equivalentes podem demandar 15 comparações, 8 demandam 28 e 2048 demandam 2.096.128, excedendo o limite **proposto** de 50.000, que então precisa causar aborto global, jamais 'não duplicado'.
- **Não executado:** `bpy`, Blender 5 real, arquivos `.blend`, API de exclusão real, drivers/material real, monitor de RSS sob cargas gigantes, validação do comportamento da v1.0.1, regressões C01–C24 de outro auditor. Sem qualquer criação de patch/candidata.

## 3. Fechamento dos achados anteriores

| Achado anterior | Cobertura R2 | Parecer documental |
|---|---|---|
| A101-H01 — referências/closure com observabilidade incompleta | AD-R2-01 linhas 9–31, G01/G02/G03/G13: taxonomia, owner lifecycle, user_map cruzado, textos e risco residual | **RESOLVIDO NO PLANO**; varredura real ainda depende de Blender |
| A101-H02 — sem orçamento total e pré-alocação | AD-R2-03 linhas 43–65, G06: 8 limites, tempo/estados/memória, abortos integrais | **RESOLVIDO NO PLANO**, estimativa física impossível de prometer; recomendações M02 |
| A101-H03 — winding com automorfismo | AD-R2-02 linhas 33–41 e AD-R2-07: bijeção global e SEM-01 | **RESOLVIDO COMO INTERPRETAÇÃO DE R1**; mudança de regra literal exigiria proprietário |
| A101-M04 — oráculo/multiplicidades/hipergrafo | AD-R2-02 e AD-R2-06 linhas 97–99 | **RESOLVIDO NO PLANO**; prova no código futuro pendente |
| A101-M05 — lista falsa após falha parcial | AD-R2-05 linhas 83–93: três estados, indeterminação, sem rollback/autosave | **RESOLVIDO NO PLANO**; ampliar teste de fase 3 L04 |
| A101-M06 — política linked/readonly/overrides | AD-R2-04 linhas 67–81: tabela KEEP/DROP/Mesh e ranking absoluto | **RESOLVIDO NO PLANO**; provar casos no Blender real futuramente |
| A101-L07 — caminho incorreto baseline | AD-R2-06 linha 100 usa `BASELINE/` e SHA fixo | **RESOLVIDO NO ADENDO**, sem editar o R1 original |

## 4. Contraprovas e raciocínio por risco

**SEM-01:** `[0,1,2]` vs `[0,2,1]` com 3 vértices coincidentes, arestas 01/12/02: testemunha de bijeção 0→0, 1→2, 2→1. Não se faz `reverse()` do ciclo no comparador. Com coordenadas distinguíveis a bijeção não existe e o winding reverso é corretamente NEGATIVO. Se o proprietário desejar que qualquer inversão textual seja negativa mesmo sob automorfismo, essa seria nova regra: o adendo não a ratificou.

**Hiper-grafo:** numa estrutura sintética de 6 vértices, faces `(0,1,2)` e `(2,3,4)` sem arestas explícitas, componentes apenas por edges = `1,1,1,1,1,1`; por edges **e faces** = `1,5`. Portanto, particionamento apenas por arestas não é suficiente como invariante estrutural nas fixtures abstratas. Não extrapolar essa geometria fake para validade no Blender real.

**Orçamentos:** 300s total vs 45s/par; 2 milhões estados total vs 250 mil/par; 2GiB memória temporária estimada vs 512MiB/par. Os tetos são coerentes entre si, mas não garantem terminar operações nativas dentro do prazo nem impedir OOM físico. O contrato exige erro tipado e zero `remove` caso qualquer fase **anterior à remoção** falhe, mesmo depois de grupos seguros calculados. Uma falha após a primeira chamada `remove` não pode prometer zero alterações: exige reconciliação e relato de estado incerto.

**Referências:** um vínculo de membro de Collection/Scene não bloqueia por si só; se um sobrevivente consome o conteúdo transitivamente via instancing/Geometry Nodes, aborta. Parents/constraints/drivers/IDProperties de sobreviventes para drop abortam. Saídas de drop para keep podem ser permitidas se comprovadamente não deixam consumidor sobrevivente afetado. Referência incompreendida gera **aborto global**; `user_map()` não equivale a prova de semântica, e scripts externos constituem risco residual não exaustivamente auditável.

**Ranking:** maior número de modifiers vence sempre, mesmo se contender com Shape Keys; empate: maior número de shape key blocks, depois nome. `KEEP` linked pode ser mantido como somente leitura sob prova; `DROP` linked/indirect/override/readonly dispara aborto, não reordenação conveniente. Remover apenas Object; `Mesh` compartilhado não deve ser apagado.

## 5. Condições obrigatórias para a próxima candidata

1. Master consolidar A/B e aceitar formalmente o adendo subordinado à especificação congelada; registrar qualquer conflito que precise decisão do proprietário.
2. Desenvolvedor criar **novo** `remover_duplicatas_blend_v1_0_1.py`, com diff da baseline e SHA próprio. Não editar a baseline.
3. Provar com mocks/fakes: cobertura real de owner/target, instancing indireto, Text/driver dinâmico detectável, shared Mesh com NaN, vetos linked, ranking, abortos globais antes de exclusão, zero `remove` após timeout tardio, ledger e reconciliação triestatal quando falha durante/entre remoções. Os testes não devem alegar comprovar o RNA real.
4. Provar com oráculo independente: positivos e negativos certificados, ciclos orientados, multiconjuntos, 17-gon, vértices coincidentes, casos regulares Rook/Shrikhande, escala adversarial e invariantes de hipergrafo. Nunca aceitar hash/WL como prova positiva.
5. Medir e documentar limite proposto em máquina controlada; estresse de memória/tempo em processo isolado antes de progredir para Blender, sem mascarar OOM não capturável.
6. Reauditoria cega A/B **da nova candidata**, depois autorização explícita futura para Blender 5 em cópias descartáveis. Até então, produção permanece HOLD.

## 6. Vereditos separados

| Gate | Decisão A |
|---|---|
| Suficiência documental de R2 para o Master encaminhar implementação | **GO DOCUMENTAL PARA IMPLEMENTAR** |
| Prova de correção da futura v1.0.1 | **INCONCLUSIVO — não existe** |
| Acesso ao Blender 5.0.0 e arquivos `.blend` | **HOLD — não autorizado** |
| Distribuição/produção | **HOLD** |

Nada neste parecer autoaprova a própria candidata, ratifica unilateralmente uma alteração dos requisitos ou dispensa a auditoria independente B.
