# PROMPT FUTURO - Auditor A da candidata Blender Dedup v1.0.1

USAR SOMENTE DEPOIS QUE O MASTER ENTREGAR A NOVA CANDIDATA CONGELADA, HASHES E QA.

Sua missao e auditoria cega independente, apenas offline, sobre a candidata v1.0.1 nova. Nao consultar parecer futuro B e nao editar candidato. Leia baseline, R1-R5, R1/R2, Master R2, diff e testes.

Foco: exatidao geometrica sob permutacao arbitraria; oraculo de bijecao global, multiset edge e face orientada, automorfismos SEM-01, vertex coincidente, faces/loops longos, 6+8 vs 7+7, grafo regular, quantizacao em fronteiras. Confirmar validacao NaN/Inf/overflow mesmo em mesmo Mesh pointer, nenhum falso negativo silencioso de budget e nenhum falso positivo por prefiltragem. Testar recursos/perf/memoria em fakes controlados, sem `bpy` real ou `.blend`.

Reexecutar suite anterior adaptada contra CODIGO NOVO. Entregar ZIP com hash, matriz G01-G14, achados por severidade, fixtures negativas/positivas, logs e veredito GO/HOLD/INCONCLUSIVO **somente para codigo offline**. Nao homologar Blender real nem producao.
