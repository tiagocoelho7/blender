# Matriz G01–G14 — rechecagem do ADENDO R2, Auditor A

**Regra:** `SUFICIENTE DOCUMENTAL` valida a instrução de projeto, NÃO a execução na v1.0.1 inexistente. Todos os critérios em runtime seguem NÃO TESTADOS.

| Gate | Parecer documental | Localizador R2 | Prova de implementação ainda necessária |
|---|---|---|---|
| G01 | **SUFICIENTE** | AD-R2-01, linhas 9–25 | Grafo por drop, owners ID, lifecycle, paths RNA, scans e contagem por fonte |
| G02 | **SUFICIENTE** | AD-R2-01, linhas 16–21, 27, 31 | Permitir membership simples; abortar instancing transitivo consumido |
| G03 | **SUFICIENTE** | AD-R2-01, linhas 23–28, 31 | Material/IDProperty/nodes/driver; desconhecido => zero `remove` |
| G04 | **SUFICIENTE** | AD-R2-01, linha 29 | Nunca substituir target por keep devido apenas à geometria |
| G05 | **SUFICIENTE** | AD-R2-02, linhas 35–39 | SEM-01 positivo; winding distinguível negativo; testemunha de bijeção |
| G06 | **SUFICIENTE COM RESSALVA** | AD-R2-03, linhas 45–65 | Cobrança de memória e orçamento em cada operação crítica; abortos antes de qualquer mutação |
| G07 | **SUFICIENTE** | AD-R2-06, linhas 97–99 | Positivos/negativos, grafos simétricos, n-gons, C01–C24 futuros, testemunhas |
| G08 | **SUFICIENTE** | AD-R2-04, linha 81 | Ranking absoluto modifiers > shape keys > nome, sem desvio por facilidade de editar |
| G09 | **SUFICIENTE** | AD-R2-04, linhas 69–81 | KEEP/DROP/Mesh shared/linked/override/indirect/readonly/multi-scene |
| G10 | **SUFICIENTE COM RESSALVA** | AD-R2-05, linhas 83–93 | Ledger prévio, três estados, interrupção fase 3 inclusive fora da chamada remove |
| G11 | **SUFICIENTE** | AD-R2-06, linhas 97–101 | Script novo, SHA/diff/logs/manifestos, gate de Blender autorizado posteriormente |
| G12 | **SUFICIENTE COM RESSALVA** | AD-R2-02 linha 41, AD-R2-03 linha 65 | 5 casas float32/rint, fronteiras, `NaN/Inf` em datablock compartilhado (M01) |
| G13 | **SUFICIENTE** | AD-R2-01, linhas 24–27, AD-R2-07 linha 106 | Detectado-incerto => aborto; informar risco de scripts externos ao proprietário |
| G14 | **SUFICIENTE** | AD-R2-06 linha 101 | Blender 5.0 só com nova autorização em cópias descartáveis |

**Resultado:** 14/14 critérios suficientes como especificação; 0/14 validados em implementação v1.0.1. As 3 ressalvas são testes/ajustes de implementação, não afirmação de comportamento existente.
