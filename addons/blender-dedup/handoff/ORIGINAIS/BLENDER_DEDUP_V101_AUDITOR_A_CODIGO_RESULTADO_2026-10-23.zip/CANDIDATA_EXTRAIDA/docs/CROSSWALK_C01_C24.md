# C01–C24 — cobertura pelo novo código, apenas simulada

Os C01–C24 provêm do Auditor B antigo. A correspondência abaixo testa o **código novo** em fixtures B F01–F32 e testes de integração do executor. Não substitui a legalidade no Blender 5.0 real.

| C | Correspondência executada v1.0.1 | Estado |
|---|---|---|
| C01 | F01 / `test_basic_rank_and_automatic_remove` | P-S |
| C02 | F03 / multi-scene | P-S |
| C03 | F04 / `test_child_parent_target_drop_abort` | P-S |
| C04 | F05 / constraint | P-S |
| C05 | F06 / material driver | P-S |
| C06 | F08 / modifier target | P-S |
| C07 | F07 / custom IDProperty | P-S |
| C08 | F30 / nonmesh owner | P-S |
| C09 | HIPOTÉTICO: `Scene.camera` MESH e TimelineMarker.camera | **NÃO EXECUTÁVEL LEGALIDADE DESCONHECIDA** |
| C10 | F09 / Collection instanciada | P-S |
| C11 | F10 / Collection Info via NodeTree | P-S |
| C12 | F14 / saída do DROP para KEEP | P-S |
| C13 | F18 / linked DROP | P-S |
| C14 | F20 / override DROP | P-S |
| C15 | F19 / readonly DROP | P-S |
| C16 | F23 / `test_shared_mesh_removes_object_only` | P-S |
| C17 | F25 / grupo seguro antes de inseguro | P-S |
| C18 | `test_nonisomorphic_symmetric_last_bucket_fail_closed` | P-S |
| C19 | F24 / modo EDIT | P-S |
| C20 | F29 / `test_user_map_mismatch_abort` | P-S |
| C21 | F22 / `test_linked_keep_can_remain` | P-S condicional, sem reranking |
| C22 | F17 / `test_text_alias_indirect_lookup_abort` | P-S com limitação Python externo |
| C23 | `test_remove_failure_after_effect_stops`, KeyboardInterrupt | P-S |
| C24 | `test_remove_failure_on_last_call_stops` | P-S |

P-S = PASS sintético, **não é prova Blender 5.0**. A variante do contrato C21 “GO mesmo com KEEP não editável” exige verificação real do Blender. O C09 continua inconclusivo em runtime pela própria hipótese da API.
