# Matriz G01–G14 — verificação da implementação v1.0.1

**Legenda:** `P-S` = passou em prova sintética/estática; `R` = requer runtime real; `PARCIAL` = cobertura incompleta/hipótese não homologada.

| Gate | Estado agora | Evidência | Pendência |
|---|---|---|---|
| G01 Inventário incoming | P-S / R | `ReferenceScanner`, test IDs/fake owners, ledger | Cobertura real bpy/RNA e user_map |
| G02 Membership/instancing | P-S / R | `verify_B_graph32_on_candidate.py` F02/F03/F09/F11/F31 | Embedded collections reais |
| G03 RNA nested/IDProps/drivers/NodeTrees | P-S / PARCIAL | `test_candidate_v101.py` e F06/F07/F32 | Verificar tipos RNA, arrays omitidos, owners desconhecidos |
| G04 Sem remapeamento | P-S | Diff/inspeção de código: apenas `objects.remove`, nenhum setters | Revalidar estático pelos auditores |
| G05 Bijeção/topologia/SEM-01 | P-S | Oráculos A 266 + 2.649; `test_sem_01` e 17-gon | Malhas Blender reais com índices reorganizados |
| G06 Budgets e fail-closed | P-S / R | Rook-vs-Shrikhande, late-bucket, OOM e memória | Calibrar valores e limites físicos reais |
| G07 Oráculo e C01–C24 | P-S / PARCIAL | A 266 + 2.649, B 32, 57 novos, crosswalk C01–C24 | Casos API hipotéticos e runtime legalidade dos mocks |
| G08 Ranking absoluto | P-S | tests modifier-over-shape-key/name | Testar flags de library em Blender |
| G09 Linked/readonly/shared/edit | P-S / R | testes linked-drop/keep, overrides, edit, owner membership | Combos efetivos Blender 5.0 |
| G10 Ledger/falha parcial | P-S / R | tests remove/print/KeyboardInterrupt antes/depois | session_uid e callbacks reais |
| G11 Custódia/diff | P-S | baseline e especificação intactos, diff, manifestos | Auditor independente deve conferir hashes |
| G12 Quantização/não-finito/alias | P-S | NaN mesmo pointer, Inf, overflow, testes 5 casas | Validar numeric do RNA float32 real |
| G13 Text/script/nome | PARCIAL / R | testes de Text, IDProperty string, AST alias, documentação | Python arbitrário e scripts externos não detectáveis integralmente |
| G14 Blender somente com autorização | P-S | logs apenas Python offline, `bpy is None` | Teste Blender real depende de autorização futura |

**Parecer do executor:** nenhuma linha desta matriz equivale a homologação de Blender real. G03, G07, G13 e demais linhas marcadas `R` impedem GO para produção.
