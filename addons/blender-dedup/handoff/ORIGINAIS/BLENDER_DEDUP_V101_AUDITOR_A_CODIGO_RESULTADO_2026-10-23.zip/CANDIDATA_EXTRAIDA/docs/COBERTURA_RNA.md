# Superfícies de referência e limites explícitos da inspeção

| Superfície | Como é inspecionada | Classe potencial | Evidência offline / pendência |
|---|---|---|---|
| `Object.parent`, constraints, modifiers e campos ID em Object | Recursão RNA `POINTER`/`COLLECTION` | Direta | Mock testado; RNA Blender não executado |
| Objetos de `Collection.objects`/`Scene.objects`/view layer | RNA com paths estruturais | Membership autorizada | Mock F02/F03/F31; multi-scene real pendente |
| `Object.instance_collection` e ancestrais `Collection.children` | Fecho transitivo de Collections afetadas | Indireta | Mock F09/F11; comportamento real pendente |
| `NodeTree.nodes`, `NodeSocket`, Geometry Nodes | Recursão RNA, ID incluído no inventário | Direta ou indireta | Mock F10/F13/F32; tipos Blender pendentes |
| Material/World driver e `animation_data` | Recursão em ID, RNA nested | Direta | Mock material-driver; Blender pendente |
| IDProperties em ID e RNA structs | Recursão aninhada incluindo Object ID refs, grupos, arrays numéricos | Direta | Mocks pointer/list/números; subclasses Blender pendentes |
| Outros IDs persistentes, até mesmo orphan | Enumerar collections RNA em `bpy.data` e ID embutidos referenciados | Direta ou indireta | Mock NodeTree orphan; Blender pendente |
| `bpy.data.user_map(subset=drops)` | Conferir owners de referência conhecidos, abortar discrepâncias | Cruzamento, não prova exclusiva | Mock divergência e falha; Blender pendente |
| `bpy.data.texts`, driver expressions e IDProperty strings | Padrão de lookup e AST para aliases simples | Suspeita de dependência por nome | Mock direto/alias; não cobre Python arbitrário |
| `Mesh.vertices/edges/polygons/loops` e outros arrays numéricos listados em código | Excluídos do scanner de IDs, mas usados na **comparação geométrica** | Exceção por hipótese | Requer confirmação de ausência de ID pointers no RNA real |
| `Object.children`, `users_collection`, `users_scene` e `Collection.all_objects` | Backlinks derivados omitidos, forward refs avaliadas | Exceção por hipótese | Requer runtime real |
| Scripts externos/add-ons e acesso indireto por `eval`, `getattr`, renames posteriores | Não há inspeção completa possível por snapshot local | DESCONHECIDO | Risco residual; decisão Master/proprietário antes de produção |

Falha em enumerar qualquer superfície requerida aborta antes do primeiro `remove`. `excluded_by_assumption` aparece no ledger para tornar visíveis as exclusões assumidas, sem afirmar cobertura comprovada.
