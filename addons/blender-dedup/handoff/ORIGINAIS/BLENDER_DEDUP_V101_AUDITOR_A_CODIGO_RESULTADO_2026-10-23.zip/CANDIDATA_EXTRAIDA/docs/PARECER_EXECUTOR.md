# Parecer do executor — Blender Dedup v1.0.1

Data: 2026-10-22. Escopo: implementação NOVA a partir de baseline congelada com plano R2 aprovado documentalmente. Nenhum Blender real foi executado.

## Decisão

**ENTREGUE PARA AUDITORIA INDEPENDENTE DE CÓDIGO, SEM GO DE BLENDER OU PRODUÇÃO.** A candidata está pronta para exame adversarial pelos Auditores A/B, não homologada. Não houve autorização ou execução em projeto real do usuário.

## Modificações relevantes frente à v1.0

- Preflight em três fases lógicas: validação de todas as malhas-base e classificação de clusters; inventário conservador de referências e elegibilidade de DROPs; emissão de ledger completo antes do primeiro `remove`.
- Identidade Mesh compartilhada não contorna validação `NaN`/`Inf`/overflow; `np.float32` convertido para `float64` antes da quantização de 5 casas.
- Mantida comparação por bijeção global: faces orientadas preservadas até rotação do ciclo, arestas não direcionadas e multiplicidade relevante.
- Budgets cooperativos de tempo, estados, pares, RSS, estimativa de alocações e bucket; complexo/inconclusivo => ABORTO GLOBAL preflight.
- Inventário RNA aninhado em IDs de `bpy.data`, IDProperties aninhadas, Text/driver lookup detectável, Collection instanciada/consumida, user_map de cruzamento. Referências de surviving IDs para DROP abortam. Membership ordinária permitida quando owner editável.
- Priorização determinística de modifiers sobre shape keys; DROP linked/readonly/indirect/override/EDIT/evaluated => aborto global; KEEP linked pode permanecer sem alteração.
- Exclusão automática **sem remapeamento**, **sem salvar**, com ledger anterior e reconciliação conservadora em falha parcial de fase 3.

## Evidências obtidas no código novo

| Prova | Resultado | Natureza |
|---|---:|---|
| Testes unitários/integrados em fake bpy | 57/57 | Somente offline |
| Oráculo independente A R2 adaptado à v1.0.1 | 266/266 | Geometria sintética |
| Oráculo do Auditor A antigo adaptado | 2.649/2.649 | Geometria sintética |
| Casos de grafo B R2 F01-F32 adaptados | 32/32 | Dependência sintética |
| 1M vértices/999.999 arestas por malha | igualdade detectada | Buffer NumPy sintético |
| Rook vs Shrikhande, todos coincidentes | orçamento interrompe sem resposta errada | Sintético, falso positivo rejeitado |

## Riscos ainda não cobertos

- **ALTO — RNA real não executado:** o scanner pode falhar fechado frequentemente na instalação Blender 5.0, pode omitir referências por nomes em código externo ou usar hipóteses sobre arrays primitivos que dependem de verificação do runtime. Não há prova de completude de introspecção.
- **ALTO — efeitos não transacionais:** handlers/callbacks podem alterar dependências durante a fase de exclusão; não é possível prometer rollback nem atomicidade apenas com Python.
- **MÉDIO — desempenho em geometrias reais:** NumPy em buffers diretos é mais rápido que proxies/malhas reais; orçamentos numéricos são propostas não calibradas para PC/estátuas do usuário.
- **MÉDIO — Text/scripts externos:** detecção por padrões e AST simples não cobre `eval`, indireção arbitrária, módulos externos, código executado depois da limpeza ou aliases complexos.
- **MÉDIO — políticas do Blender:** exigem testes reais objetos linked/overrides, Collection/Scene readonly, NodeTrees embedded/orphan e confiabilidade de `session_uid` para reconciliar.

## Conclusão operacional

GO para **duas auditorias independentes OFFLINE da candidata congelada**. HOLD para teste Blender real, HOLD para instalação e utilização nos `.blend` produtivos. Preservar os hashes do artefato nesta entrega.
