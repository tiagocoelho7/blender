# Limites conhecidos / prioridades para reauditoria

1. **P0 em potencial:** verificabilidade do inventário completo de referências em Blender 5.0 real; lógica desenvolvida a partir de API documental e mocks. Um RNA não coberto deve abortar, mas hipóteses de exclusão de arrays/backlinks precisam ser examinadas.
2. **P0 em potencial:** acesso via nomes em scripts externos e Python arbitrário (não inspecionável completamente) — a presença de scripts no blend é examinada por padrões e AST simples; false-safe por indireção avançada é possível. Requer política residual explícita.
3. **P1:** fase de exclusão não atômica; se handlers alterarem semântica entre preflight e chamada `remove`, não há rollback garantido. Ledger precisa passar por Blender real.
4. **P1:** budget de RSS só é conhecido quando amostra SO está disponível; são limites cooperativos, não quotas rígidas; defaults sugeridos não calibrados com estátuas reais.
5. **P1:** `user_map` e NodeTree orphan/embedded são mockados; varredura de Object/Collection/Scene de Blender e `ID.session_uid` devem ser validadas em cópia e com autorização.
6. **P1:** algoritmo de isomorfismo pode abortar em grafos simétricos ambíguos (não inferir desigualdade). O usuário proíbe falsos negativos decorrentes dos índices, então a execução não deve apagar outros objetos se houver qualquer caso indecidível.
7. **P2:** arquivo `.blend` salvo anteriormente pode conter referências por string externa não expressas em RNA; nenhum classificador estático prova ausência de automação futura.

**Separar vereditos:** GO de auditoria offline de código ≠ GO para testes em Blender real ≠ GO para produção. Arquivo destrutivo disponível somente para inspeção.
