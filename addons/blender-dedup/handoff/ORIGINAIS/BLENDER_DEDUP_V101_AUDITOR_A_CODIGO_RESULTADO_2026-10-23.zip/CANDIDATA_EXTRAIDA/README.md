# Blender Dedup v1.0.1 — candidata de implementação OFFLINE

**Status: candidata para duas auditorias independentes A/B. NÃO HOMOLOGADA. Produção HOLD.**

O projeto remove objetos `MESH` com malhas-base topologicamente equivalentes, independentemente dos índices dos vértices e de G/R/S, collections, materiais, UV, modifiers e shape keys. Preserva a cópia com **mais modifiers**, depois **mais shape key blocks**, depois **nome em ordem alfabética** (seguido de identificador de sessão no caso de empate absoluto).

## Atenção à exclusão

A implementação (`src/remover_duplicatas_blend_v1_0_1.py`) é um script **destrutivo quando executado dentro de Blender real**: após preflight inteiramente bem-sucedido, chama `bpy.data.objects.remove(..., do_unlink=True)` automaticamente. **Não salva** o `.blend`. Nenhum Blender real, `.blend` ou projeto do usuário foi acessado na presente rodada. NÃO EXECUTAR a candidata nos arquivos do usuário enquanto os gates A/B e Blender real não forem aprovados.

O preflight aborta globalmente, com **ZERO remove**, quando a comparação é inconclusiva, o orçamento estoura, há coordenadas não finitas, RNA/IDProperty não inspecionável, `user_map` divergente, referência funcional potencialmente afetada ou DROP não elegível. A fase de exclusão não é transacional: se um `remove`/logger/handler falhar, a execução interrompe novas remoções e produz reconciliação conservadora (`CONFIRMADO_REMOVIDO`, `CONFIRMADO_PRESENTE`, `INDETERMINADO`). Não há rollback.

## Estrutura

- `src/`: candidata nova Python, não altera baseline.
- `docs/`: parecer executor, matriz G01–G14, tabela das superfícies RNA, diff unificado e correspondência C01–C24.
- `qa/`: suítes realmente executadas **contra a candidata nova**, adaptadas de A/B e testes adicionais em mocks.
- `evidencias/`: stdout dos testes, JSONs e benchmark offline.
- `originais/master_r2/`: extração do handoff Master aprovado para implementação, contendo especificação, plano, adendo, parecer, originais A/B e QA de referência inalterados.
- `originais/remover_duplicatas_blend_v1.py`: cópia de baseline congelada.
- `SHA256SUMS.txt` e `MANIFESTO.json`: integridade e contexto.
- `AUDITOR_A/` e `AUDITOR_B/`: prompts de próxima rodada cega de código.

## Testes offline reproduzidos

A partir da raiz deste diretório, com Python + NumPy (e networkx para o benchmark/suite tardia):

```bash
python -m unittest discover -s qa -p 'test_candidate_v101.py' -v
python qa/oracle_A_adapted_to_candidate.py src/remover_duplicatas_blend_v1_0_1.py evidencias/oracle_A_candidate_results.json
python qa/audit_A_geometry_adapted.py src/remover_duplicatas_blend_v1_0_1.py
python qa/verify_B_graph32_on_candidate.py
python qa/benchmark_v101.py
```

Resumo do replay local: **57/57** testes de integração sintética; **266/266** oráculo independente A R2; **2.649/2.649** comparações de geometria A antiga adaptada; **32/32** cenários do grafo B R2 adaptados para testar de fato a candidata. Benchmark sintético de **1 milhão de vértices por malha, 999.999 arestas, sem faces**, com reindexação completa: igualdade reconhecida; ver `evidencias/benchmark_v101.json`. Outro teste de grafos adversariais realizou **aborto inconclusivo** por limite de estados, não uma decisão falsa.

Estes testes são executados com simulações: NÃO validam comportamento do RNA, do `user_map`, de `bpy.data.objects.remove` nem custo de malhas reais no Blender 5.0.0. O benchmark usa buffers NumPy otimizados e não é estimativa de desempenho nos arquivos do proprietário.

## Limites cooperativos propostos R2 (NÃO calibrados)

Tempo total 300 s; por comparação 45 s; máximo 50.000 comparações; até 2.000.000 estados globais, 250.000 por par; orçamento incremental RSS global 2 GiB; estimativa temporária por par 512 MiB; bucket máximo 2.048 objetos; até 2.000.000 nós RNA; Text até 8 MiB. `Limits(...)` permite ajuste, somente após revisão. Não são garantias físicas de memória/tempo do sistema operacional. Sem medição RSS, preflight se recusa a prosseguir.

## Pontos de atenção para A/B

1. Escaneamento RNA de propriedades de `bpy.data`, nested RNA e IDProperties sem validação no Blender real. Algumas coleções primitivas da geometria e backlinks calculados são excluídos **por hipótese explícita**, relatada no ledger (`excluded_by_assumption`), não por prova runtime.
2. Scripts externos, add-ons e código Python dinâmico arbitrário podem acessar objetos por nome e escapar da inspeção local. Algumas chamadas em Text/expressões são detectadas e bloqueadas, mas não há garantia de cobertura completa.
3. `user_map` é cruzamento de IDs, não prova isolada da semântica de uma dependência. Relações de membership comuns são permitidas; conteúdo de Collection consumida por sobrevivente é bloqueado.
4. Não há atomicidade/rollback de `objects.remove`; alterações feitas por handlers após preflight são risco residual.
5. C01–C24 e G01–G14 têm lacunas de runtime real documentadas. Não se auto-homologa a candidata pelo sucesso destes testes.

## Próximo passo

Entregar ZIP A ao Auditor A e ZIP B ao Auditor B sem compartilhar conclusões entre eles. O Master consolidará achados e, **somente com autorização explícita futura**, avaliará testes em `.blend` descartáveis no Blender 5.0.0. Nenhuma autorização para produção foi dada.
