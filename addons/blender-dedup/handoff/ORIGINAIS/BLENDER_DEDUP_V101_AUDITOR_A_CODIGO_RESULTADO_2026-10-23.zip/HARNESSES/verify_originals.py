"""Verify bundled input ZIP against extracted files and declared manifests."""
import hashlib,json,pathlib,re,sys,zipfile
base=pathlib.Path(__file__).resolve().parents[1]
original=base/'CANDIDATA_EXTRAIDA'
zips=list((base/'ORIGINAIS').glob('*.zip'));assert len(zips)==1
bad=[]
with zipfile.ZipFile(zips[0]) as z:
 for p in z.namelist():
  disk=original/p
  if not disk.is_file() or hashlib.sha256(disk.read_bytes()).digest()!=hashlib.sha256(z.read(p)).digest():bad.append(p)

def verify_sums(root,name):
 checked=0
 for line in (root/name).read_text().splitlines():
  m=re.fullmatch(r'([a-fA-F0-9]{64})\s+\*?(.+)',line)
  if not m:bad.append('sum format '+line);continue
  sha,path=m.groups();checked+=1
  f=root/path
  if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=sha.lower():bad.append(str(name)+':'+path)
 return checked
count1=verify_sums(original,'SHA256SUMS.txt')
count2=verify_sums(original/'originais/master_r2','SHA256SUMS.txt')
manifest=json.loads((original/'MANIFESTO.json').read_text())
for x in manifest['entries']:
 f=original/x['path']
 if not f.is_file() or f.stat().st_size!=x['bytes'] or hashlib.sha256(f.read_bytes()).hexdigest()!=x['sha256']:bad.append('manifest:'+x['path'])
print(json.dumps({'zip_members':len(list(zipfile.ZipFile(zips[0]).namelist())),'sum1':count1,'sum2':count2,'manifest_entries':len(manifest['entries']),'mismatches':bad},indent=2))
sys.exit(bool(bad))
