#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
export PYTHONDONTWRITEBYTECODE=1
export DEDUP_RESULT_DIR="$BASE/REPLAY_GERADO"
mkdir -p "$DEDUP_RESULT_DIR"
python "$BASE/HARNESSES/verify_originals.py" > "$DEDUP_RESULT_DIR/integrity_replay.log"
TEMP=$(mktemp -d)
trap 'rm -rf "$TEMP"' EXIT HUP INT TERM
cp -R "$BASE/CANDIDATA_EXTRAIDA/." "$TEMP/"
( cd "$TEMP" && python -m unittest discover -s qa -p 'test_candidate_v101.py' -v ) > "$DEDUP_RESULT_DIR/unit.log" 2>&1
( cd "$TEMP" && python qa/oracle_A_adapted_to_candidate.py src/remover_duplicatas_blend_v1_0_1.py "$DEDUP_RESULT_DIR/oracle_A.json" ) > "$DEDUP_RESULT_DIR/oracle_A.log" 2>&1
( cd "$TEMP" && python qa/audit_A_geometry_adapted.py src/remover_duplicatas_blend_v1_0_1.py ) > "$DEDUP_RESULT_DIR/geometry.log" 2>&1
( cd "$TEMP" && python qa/verify_B_graph32_on_candidate.py ) > "$DEDUP_RESULT_DIR/graph32.log" 2>&1
( cd "$TEMP" && python qa/benchmark_v101.py ) > "$DEDUP_RESULT_DIR/large_benchmark.log" 2>&1
python "$BASE/HARNESSES/independent_geometry_oracle.py" > "$DEDUP_RESULT_DIR/independent_geometry.log" 2>&1
python "$BASE/HARNESSES/adversarial_references.py" > "$DEDUP_RESULT_DIR/adversarial_references.log" 2>&1
python "$BASE/HARNESSES/run_memory_samples.py" > "$DEDUP_RESULT_DIR/adversarial_memory.log" 2>&1
python "$BASE/HARNESSES/adversarial_deadline.py" > "$DEDUP_RESULT_DIR/adversarial_deadline.log" 2>&1
echo 'OFFLINE REPLAY COMPLETE. Reports under REPLAY_GERADO/'
