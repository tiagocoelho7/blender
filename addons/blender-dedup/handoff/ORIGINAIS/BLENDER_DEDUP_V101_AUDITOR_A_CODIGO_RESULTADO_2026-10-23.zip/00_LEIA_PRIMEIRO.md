# Auditoria A independente - Codigo Blender Dedup v1.0.1 - 2026-10-23

**Veredito: HOLD para avancar ao proximo gate**, condicionado a correcoes e reauditoria offline; nao ha autorizacao para Blender real nem producao.

Conteudo:
- `01_PARECER_A_CODIGO_V101.md`: parecer tecnico, riscos e contraprovas.
- `02_MATRIZ_G01_G14.md`: matriz de gates independente.
- `03_PROMPT_CONTINUIDADE_MASTER.md`: handoff para Master.
- `04_REPRODUCAO.md`: comandos e limites de testes.
- `EVIDENCIAS/`: logs da execucao neste ambiente.
- `HARNESSES/`: testes sintenticos proprios e replay integral.
- `CANDIDATA_EXTRAIDA/`: conteudo integral recebido, inalterado.
- `ORIGINAIS/`: ZIP original recebido, para conferir custodia.
- `MANIFESTO_AUDITOR_A.json` e `SHA256SUMS_AUDITOR_A.txt`: hash de todo conteudo (exceto manifestos autoreferentes).

**PERIGO:** a candidata `CANDIDATA_EXTRAIDA/src/remover_duplicatas_blend_v1_0_1.py` e destrutiva se executada no Blender. **NAO EXECUTAR no Blender real ou em .blend do proprietario.** O unico comando de replay autorizado por este pacote e `sh HARNESSES/replay_all_offline.sh`, em Python externo sem bpy, com as dependencias ja instaladas. O runner nao abre nenhum `.blend`.
