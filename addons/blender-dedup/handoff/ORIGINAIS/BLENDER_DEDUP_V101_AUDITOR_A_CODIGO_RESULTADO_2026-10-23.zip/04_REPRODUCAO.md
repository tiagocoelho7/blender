# Reproducao offline

Requer Python externo, numpy, networkx. Nenhum teste roda bpy nem abre `.blend`.

A partir da raiz do ZIP descompactado:

```sh
python HARNESSES/verify_originals.py
sh HARNESSES/replay_all_offline.sh
```

O runner copia a candidata para diretorio temporario antes de rodar suites do executor que escrevem JSON, e deposita evidencias novas sob `REPLAY_GERADO/`. Testes proprios em `HARNESSES/` fazem import do modulo em `CANDIDATA_EXTRAIDA/src`, mas nunca chamam `run_blender()`, e nao executam `bpy` real. Sao usados callbacks e objetos fake explicitamente.

Para probe individual (subprocesso com timeout externo recomendado):

```sh
python HARNESSES/independent_geometry_oracle.py
python HARNESSES/adversarial_references.py
python HARNESSES/run_memory_samples.py
python HARNESSES/adversarial_deadline.py
```

O probe `run_memory_samples.py` limita externamente a 8s por n; a rotina principal utiliza n=100/200/240, todos pequenos. O replay nao configura hard cap de RSS do sistema, nao e substituto de validacao no Blender. Logs originais executados nesta sessao ficam preservados em `EVIDENCIAS/`.

O benchmark de 1M vertices opera com NumPy fake, buffers ja construidos em memoria, nao representa tempo de carregamento/sistema Blender real. Nenhuma informacao sobre arquivo real de cliente e produzida.
