# Matriz G01-G14 - Auditor A independente (codigo v1.0.1)

| Gate | Estado A | Evidencia / pendencia |
|---|---|---|
| G01 incoming | **HOLD/P0** | REF-01/02 mudanca de referencias depois de inventario; P2 user_map one-way; ledger parcial |
| G02 membership instancing | PASS sint., RUNTIME PENDENTE | F02/F03/F09/F11/F31, nao Blender real |
| G03 nested RNA/IDProps | PASS PARCIAL | 57/57 e 32/32 em mocks; completude Blender nao demonstrada |
| G04 sem remap | PASS estatico | Apenas `objects.remove` no script, sem `data.meshes.remove` |
| G05 geometria | PASS sint. | A 266, A 2649, oraculo independente 400/400 |
| G06 budgets | **HOLD/P1** | memoria por par subestimada; deadline cooperativo atrasado em busca ambigua |
| G07 regressao/C01-C24 | PASS sint. PARCIAL | B F01-F32 32/32, legalidade API desconhecida em C09 |
| G08 ranking | PASS sint. | Modifiers > shape keys > nome, 57/57 |
| G09 flags/multi-scene | PASS sint., RUNTIME PENDENTE | fake linked/readonly/overrides/EDIT/shared |
| G10 ledger/reconcile | **HOLD/P0-P2** | sucesso incorreto sob referencia adicionada por callback; campos incompletos |
| G11 custodia | PASS | SHA 62/62; nested 34/34; patch reproduce SHA |
| G12 quantizacao | PASS sint. | NaN/Inf/overflow e pointer compartilhado |
| G13 script name | **HOLD/P1** | dois aliases simples nao detectados; Python externo residual |
| G14 restricao real | CONFORME | Nenhum bpy/Blender real, `.blend` ou producao executado |

**Estado global:** HOLD para avancar ao proximo gate; nao e HOLD da geometria comprovada em testes sinteticos.
