# Parecer tecnico independente A - Blender Dedup v1.0.1 (CODIGO)

**Data:** 2026-10-23. **Objeto:** `src/remover_duplicatas_blend_v1_0_1.py`, SHA-256 `1d4175b1190732ea6077232b32d4fd632021f99c9ccb80e5ba15dd5e4dcb9956`. **Modo:** auditoria cega desta rodada, somente offline, sem consultar conclusoes B.

## 1. Veredito

**HOLD PARA AVANCAR AO PROXIMO GATE** de execucao/avaliacao em Blender, sem homologacao. A candidata satisfaz as principais provas sinteticas de igualdade geometrica, mas possui contraprovas executadas que deixam a fronteira preflight/exclusao exposta e nao cumprem adequadamente os limites cooperativos sob topologias degeneradas. Requer revisao, candidato novo com hash proprio e reauditoria A/B antes de qualquer escalonamento.

Classificacao: **1 P0, 3 P1 e 2 P2** nesta rodada. Severidades refletem risco para integridade do arquivo, nao prova de exploracao em Blender real. A executabilidade de alguns cenarios depende de callback/handler que existe no mock e cuja possibilidade real precisa ser comprovada.

## 2. Cadeia de custodia

- ZIP de entrada SHA-256 `6329e17c87d5cdd6af603ecb99c76e333dc302549f84d6c1de3f9bb352acf5a2`, com 64 membros.
- SHA256SUMS principal: **62/62** entradas conferidas. MANIFESTO.json: **62/62** caminhos/tamanhos/hashes conferidos. Manifesto aninhado Master R2: **34/34** hashes conferidos. Sem divergencias.
- Baseline congelada: `f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3`; copia aninhada identica.
- Especificacao R1-R5: `2d1aa740b4ec7a42307dcec253fbce23f452ad45249fa35585bd12a6da0d3653`. Plano R1: `593ab739ebfbbbfa32e7d2f99dd568f56463081fb72c16cf53ba42cc46d2a839`.
- Diff `docs/DIFF_V1_V101.patch` reproduz EXATAMENTE o arquivo candidato apos aplicar patch apenas em copia descartavel (mesmo SHA-256).
- Arquivos de origem/candidata nao modificados. Suite original que salva evidencias foi reexecutada sobre copia de trabalho, preservando os originais.

## 3. Reproducao independente e positiva

| Prova offline | Resultado | Alcance |
|---|---:|---|
| Suite de integracao do executor | 57/57 | fake bpy, nao Blender real |
| Oraculo A R2 adaptado | 266/266 | coordenadas/arestas/faces |
| Suite geometrica A adaptada | 2649/2649 | topologia, loops e faces |
| Casos F01-F32 adaptados | 32/32 | grafo RNA fake |
| Oraculo proprio forca bruta, seed 20261023 | 400/400 concordancias | bijecao independente e orientacao ciclica |
| Benchmark proprio reexecutado, 1M vertices e 999999 arestas por mesh | resultado equivalente em 0,743 s; RSS delta amostrado 220 MB | buffers NumPy, sem bpy; nao extrapolar para Blender |
| Rook vs Shrikhande, estados limitados | ABORT_INCONCLUSIVE_NO_DELETE | caso nao isomorfo reconhecido pelo oraculo; nao houve decisao falsa |

O oraculo proprio em `HARNESSES/independent_geometry_oracle.py` usa enumeracao de todas as bijecoes por classe de coordenada, Counter de arestas nao direcionadas e canonizacao independente das faces por rotacao. Inclui 400 amostras geradas, seed fixo, fixtures de permutacao, alteracao, faces-only e repeticoes. Este teste nao prova correcao universal.

## 4. Achados adversariais

### A101-P0-01 - Integridade muda apos preflight e exclusao declara sucesso (G01, G10)

**Contraprova efetivamente executada.** Com `Blend` fake e parametro publico `execute(..., emit=callback)`, um callback em `[T7-DEDUP-LEDGER-PRE]` configura `survivor.parent = drop` apos o inventario. O script confere apenas a lista de POINTERs do conjunto `bpy.data.objects` (nao o grafo de referencias ou fingerprints da geometria) e faz 2 `remove`. Resultado `REMOVOES_CONFIRMADAS` com `survivor.parent` apontando para o DROP ja removido.

Segunda prova: callback fake `objects.remove` cria a mesma dependencia apos a primeira chamada, apontando para o segundo DROP; o script remove o segundo e declara `REMOVOES_CONFIRMADAS`. Isso viola a expectativa de parar quando a certeza sobre as referencias deixa de existir. A candidata reconhece risco residual de handlers na documentacao, mas nao o sinaliza em `status` neste caminho.

**Limite da prova:** o primeiro caso depende de `emit` com efeito colateral (o logger padrao atual e print puro); o segundo depende de handler/efeito em remove que **nao foi demonstrado no Blender 5.0 real**. Portanto, nao e prova de que Blender real dispara essas mutacoes. E, porem, falso sucesso concretamente reproduzido na API Python da candidata com callbacks permitidos.

**Correcao exigida:** tratar callback como fronteira de confianca, eliminar callbacks com efeitos nao controlados ou revisar semantica; avaliar revalidacao/estabilizacao de snapshots de refs/flags antes das remocoes, e parada por mudanca observada entre chamadas. Para garantias impossiveis sob handlers arbitrarios, especificar condicoes e pedir decisao do Master. Nao proclamar garantia de atomicidade.

### A101-P1-02 - Text lookup importado/indireto nao detectado (G13)

**Contraprova efetivamente executada.** Text script com `from bpy import data as d; obj = d.objects[name]` e nome calculado, ou `getattr(bpy.data, "objects").get(name)`, produz `_text_lookup_risk=False`. O plano prossegue, remove 2 objetos e declara sucesso, embora o Text contenha referencia funcional potencial por nome a DROP. O C17 do executor cobre apenas padroes de lookup diretos e aliases de `objs = bpy.data.objects`.

**Limite da prova:** Text armazenado nao equivale a codigo que necessariamente sera executado; Python externo nao e completamente inspecionavel. Mesmo assim, sao dois casos Python simples detectaveis e diretamente pertinentes a AD-R2-07 (incerto detectavel -> aborto).

**Acao:** ampliar detector de alias/import/getattr ou impor politica conservadora para Text executavel/desconhecido, sem afirmar que um parser completo seria possivel. Explicitar risco residual ao proprietario.

### A101-P1-03 - Orçamento por par subestima alocacao e custo superlinear (G06)

**Contraprova efetivamente executada.** Chamada de `_ambiguous_isomorphism` em classe toda coincidente, sem arestas/faces, com cap configurado em 60.000 bytes por par. Para n=100/200/240, `allocation_bound` reporta requisicoes de 16.000/32.000/38.400 bytes; RSS incremental amostrado foi cerca de 315.392/778.240/1.032.192 bytes. A funcao retorna True, sem exceder `mem_pair_bytes` na logica. A maior parcela vem das listas de candidatos replicadas por cada vertice (e da busca).

A construcao `for a in verts_a: candidates[a]=tuple(sorted(verts_b))` duplica a lista O(g²); `frame().rank` reconta candidatos livres para cada vertice a cada frame, produzindo custo superlinear grave mesmo com grafos vazios. O caminho normal de `meshes_equal` pode pular a busca quando a indexacao ja coincide, mas a busca ambigua e necessaria quando a topologia foi reindexada.

**Limite da prova:** medicao RSS global inclui overhead Python e nao equivale exclusivamente a uso temporario do par; o budget documentado e cooperativo e nao um cap fisico. Ainda assim, a estimativa requisitada pela funcao omite deliberadamente a estrutura O(g²), contrariando o requisito de checagem previa de alocacoes.

**Acao:** candidatos compartilhados por grupo, refinamento de particoes, limite de cardinalidade/estimativa quadratica antes de construir, amostragem RSS por par e validacao sob casos degenerados.

### A101-P1-04 - Prazo cooperativo nao checado dentro de ranking (G06)

**Contraprova efetivamente executada.** Para 200 vertices coincidentes sem arestas/faces, pair_seconds=0,01 s: a chamada so abortou em 0,7504 s (75,0x o prazo), com 256 estados. `frame().rank` nao chama checkpoint dentro do duplo loop. Nao e violacao de um limite fisico/SLA (que a candidata expressamente nao promete), mas prova de falta de granularidade em area de alto custo.

**Acao:** verificacao periodica de deadline/estados nos loops de rank, refinamento previo e interrupcoes seguras; manter timeout distinto de comparacao desigual.

### A101-P2-05 - user_map comparado em um unico sentido (G01/G03)

**Contraprova efetivamente executada.** `user_map(subset=[drop])` fake retorna `set()` apesar de o scanner registrar duas memberships RNA para o DROP. `_user_map_corroborate` aceita o inventario. O algoritmo cruza apenas owners presentes no user_map mas nao no scanner, nao faz comparacao reversa.

**Limite:** na API real, nem toda relacao RNA/membership precisa ser um usuario contabilizado da mesma forma pelo user_map. Antes de exigir igualdade estrita, especificar um conjunto normalizado de relacoes comparaveis. Classificado P2 ate verificacao real.

### A101-P2-06 - Ledger incompleto frente ao contrato R2 (G01/G10)

`Reference.record` (linhas ~712-748) fornece owner, target, path, surface, category, why, drop_target, mas nao fornece campos obrigatorios completos: `owner_lifecycle` explicito, `scan_status`, `action`, `evidence` e `drop_key` para cada registro. Alem disso, `_classify` levanta excecao no primeiro bloqueio sem devolver todos os bloqueios existentes. E um deficit de auditabilidade e triagem; nao se prova que isso gera exclusao incorreta.

**Acao:** estruturar tipos de owner e justificativas por DROP; em falha, agregar diagnosticos sem prosseguir para remocoes, preservando hash e custodia.

## 5. Riscos nao encerrados

- **Blender 5.0 real NAO executado.** Legalidade das fixtures, RNA embutido/orphan, `bpy.data.user_map`, Collections/Scenes readonly, flags e `session_uid` sem validacao no runtime.
- Sem garantias para scripts externos, addons, aliases arbitrarios ou acesso a IDs por strings fora do grafo RNA. Risco reconhecido pelo executor, ainda requer politica de aceite do proprietario.
- `objects.remove` nao e transacional e nao ha rollback; testes fake de excecoes sao bons, mas nao justificam prometer exclusao segura sob handlers.
- Sem calibracao dos defaults 300 s, 45 s/par, 2 GiB RSS, 512 MiB/par em estatuas reais. Nao confundir benchmark NumPy com desempenho de Blender.

## 6. Decisao recomendada ao Master

1. **Manter HOLD.** P0-01 deve receber correcao, mitigacao ou limitacao formal antes de qualquer GO de codigo para Blender real.
2. Enderecar P1-02, P1-03 e P1-04, validar detector de lookup e protecao de orçamento.
3. Resolver P2-05/P2-06 documentalmente e manter C09/meshes Blender como runtime PENDENTE.
4. Desenvolvedor produz **nova candidata/hash** em area separada, nunca sobrepor este `v1.0.1` congelado.
5. Dois auditores independentes reexecutam contraprovas, sem partilhar conclusoes antes da fase cega. Apos GO offline combinado, Master pode solicitar autorizacao expressa do proprietario para homologacao em `.blend` descartavel com Blender 5.0.0. **Nao ha autorizacao atual para Blender real nem producao.**

**Veredito:** HOLD para avancar ao proximo gate; evidencias apenas offline.
