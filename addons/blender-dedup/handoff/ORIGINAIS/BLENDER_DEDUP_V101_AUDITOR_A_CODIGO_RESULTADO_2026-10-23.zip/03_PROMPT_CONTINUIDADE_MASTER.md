# PROMPT PARA O CHAT MASTER - FECHAMENTO AUDITOR A CODIGO V1.0.1

Voce e o Chat Master do Blender Dedup. Receba o bundle integral `BLENDER_DEDUP_V101_AUDITOR_A_CODIGO_RESULTADO_2026-10-23.zip` (hash informado no chat).

Esta e a auditoria A INDEPENDENTE do codigo novo `v1.0.1`, nao auditoria documental. Preserve hashes originais, nao edite a candidata congelada. Examine `01_PARECER_A_CODIGO_V101.md`, `02_MATRIZ_G01_G14.md`, e os harnesses/logs. Resultado A: HOLD para avancar ao proximo gate, por 1 P0, 3 P1 e 2 P2.

Fatos positivos verificados offline: 57/57, 266/266, 2649/2649, 32/32 e oraculo independente 400/400. Verificados SHA original 62/62 + aninhado 34/34 e patch produz candidata byte-identica. Nao houve Blender real.

P0 A101-P0-01: alteracoes de referencias por callback `emit` entre preflight e remocao ou por efeito de primeira chamada `remove` podem deixar referencial sobrevivente apontando para DROP, enquanto status final e REMOVOES_CONFIRMADAS. E prova no mock, nao Blender real. P1 A101-P1-02: Text lookup via `from bpy import data as d; d.objects[name]` e `getattr(bpy.data,"objects").get(name)` passa sem alerta; P1-03: alocacao por par nao conta O(g^2); P1-04: deadline nao checado durante ranking O(g^3). P2-05: user_map somente um sentido; P2-06: ledger sem campos R2 completos.

Nao consultar ou incorporar auditor B atual antes de preservar sua Fase 1 cega. Quando disponivel, consolide A/B, decida se candidatos de correcao novos serao requisitados. Nao transfira GO documental R2 para GO de codigo, Blender real ou producao. **NAO executar Blender/bpy real, nao tocar arquivos .blend, nao salvar, nao homologar, nao ampliar escopo sem autorizacao do proprietario**. Se autorizar trabalho futuro: exigir nova candidata em arquivo separado, testes e hash novo, reauditoria A/B e gate Blender 5.0 em copia descartavel somente com autorizacao posterior explicita.
