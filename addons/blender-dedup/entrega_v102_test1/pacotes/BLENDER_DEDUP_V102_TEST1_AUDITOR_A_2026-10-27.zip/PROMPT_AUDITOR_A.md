# Auditor A — reauditoria cega v1.0.2-test1

Audite independentemente esta candidata congelada. Você é auditor, não desenvolvedor nem homologador de produção.
SHA-256 da candidata: 02618942350dacfbb7d1b2b079e802ed3336802ddb719e059a85bfd2582a1ca8
Baseline v1.0.1: 1d4175b1190732ea6077232b32d4fd632021f99c9ccb80e5ba15dd5e4dcb9956.
Base Git do desenvolvimento: 828aeab4280f650d3d2786d75eee55634b728736.

Leia R1–R5, adendo R2, plano R1, diff e testes. Foque em: Geometria/topologia exata, bijeção global, multiplicidades, winding/SEM-01, quantização, classes ambíguas, oráculos independentes, Rook/Shrikhande, memória/deadlines e 1M vértices.

Reproduza 57/57, 266/266, 2649/2649, 32/32, oráculos 400/400 e 160/160; verifique o adapter do PIN do oráculo e as inversões de asserções B.
Revise MC01–MC07 integralmente e crie contraprovas próprias. Teste incerteza antes da primeira remoção = zero chamadas do executor;
erro depois = parar e conciliar sem rollback. Exercite mutação de geometria/refs em emit e remove, inclusive último remove,
falhas antes/depois do efeito e logger quebrado. Não aceite hash/refinamento como prova positiva geométrica.
Questione o domínio de exclusividade, getters/handlers, normalização user_map e legalidade das fixtures.
O callback final recebe PENDING_FINAL_VALIDATION; REMOVOES_CONFIRMADAS só pode vir no retorno após novo check.

Use somente Python offline com mocks/dados sintéticos. Não execute Blender real, importe bpy real, abra/crie/salve .blend,
use ChatGPT Work, instale a candidata, publique release, faça merge/PR ou altere código/inputs. NÃO leia MASTER,
parecer do outro auditor, resultados do desenvolvedor ou da rodada atual antes de entregar seu selo independente.
Este pacote deliberadamente não contém esses pareceres nem o prompt do outro auditor. Nenhum auditor atual foi acionado pelo executor.

Com dependências previamente disponíveis: python tests_v102_test1/replay.py
Os scripts históricos têm nomes/rótulos v1.0.1; o runner vincula o alvo novo somente nas cópias de work/ e em memória.
Não trate PASS de contraprovas históricas sobre v1.0.1 como correção. Não confunda mocks com API Blender 5.0.

Entregue ZIP autônomo com seu parecer, achados por severidade e IDs, matriz MC01–MC07 e G01–G14,
logs/comandos, testes próprios, hashes e declaração de independência. Informe precisamente testes não reproduzidos.
Veredito apenas sobre código offline: GO/HOLD/INCONCLUSIVO; nenhum GO de Blender real ou produção.
