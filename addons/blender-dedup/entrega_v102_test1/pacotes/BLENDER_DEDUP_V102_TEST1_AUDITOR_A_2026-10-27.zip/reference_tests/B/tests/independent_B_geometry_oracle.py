"""Independent reproducible graph oracle for candidate. Pure Python/NumPy/networkx; no bpy."""
import sys; sys.dont_write_bytecode = True
import sys,json,random,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'input'/'qa'))
from test_candidate_v101 import d,Mesh
import networkx as nx
r=random.Random(20261023)
seen=[];failures=[]
t0=time.monotonic()
for i in range(160):
 n=r.randint(4,8)
 all_edges=[(u,v) for u in range(n) for v in range(u+1,n)]
 m=r.randint(0,min(len(all_edges),n+4))
 edges_a=r.sample(all_edges,m)
 if i%2:
  perm=list(range(n));r.shuffle(perm)
  edges_b=[(perm[u],perm[v]) for u,v in edges_a]
 else:
  edges_b=r.sample(all_edges,m)
 a=Mesh([(0.,0.,0.)]*n,edges_a,[])
 b=Mesh([(0.,0.,0.)]*n,edges_b,[])
 # explicitly add isolated vertices
 ga=nx.Graph();ga.add_nodes_from(range(n));ga.add_edges_from(edges_a)
 gb=nx.Graph();gb.add_nodes_from(range(n));gb.add_edges_from(edges_b)
 expected=nx.is_isomorphic(ga,gb)
 try: actual=d.meshes_equal(a,b)
 except d.ComplexityBudgetExceeded:actual='INCONCLUSIVE'
 good= actual==expected
 seen.append({'case':i,'n':n,'m':m,'expected':expected,'actual':actual,'ok':good})
 if not good:failures.append(seen[-1])
print(json.dumps({'test':'independent_B_geometry_oracle','cases':len(seen),'pass':len(seen)-len(failures),'failures':failures,'elapsed_s':round(time.monotonic()-t0,3),'scope':'zero bpy, all vertices coincident, no faces'},ensure_ascii=False))
if failures: raise SystemExit(2)
