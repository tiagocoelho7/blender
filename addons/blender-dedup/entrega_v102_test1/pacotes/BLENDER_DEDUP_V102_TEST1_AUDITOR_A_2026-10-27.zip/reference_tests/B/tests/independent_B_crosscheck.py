"""Extra B QA on cross-check completeness and IDProperty string scanner. Only mocks."""
import sys; sys.dont_write_bytecode = True
import sys,json,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'input'/'qa'))
from test_candidate_v101 import d,basic,quick_execute,Material
class SecondaryB(unittest.TestCase):
 def test_user_map_empty_not_inconclusive(self):
  b,objs=basic(); b.user_map=lambda *,subset=None: {}
  actual=quick_execute(b)
  assert actual['status']=='REMOVOES_CONFIRMADAS'
  assert b.objects.remove_calls==2
  print('B08',json.dumps({'user_map':'{}','objects_remove_calls':b.objects.remove_calls,'status':actual['status']}))
 def test_dynamic_lookup_in_nested_idproperty_str_not_flagged(self):
  b,objs=basic();mat=Material('script_config')
  mat.idprops={'nested':{'script':"from bpy import data\nobj=data.objects.get('model.000')"}}
  b.materials.append(mat)
  actual=quick_execute(b)
  assert actual['status']=='REMOVOES_CONFIRMADAS'
  assert b.objects.remove_calls==2
  print('B09',json.dumps({'idproperty_dynamic_script':mat.idprops,'objects_remove_calls':b.objects.remove_calls,'status':actual['status']}))
if __name__=='__main__': unittest.main(verbosity=2)
