"""Independent Auditor B targeted tests. Only fake Blender data; NO bpy and NO .blend.
Uses the candidate executor's mock data classes as convenient fixtures, with independent
oracles on the effects and explicit recorded observed/expected divergence.
The frozen candidate and its original QA are imported without modification.
"""
import sys; sys.dont_write_bytecode = True
import json,unittest,traceback
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'input'
sys.path.insert(0,str(SRC/'qa'))
import test_candidate_v101 as f
D=f.d
assert D.bpy is None

class AuditorBRechecks(unittest.TestCase):
  @staticmethod
  def run_case(blend, on_emit=None):
    emitted=[]
    def emit(label,data):
      emitted.append(label)
      if on_emit is not None: on_emit(label,data)
    caught=None;ret=None
    try:ret=D.execute(blend, emit=emit)
    except BaseException as ex:caught=f'{type(ex).__name__}: {ex}'
    return {'ret':ret['status'] if ret else None, 'error':caught, 'calls':blend.objects.remove_calls, 'remaining':[o.name for o in blend.objects], 'emissions':emitted}

  def test_control_direct_name_block(self):
    b,objs=f.basic()
    b.texts.append(f.FakeText('control',"x = bpy.data.objects['model.000']"))
    r=self.run_case(b)
    self.assertEqual(r['calls'],0,r)
    self.assertIsNotNone(r['error'])
    print('B-CTRL-DIRECT',json.dumps(r,ensure_ascii=False))

  def test_control_nested_idproperty_block(self):
    b,objs=f.basic()
    item=f.Material('custom')
    item.idprops={'idref':{'links':[objs[0]]}}
    b.materials.append(item)
    r=self.run_case(b)
    self.assertEqual(r['calls'],0,r)
    print('B-CTRL-IDPROP',json.dumps(r,ensure_ascii=False))

  def test_unsafe_keep_in_edit_mode_not_blocked(self):
    b,objs=f.basic()
    keep=objs[1]
    keep.mode='EDIT'
    r=self.run_case(b)
    r['keep_mode']=keep.mode
    self.assertEqual(r['ret'],'REMOVOES_CONFIRMADAS',r)
    self.assertEqual(r['calls'],2,r)
    print('B01-EDIT-KEEP',json.dumps(r,ensure_ascii=False))

  def test_unsafe_keep_mesh_data_edit_after_planning(self):
    b,objs=f.basic()
    def alter(label,payload):
      if label=='[T7-DEDUP-LEDGER-PRE]':
        objs[0].data.vertices.rows[0]['co']=(500.,500.,500.)
    r=self.run_case(b,alter)
    r['drop_mesh_after_ledger'] = objs[0].data.vertices.rows[0]['co']
    self.assertEqual(r['ret'],'REMOVOES_CONFIRMADAS',r)
    self.assertEqual(r['calls'],2,r)
    print('B02-TOCTOU-GEOMETRY',json.dumps(r,ensure_ascii=False))

  def test_unsafe_reference_added_after_ledger(self):
    b,objs=f.basic()
    outsider=f.Obj('LivingOutside',None,modifier_count=1,kind='EMPTY')
    b.objects.append(outsider)
    def alter(label,payload):
      if label=='[T7-DEDUP-LEDGER-PRE]':
        outsider.modifiers[0].object = objs[0]
    r=self.run_case(b,alter)
    r['surviving_owner_target'] = outsider.modifiers[0].object.name
    self.assertEqual(r['ret'],'REMOVOES_CONFIRMADAS',r)
    self.assertEqual(r['calls'],2,r)
    self.assertNotIn(objs[0], b.objects)
    print('B03-TOCTOU-REF',json.dumps(r,ensure_ascii=False))

  def test_unsafe_reference_added_to_existing_root_before_snapshot(self):
    b,objs=f.basic()
    outsider=f.Obj('LivingOutside',None,modifier_count=1,kind='EMPTY')
    b.objects.append(outsider)
    def alter(label,payload):
      if label=='[T7-DEDUP-LEDGER-PRE]':
        outsider.parent=objs[0]
    r=self.run_case(b,alter)
    self.assertEqual(r['ret'],'REMOVOES_CONFIRMADAS',r)
    self.assertEqual(r['calls'],2,r)
    print('B04-TOCTOU-PARENT',json.dumps(r,ensure_ascii=False))

  def test_unsafe_two_stage_alias_name_lookup(self):
    b,objs=f.basic()
    s="module = bpy.data\nref = module.objects.get('model.000')\nprint(ref)\n"
    b.texts.append(f.FakeText('name_lookup_two_stage.py',s))
    self.assertFalse(D._text_lookup_risk(s, {'model.000'}))
    r=self.run_case(b)
    self.assertEqual(r['ret'],'REMOVOES_CONFIRMADAS',r)
    self.assertEqual(r['calls'],2,r)
    print('B05-DYNAMIC-ALIAS',json.dumps(r,ensure_ascii=False))

  def test_unsafe_from_bpy_import_data_lookup(self):
    b,objs=f.basic()
    s="from bpy import data\nref = data.objects.get('model.000')\nprint(ref)\n"
    b.texts.append(f.FakeText('from_import.py',s))
    self.assertFalse(D._text_lookup_risk(s, {'model.000'}))
    r=self.run_case(b)
    self.assertEqual(r['ret'],'REMOVOES_CONFIRMADAS',r)
    self.assertEqual(r['calls'],2,r)
    print('B06-FROM-IMPORT',json.dumps(r,ensure_ascii=False))

  def test_unsafe_getattr_objects_lookup(self):
    b,objs=f.basic()
    s="ref = getattr(bpy.data, 'objects').get('model.000')\nprint(ref)\n"
    b.texts.append(f.FakeText('getattr.py',s))
    self.assertFalse(D._text_lookup_risk(s, {'model.000'}))
    r=self.run_case(b)
    self.assertEqual(r['ret'],'REMOVOES_CONFIRMADAS',r)
    self.assertEqual(r['calls'],2,r)
    print('B07-GETATTR-LOOKUP',json.dumps(r,ensure_ascii=False))

  def test_control_keep_readonly_allowed(self):
    b,objs=f.basic()
    objs[1].library='linked.blend';objs[1].is_editable=False
    r=self.run_case(b)
    self.assertEqual(r['calls'],2,r)
    print('B-CTRL-KEEP-READONLY',json.dumps(r,ensure_ascii=False))

  def test_control_drop_edit_denied(self):
    b,objs=f.basic()
    objs[0].mode='EDIT'
    r=self.run_case(b)
    self.assertEqual(r['calls'],0,r)
    print('B-CTRL-DROP-EDIT',json.dumps(r,ensure_ascii=False))

if __name__=='__main__':
    unittest.main(verbosity=2)
