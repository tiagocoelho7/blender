"""Synthetic/isolated QA of *new candidate*; no real bpy, no .blend.
Run: python -m unittest discover -s qa -p 'test_candidate_v101.py' -v
"""
import contextlib
import importlib.util
import io
import json
import sys
import time
import unittest
from pathlib import Path
from types import SimpleNamespace as NS

import numpy as np

SRC=Path(__file__).resolve().parents[1]/'src'/'remover_duplicatas_blend_v1_0_1.py'
spec=importlib.util.spec_from_file_location('t7_dedup_candidate_v101', SRC)
d=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=d
spec.loader.exec_module(d)
assert d.bpy is None, 'NO real bpy permitted in QA'

class Prop:
    def __init__(self, identifier, kind):self.identifier,self.type=identifier,kind
class RNA:
    def __init__(self, identifier, **props):
        self.identifier=identifier
        self.properties=[Prop(k,v) for k,v in props.items()]

class Buffer:
    def __init__(self, rows):self.rows=rows
    def __len__(self):return len(self.rows)
    def foreach_get(self,key,out):
        vals=[]
        for r in self.rows:
            x=r[key]
            vals.extend(x if isinstance(x,(list,tuple)) else [x])
        out[:]=np.asarray(vals,dtype=out.dtype)

class MockID:
    _id_counter=1000
    def __init__(self,kind,name):
        MockID._id_counter+=1
        self.id_type=kind.upper()
        self.name=name
        self.bl_rna=RNA(kind)
        self.idprops={}
        self.session_uid=MockID._id_counter
        self.library=None
        self.is_library_indirect=False
        self.override_library=None
        self.is_editable=True
        self.is_evaluated=False
        self.users=1
    def as_pointer(self):return id(self)
    def items(self):return self.idprops.items()

class Mesh(MockID):
    def __init__(self,coords,edges,faces,name='MESH'):
        super().__init__('Mesh',name)
        self.vertices=Buffer([{'co':p} for p in coords])
        self.edges=Buffer([{'vertices':t} for t in edges])
        p=[];loops=[]
        for f in faces:
            p.append({'loop_start':len(loops),'loop_total':len(f)})
            loops.extend({'vertex_index':v} for v in f)
        self.polygons=Buffer(p)
        self.loops=Buffer(loops)
        self.shape_keys=None
        self.bl_rna=RNA('Mesh',vertices='COLLECTION',edges='COLLECTION',polygons='COLLECTION',loops='COLLECTION')

class Obj(MockID):
    def __init__(self, name, mesh=None, modifier_count=0, keys=0, parent=None, kind='MESH'):
        super().__init__('Object',name)
        self.type=kind
        self.data=mesh
        if mesh and keys:
            mesh.shape_keys=NS(key_blocks=list(range(keys)))
        self.modifiers=[NS(bl_rna=RNA('Modifier', object='POINTER'), object=None) for _ in range(modifier_count)]
        self.constraints=[]
        self.parent=parent
        self.instance_collection=None
        self.mode='OBJECT'
        self.bl_rna=RNA('Object',data='POINTER',modifiers='COLLECTION',constraints='COLLECTION',parent='POINTER',instance_collection='POINTER')

class Collection(MockID):
    def __init__(self,name, objects=(), children=()):
        super().__init__('Collection',name)
        self.objects=list(objects)
        self.children=list(children)
        self.bl_rna=RNA('Collection',objects='COLLECTION',children='COLLECTION')

class Scene(MockID):
    def __init__(self,name,collection,objects=()):
        super().__init__('Scene',name)
        self.collection=collection
        self.objects=list(objects)
        self.bl_rna=RNA('Scene',collection='POINTER',objects='COLLECTION')

class Material(MockID):
    def __init__(self,name,node_tree=None,animation_data=None):
        super().__init__('Material',name)
        self.node_tree=node_tree
        self.animation_data=animation_data
        self.bl_rna=RNA('Material',node_tree='POINTER',animation_data='POINTER')

class NodeTree(MockID):
    def __init__(self,name,nodes=()):
        super().__init__('NodeTree',name)
        self.nodes=list(nodes)
        self.bl_rna=RNA('NodeTree', nodes='COLLECTION')

class Node:
    def __init__(self, target=None, collection=None):
        self.target=target
        self.collection=collection
        self.bl_rna=RNA('Node',target='POINTER',collection='POINTER')

class FakeText(MockID):
    def __init__(self,name,content):
        super().__init__('Text',name)
        self._content=content
    def as_string(self):return self._content

class Driver:
    def __init__(self,target=None,expression=''):
        self.target=target;self.expression=expression
        self.bl_rna=RNA('Driver',target='POINTER',expression='STRING')

class Objects(list):
    def __init__(self,items=(), fail_at=None, after_effect=False):
        super().__init__(items)
        self.remove_calls=0
        self.fail_at=fail_at
        self.after_effect=after_effect
    def remove(self,obj,do_unlink=False):
        assert do_unlink is True
        self.remove_calls+=1
        if self.remove_calls==self.fail_at and not self.after_effect:
            raise RuntimeError('injected BEFORE effect')
        super().remove(obj)
        if self.remove_calls==self.fail_at and self.after_effect:
            raise RuntimeError('injected AFTER effect')

class Blend:
    def __init__(self, objects, collections=(), scenes=(), materials=(), node_groups=(), texts=(), other_ids=()):
        self.objects=Objects(objects)
        self.collections=list(collections)
        self.scenes=list(scenes)
        self.materials=list(materials)
        self.node_groups=list(node_groups)
        self.texts=list(texts)
        self.meshes=list({x.data for x in objects if x.data is not None})
        self.other_ids=list(other_ids)
        self.bl_rna=RNA('BlendData',objects='COLLECTION',collections='COLLECTION',scenes='COLLECTION',
                        materials='COLLECTION',node_groups='COLLECTION',texts='COLLECTION',
                        meshes='COLLECTION',other_ids='COLLECTION')
        self.extra_user_map={}
        self.fail_user_map=False
    def user_map(self,*,subset=None):
        if self.fail_user_map:raise RuntimeError('user_map inaccessible')
        result={x:set() for x in subset}
        for target in subset:
            if target in self.extra_user_map:
                result[target]=set(self.extra_user_map[target])
            else:
                for coll in self.collections:
                    if target in coll.objects:
                        result[target].add(coll)
                for scene in self.scenes:
                    if target in scene.objects:
                        result[target].add(scene)
                for obj in self.objects:
                    if obj is not target and obj.parent is target:
                        result[target].add(obj)
                    if any(m.object is target for m in obj.modifiers):
                        result[target].add(obj)
        return result


def triangle():
    return [(0,0,0),(1,0,0),(0,1,0)],[(0,1),(1,2),(2,0)],[(0,1,2)]

def basic(count=3,*, modifiers=(0,2,1),keys=(0,0,0),one_mesh=False):
    coords,edges,faces=triangle()
    shared=Mesh(coords,edges,faces)
    objects=[Obj('model.%03d'%i,shared if one_mesh else Mesh(coords,edges,faces),
                 modifier_count=modifiers[i],keys=keys[i]) for i in range(count)]
    collection=Collection('Main',objects)
    scene=Scene('S',collection,objects)
    return Blend(objects,[collection],[scene]),objects

def quick_execute(blend, **kwargs):
    out=[]
    return d.execute(blend,emit=lambda label,payload:out.append((label,payload)),**kwargs)

class Tests(unittest.TestCase):
    def test_basic_rank_and_automatic_remove(self):
        b,objs=basic()
        result=quick_execute(b)
        self.assertEqual(b.objects.remove_calls,2)
        self.assertEqual(list(b.objects),[objs[1]])
        self.assertEqual(result['status'],'REMOVOES_CONFIRMADAS')
        self.assertTrue(result['no_autosave'])
    def test_modifiers_beat_shape_keys(self):
        b,objs=basic(modifiers=(2,5,3),keys=(40,0,90))
        quick_execute(b)
        self.assertEqual(list(b.objects),[objs[1]])
    def test_shape_keys_tiebreak(self):
        b,objs=basic(modifiers=(2,2,2),keys=(1,4,2))
        quick_execute(b)
        self.assertEqual(list(b.objects),[objs[1]])
    def test_name_tiebreak(self):
        b,objs=basic(modifiers=(2,2,2))
        quick_execute(b)
        self.assertEqual(list(b.objects),[objs[0]])
    def test_shared_mesh_removes_object_only(self):
        b,objs=basic(one_mesh=True)
        quick_execute(b)
        self.assertEqual(len(b.meshes),1)
        self.assertEqual(list(b.objects),[objs[1]])
    def test_all_blend_multi_scene_and_hidden(self):
        b,objs=basic()
        b.collections.append(Collection('Other', [objs[2]]))
        b.scenes.append(Scene('OtherScene', b.collections[-1], [objs[2]]))
        quick_execute(b)
        self.assertEqual(len(b.objects),1)
    def test_nan_same_pointer_global_abort(self):
        b,objs=basic(one_mesh=True)
        b.meshes[0].vertices.rows[0]['co']=(np.nan,0,0)
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_inf_global_abort(self):
        b,objs=basic()
        objs[2].data.vertices.rows[0]['co']=(np.inf,0,0)
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_overflow_global_abort(self):
        b,objs=basic()
        objs[2].data.vertices.rows[0]['co']=(1e30,0,0)
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_different_mesh_not_duplicate(self):
        b,objs=basic()
        objs[2].data.vertices.rows[0]['co']=(0,0,.5)
        quick_execute(b)
        self.assertEqual(len(b.objects),2)
        self.assertIn(objs[2],b.objects)
    def test_missing_rna_global_abort(self):
        b,objs=basic()
        b.materials.append(MockID('Material','invalid-without-rna'))
        b.materials[-1].bl_rna=None
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_linked_drop_abort(self):
        b,objs=basic()
        objs[0].library='linked.blend'
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_linked_keep_can_remain(self):
        b,objs=basic()
        objs[1].library='linked.blend'
        objs[1].is_editable=False
        result=quick_execute(b)
        self.assertEqual(result['status'],'REMOVOES_CONFIRMADAS')
    def test_readonly_drop_abort(self):
        b,objs=basic()
        objs[0].is_editable=False
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_override_drop_abort(self):
        b,objs=basic()
        objs[0].override_library=object()
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
    def test_indirect_drop_abort(self):
        b,objs=basic()
        objs[0].is_library_indirect=True
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
    def test_edit_drop_abort(self):
        b,objs=basic()
        objs[0].mode='EDIT'
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
    def test_scene_mode_edit_abort(self):
        b,objs=basic()
        with self.assertRaises(d.PreflightAborted):quick_execute(b,context_mode='EDIT_MESH')
        self.assertEqual(b.objects.remove_calls,0)
    def test_child_parent_target_drop_abort(self):
        b,objs=basic()
        child=Obj('NonmeshChild',None,parent=objs[0],kind='EMPTY')
        b.objects.append(child)
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_modifier_target_drop_abort(self):
        b,objs=basic()
        survivor=Obj('child',None,kind='EMPTY',modifier_count=1)
        survivor.modifiers[0].object=objs[0]
        b.objects.append(survivor)
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
    def test_orphan_nodetree_to_drop_abort(self):
        b,objs=basic()
        orphan=NodeTree('Orphan',nodes=[Node(target=objs[0])])
        b.node_groups.append(orphan)
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_material_driver_to_drop_abort(self):
        b,objs=basic()
        driver=Driver(target=objs[0])
        b.materials.append(Material('mat',animation_data=NS(bl_rna=RNA('AnimData',drivers='COLLECTION'),drivers=[driver])))
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_idproperty_nested_direct_abort(self):
        b,objs=basic()
        material=Material('mat')
        material.idprops={'root':{'nested':[objs[0]]}}
        b.materials.append(material)
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_collection_instancing_transitive_abort(self):
        b,objs=basic()
        outer=Collection('Ancestor',children=[b.collections[0]])
        b.collections.append(outer)
        survivor=Obj('instancer',kind='EMPTY')
        survivor.instance_collection=outer
        b.objects.append(survivor)
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_collection_info_orphan_abort(self):
        b,objs=basic()
        b.node_groups.append(NodeTree('OrphanTrees',[Node(collection=b.collections[0])]))
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_user_map_mismatch_abort(self):
        b,objs=basic()
        bad=MockID('World','unseen')
        b.extra_user_map[objs[0]]={bad}
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_user_map_unavailable_abort(self):
        b,objs=basic()
        b.fail_user_map=True
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
    def test_text_dynamic_name_abort(self):
        b,objs=basic()
        b.texts.append(FakeText('script','target=bpy.data.objects[dynamic_name]'))
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_text_explicit_name_abort(self):
        b,objs=basic()
        b.texts.append(FakeText('script','target=bpy.data.objects["model.000"]'))
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_idprop_string_dynamic_abort(self):
        b,objs=basic()
        b.materials.append(Material('mat'))
        b.materials[-1].idprops={'code':'bpy.data.objects.get(variable)'}
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
    def test_budget_late_bucket_abort_zero_remove(self):
        b,objs=basic(count=3)
        opts=d.Limits(bucket_objects=2)
        with self.assertRaises(d.PreflightAborted):quick_execute(b,limits=opts)
        self.assertEqual(b.objects.remove_calls,0)
    def test_tiny_memory_budget_abort_zero_remove(self):
        b,objs=basic()
        opts=d.Limits(mem_pair_bytes=1)
        with self.assertRaises(d.PreflightAborted):quick_execute(b,limits=opts)
        self.assertEqual(b.objects.remove_calls,0)
    def test_logger_fails_before_remove_zero_calls(self):
        b,objs=basic()
        def broken(label,payload):raise OSError('blocked stdout')
        with self.assertRaises(d.PreflightAborted):d.execute(b,emit=broken)
        self.assertEqual(b.objects.remove_calls,0)
    def test_logger_fails_after_first_delete_stops(self):
        b,objs=basic()
        def broken(label,payload):
            if label=='[T7-DEDUP-AFTER-REMOVE]':raise OSError('blocked stdout')
        with self.assertRaisesRegex(RuntimeError,'FALHA_PARCIAL_POSSIVEL'):
            d.execute(b,emit=broken)
        self.assertEqual(b.objects.remove_calls,1)
    def test_remove_failure_before_effect_stops(self):
        b,objs=basic()
        b.objects.fail_at=1
        with self.assertRaisesRegex(RuntimeError,'FALHA_PARCIAL_POSSIVEL'):
            quick_execute(b)
        self.assertEqual(b.objects.remove_calls,1)
        self.assertEqual(len(b.objects),3)
    def test_remove_failure_after_effect_stops(self):
        b,objs=basic()
        b.objects.fail_at=1;b.objects.after_effect=True
        with self.assertRaisesRegex(RuntimeError,'FALHA_PARCIAL_POSSIVEL'):
            quick_execute(b)
        self.assertEqual(b.objects.remove_calls,1)
        self.assertEqual(len(b.objects),2)
    def test_remove_failure_on_last_call_stops(self):
        b,objs=basic()
        b.objects.fail_at=2;b.objects.after_effect=True
        with self.assertRaisesRegex(RuntimeError,'FALHA_PARCIAL_POSSIVEL'):
            quick_execute(b)
        self.assertEqual(b.objects.remove_calls,2)
    def test_missing_uid_reconcile_indeterminate(self):
        b,objs=basic()
        for item in objs:item.session_uid=None
        with self.assertRaisesRegex(RuntimeError,'FALHA_PARCIAL_POSSIVEL'):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,2)
    def test_nodetree_reference_to_non_target_no_false_abort(self):
        b,objs=basic()
        alternate=Obj('safe',None,kind='EMPTY')
        b.objects.append(alternate)
        b.node_groups.append(NodeTree('Tree',[Node(target=alternate)]))
        self.assertEqual(quick_execute(b)['status'],'REMOVOES_CONFIRMADAS')
    def test_exhaustive_plan_no_delete_for_late_bad_bucket(self):
        b,objs=basic()
        # Duplicate group valid but second group has invalid data that is singleton.
        bad=Obj('broken',Mesh([(float('nan'),0,0)],[],[]))
        b.objects.append(bad);b.meshes.append(bad.data)
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_object_non_mesh_never_removed(self):
        b,objs=basic()
        other=Obj('EMPTY',None,kind='EMPTY')
        b.objects.append(other)
        quick_execute(b)
        self.assertIn(other,b.objects)
    def test_no_duplicate_does_not_delete(self):
        b,objs=basic(count=1)
        result=quick_execute(b)
        self.assertEqual(result['status'],'SEM_DUPLICATAS')
        self.assertEqual(b.objects.remove_calls,0)
    def test_abort_on_exotic_idproperty(self):
        b,objs=basic()
        b.materials.append(Material('exotic'))
        b.materials[-1].idprops['exotic']=object()
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_sem_01(self):
        a=Mesh([(0,0,0)]*3,[(0,1),(1,2),(0,2)],[(0,1,2)])
        b=Mesh([(0,0,0)]*3,[(0,1),(1,2),(0,2)],[(0,2,1)])
        self.assertTrue(d.meshes_equal(a,b))
    def test_orientation_non_equal_with_unique_vertices(self):
        coords,edges,faces=triangle()
        a=Mesh(coords,edges,faces)
        b=Mesh(coords,edges,[(0,2,1)])
        self.assertFalse(d.meshes_equal(a,b))
    def test_n_gon_17_reindexed(self):
        n=17;coords=[(i,i%4,i%5) for i in range(n)]
        e=[(i,(i+1)%n) for i in range(n)];f=[tuple(range(n))]
        order=list(reversed(range(n)));idx={v:i for i,v in enumerate(order)}
        a=Mesh(coords,e,f)
        b=Mesh([coords[i] for i in order],[(idx[u],idx[v]) for u,v in e],
               [tuple(idx[i] for i in list(range(n))[4:]+list(range(n))[:4])])
        self.assertTrue(d.meshes_equal(a,b))

# Additional cases are appended as independent TestCase to keep original suite
# intact and make post-delete/linked-container risks individually addressable.
class AdditionalCases(unittest.TestCase):
    def test_linked_collection_membership_abort(self):
        b,objs=basic()
        b.collections[0].library='linked.blend'
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_readonly_scene_membership_abort(self):
        b,objs=basic()
        b.scenes[0].is_editable=False
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_missing_mesh_must_abort(self):
        b,objs=basic()
        b.objects.append(Obj('NoData',None,kind='MESH'))
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_keyboard_interrupt_after_side_effect(self):
        b,objs=basic()
        original=b.objects.remove
        def interrupted(obj,do_unlink=False):
            original(obj,do_unlink=do_unlink)
            raise KeyboardInterrupt('simulated interruption after unlink')
        b.objects.remove=interrupted
        with self.assertRaisesRegex(RuntimeError,'FALHA_PARCIAL_POSSIVEL'):
            quick_execute(b)
        self.assertEqual(b.objects.remove_calls,1)
        self.assertEqual(len(b.objects),2)
    def test_snapshot_error_after_preflight_before_delete(self):
        b,objs=basic()
        original=d._enumerate_current_snapshots
        def failure(data):raise RuntimeError('snapshot unavailable')
        try:
            d._enumerate_current_snapshots=failure
            with self.assertRaises(d.PreflightAborted):quick_execute(b)
        finally:
            d._enumerate_current_snapshots=original
        self.assertEqual(b.objects.remove_calls,0)
    def test_text_alias_indirect_lookup_abort(self):
        b,objs=basic()
        b.texts.append(FakeText('script','objs=bpy.data.objects\nselected=objs[dynamic_name]'))
        with self.assertRaises(d.PreflightAborted):quick_execute(b)
        self.assertEqual(b.objects.remove_calls,0)
    def test_idproperty_numeric_typecode_does_not_fake_reference(self):
        from array import array
        b,objs=basic()
        b.materials.append(Material('mat'))
        b.materials[-1].idprops['numbers']=array('f',[1.0,2.0])
        self.assertEqual(quick_execute(b)['status'],'REMOVOES_CONFIRMADAS')

class LateAdversarial(unittest.TestCase):
    def test_nonisomorphic_symmetric_last_bucket_fail_closed(self):
        import networkx as nx
        b,objs=basic(count=3)
        rook=nx.Graph();rook.add_nodes_from(range(16))
        for i in range(16):
            for j in range(i+1,16):
                if i//4==j//4 or i%4==j%4:rook.add_edge(i,j)
        shr=nx.Graph();shr.add_nodes_from(range(16))
        for i in range(16):
            x,y=divmod(i,4)
            for dx,dy in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1)]:
                shr.add_edge(i,((x+dx)%4)*4+(y+dy)%4)
        self.assertFalse(nx.is_isomorphic(rook,shr))
        coincident=[(0,0,0)]*16
        xa=Obj('Rook',Mesh(coincident,list(rook.edges()),[]))
        xb=Obj('Shrikhande',Mesh(coincident,list(shr.edges()),[]))
        b.objects.extend([xa,xb]);b.meshes.extend([xa.data,xb.data])
        b.collections[0].objects.extend([xa,xb]);b.scenes[0].objects.extend([xa,xb])
        lim=d.Limits(states_per_pair=750, pair_seconds=.2, total_seconds=5)
        with self.assertRaises(d.PreflightAborted):quick_execute(b,limits=lim)
        self.assertEqual(b.objects.remove_calls,0)
    def test_memory_error_during_late_signature_no_delete(self):
        b,objs=basic()
        extra=Obj('singleton',Mesh([(11,0,0)],[],[]))
        b.objects.append(extra);b.meshes.append(extra.data)
        original=d.quantized_vertices
        def faulty(mesh):
            if mesh is extra.data:raise MemoryError('synthetic OOM')
            return original(mesh)
        try:
            d.quantized_vertices=faulty
            with self.assertRaises(d.PreflightAborted):quick_execute(b)
        finally:
            d.quantized_vertices=original
        self.assertEqual(b.objects.remove_calls,0)

class QuantizationBoundaries(unittest.TestCase):
    def test_five_decimal_boundary_after_float32(self):
        vals=(0.0000049,0.0000051,-0.0000049,-0.0000051)
        mesh=Mesh([(v,0,0) for v in vals],[],[])
        q=d.quantized_vertices(mesh)
        expected=[int(np.rint(float(np.float32(v))*100000)) for v in vals]
        self.assertEqual(list(q[:,0]),expected)
        self.assertEqual(expected,[0,1,0,-1])
    def test_quantization_exact_float32_promoted(self):
        v=np.float32(0.123455)
        mesh=Mesh([(float(v),0,0)],[],[])
        self.assertEqual(d.quantized_vertices(mesh)[0,0],int(np.rint(float(v)*100000)))

if __name__=='__main__': unittest.main()
