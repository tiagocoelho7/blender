#!/usr/bin/env python3
"""Documentary contract oracle for Blender Dedup R2, no bpy, no .blend, no edits.

This is a synthetic policy oracle and mathematical model, NOT a test of the
nonexistent v1.0.1 implementation or of actual Blender RNA semantics.
"""
from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import permutations, product
from pathlib import Path
import hashlib
import json
import math
import os
import sys
import unittest

ROOT = Path(__file__).resolve().parent.parent
ADENDO = ROOT / 'ORIGINAIS/EXTRAIDOS/02_ADENDO_MASTER_R2_PLANO_V101.md'
SPEC = ROOT / 'ORIGINAIS/EXTRAIDOS/ESPECIFICACAO_CONGELADA.md'
ORIGIN = ROOT / 'ORIGINAIS/EXTRAIDOS/SHA256SUMS.txt'


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@dataclass(frozen=True)
class Scenario:
    case: str
    title: str
    expected: str
    edges: tuple = ()  # (owner, target, relation)
    roles: tuple = ()  # (node, role): keep/drop/survive/component/collection
    unsafe: tuple = ()


def decision(case):
    """Minimal finite-graph interpretation of R2 reference safety contracts.

    'member' alone is nonfunctional. 'consume' turns membership into a relevant
    dependency, recursively. 'uses_data' composes consumers through node groups.
    Direct ID pointers from any surviving owner to a drop abort the whole plan.
    An incomprehensible owner or incomplete scan aborts, never returns safe.
    """
    roles = dict(case.roles)
    drops = {n for n, kind in roles.items() if kind == 'drop'}
    if not drops:
        return 'NO_DROP'
    if case.unsafe:
        return 'GLOBAL_ABORT'
    survivor_roots = {n for n, kind in roles.items() if kind in ('keep', 'survive')}
    for owner, target, relation in case.edges:
        if relation in ('direct', 'unknown') and target in drops:
            if relation == 'unknown' or owner in survivor_roots:
                return 'GLOBAL_ABORT'
    # Traverse only functional consumption edges from live roots.
    outgoing = defaultdict(list)
    for source, target, relation in case.edges:
        outgoing[source].append((target, relation))
    visited = set()
    queue = []
    for root in survivor_roots:
        for target, relation in outgoing[root]:
            if relation in ('consume', 'uses_data'):
                queue.append((target, True))
    while queue:
        node, active = queue.pop()
        if (node, active) in visited:
            continue
        visited.add((node, active))
        if node in drops:
            return 'GLOBAL_ABORT'
        for target, relation in outgoing[node]:
            if relation in ('consume', 'uses_data', 'member'):
                queue.append((target, True))
            if relation in ('unknown', 'direct') and target in drops:
                return 'GLOBAL_ABORT'
    return 'AUTO_REMOVE'


SCENARIOS = [
    Scenario('F01','simple pair', 'AUTO_REMOVE',roles=(('K','keep'),('D','drop'))),
    Scenario('F02','single ordinary collection membership', 'AUTO_REMOVE',
        edges=(('C','D','member'),),roles=(('K','keep'),('D','drop'),('C','collection'))),
    Scenario('F03','two ordinary collections and scene member', 'AUTO_REMOVE',
        edges=(('Scene','C1','member'),('C1','D','member'),('C2','D','member')),
        roles=(('K','keep'),('D','drop'),('Scene','survive'),('C1','collection'),('C2','collection'))),
    Scenario('F04','survivor child points to drop parent','GLOBAL_ABORT',
        edges=(('Child','D','direct'),),roles=(('K','keep'),('D','drop'),('Child','survive'))),
    Scenario('F05','survivor constraint pointer','GLOBAL_ABORT',
        edges=(('Empty','D','direct'),),roles=(('K','keep'),('D','drop'),('Empty','survive'))),
    Scenario('F06','surviving material driver pointer','GLOBAL_ABORT',
        edges=(('Material','D','direct'),),roles=(('K','keep'),('D','drop'),('Material','survive'))),
    Scenario('F07','surviving node group custom ID pointer','GLOBAL_ABORT',
        edges=(('NodeTree','D','direct'),),roles=(('K','keep'),('D','drop'),('NodeTree','survive'))),
    Scenario('F08','survivor modifier pointer','GLOBAL_ABORT',
        edges=(('K','D','direct'),),roles=(('K','keep'),('D','drop'))),
    Scenario('F09','empty survivor instances collection','GLOBAL_ABORT',
        edges=(('Empty','C','consume'),('C','D','member')),
        roles=(('K','keep'),('D','drop'),('Empty','survive'),('C','collection'))),
    Scenario('F10','node group used by survivor consumes collection','GLOBAL_ABORT',
        edges=(('K','N','uses_data'),('N','C','consume'),('C','D','member')),
        roles=(('K','keep'),('D','drop'),('N','component'),('C','collection'))),
    Scenario('F11','nested collections consumed by survivor','GLOBAL_ABORT',
        edges=(('Empty','C1','consume'),('C1','C2','member'),('C2','D','member')),
        roles=(('K','keep'),('D','drop'),('Empty','survive'),('C1','collection'),('C2','collection'))),
    Scenario('F12','only removed object consumes collection','AUTO_REMOVE',
        edges=(('D2','C','consume'),('C','D','member')),
        roles=(('K','keep'),('D','drop'),('D2','drop'),('C','collection'))),
    Scenario('F13','orphan node group persisted as live ID','GLOBAL_ABORT',
        edges=(('OrphanNodeTree','C','consume'),('C','D','member')),
        roles=(('K','keep'),('D','drop'),('OrphanNodeTree','survive'),('C','collection'))),
    Scenario('F14','removed drop targets keep only','AUTO_REMOVE',
        edges=(('D','K','direct'),),roles=(('K','keep'),('D','drop'))),
    Scenario('F15','unclassified incoming owner','GLOBAL_ABORT',
        edges=(('Mystery','D','unknown'),),roles=(('K','keep'),('D','drop'),('Mystery','survive'))),
    Scenario('F16','enumerator reports incomplete','GLOBAL_ABORT',
        roles=(('K','keep'),('D','drop')),unsafe=('DISCOVERY_INCOMPLETE',)),
    Scenario('F17','dynamic Text may access drop','GLOBAL_ABORT',
        roles=(('K','keep'),('D','drop')),unsafe=('TEXT_POTENTIALLY_DYNAMIC',)),
    Scenario('F18','linked drop is ineligible','GLOBAL_ABORT',
        roles=(('K','keep'),('D','drop')),unsafe=('DROP_LINKED',)),
    Scenario('F19','readonly drop is ineligible','GLOBAL_ABORT',
        roles=(('K','keep'),('D','drop')),unsafe=('DROP_READONLY',)),
    Scenario('F20','override drop is ineligible','GLOBAL_ABORT',
        roles=(('K','keep'),('D','drop')),unsafe=('DROP_OVERRIDE',)),
    Scenario('F21','indirect linked drop is ineligible','GLOBAL_ABORT',
        roles=(('K','keep'),('D','drop')),unsafe=('DROP_INDIRECT',)),
    Scenario('F22','readonly linked keep with local drop','AUTO_REMOVE',
        roles=(('K','keep'),('D','drop'))),
    Scenario('F23','shared mesh does not justify manual mesh deletion','AUTO_REMOVE',
        roles=(('K','keep'),('D','drop'))),
    Scenario('F24','EDIT mode abort','GLOBAL_ABORT',
        roles=(('K','keep'),('D','drop')),unsafe=('EDIT_MODE',)),
    Scenario('F25','one unsafe drop aborts all groups','GLOBAL_ABORT',
        edges=(('K2','D2','direct'),),roles=(('K','keep'),('D','drop'),('K2','keep'),('D2','drop'))),
    Scenario('F26','last-bucket budget exception aborts before mutation','GLOBAL_ABORT',
        roles=(('K','keep'),('D','drop')),unsafe=('BUDGET_EXCEEDED',)),
    Scenario('F27','removed object references other removed object','AUTO_REMOVE',
        edges=(('D2','D','direct'),),roles=(('K','keep'),('D','drop'),('D2','drop'))),
    Scenario('F28','node group shared with survivor despite removed owner','GLOBAL_ABORT',
        edges=(('D2','N','uses_data'),('K','N','uses_data'),('N','C','consume'),('C','D','member')),
        roles=(('K','keep'),('D','drop'),('D2','drop'),('N','component'),('C','collection'))),
    Scenario('F29','missing RNA path despite user_map owner','GLOBAL_ABORT',
        edges=(('Mystery','D','unknown'),),roles=(('K','keep'),('D','drop'),('Mystery','survive'))),
    Scenario('F30','nonmesh Empty directly targets drop','GLOBAL_ABORT',
        edges=(('Empty','D','direct'),),roles=(('K','keep'),('D','drop'),('Empty','survive'))),
    Scenario('F31','unconsumed nested collection ordinary membership','AUTO_REMOVE',
        edges=(('Scene','C1','member'),('C1','C2','member'),('C2','D','member')),
        roles=(('Scene','survive'),('K','keep'),('D','drop'),('C1','collection'),('C2','collection'))),
    Scenario('F32','direct ID pointer in owned node group used by survivor','GLOBAL_ABORT',
        edges=(('K','N','uses_data'),('N','D','direct')),
        roles=(('K','keep'),('D','drop'),('N','component'))),
]


@dataclass
class Mesh:
    coords: tuple
    edges: tuple
    faces: tuple


def cyclic(face):
    return min((tuple(face[i:] + face[:i]) for i in range(len(face))),default=())


def canon_edges(mesh, mapping):
    return Counter(tuple(sorted((mapping[a],mapping[b]))) for a,b in mesh.edges)


def canon_faces(mesh, mapping):
    return Counter(cyclic([mapping[x] for x in face]) for face in mesh.faces)


def iso_oracle(a,b):
    """Small brute-force oracle. Coordinates are ALREADY quantized labels."""
    if len(a.coords) != len(b.coords) or len(a.edges)!=len(b.edges) or len(a.faces)!=len(b.faces):
        return False
    if Counter(a.coords)!=Counter(b.coords):
        return False
    groups_a=defaultdict(list); groups_b=defaultdict(list)
    for i,c in enumerate(a.coords): groups_a[c].append(i)
    for i,c in enumerate(b.coords): groups_b[c].append(i)
    order=list(groups_a)
    ranges=[]
    for c in order:
        if len(groups_a[c])!=len(groups_b[c]):return False
        ranges.append(list(permutations(groups_b[c])))
    for choice in product(*ranges):
        mapping={a_i:b_i for c,group_b in zip(order,choice) for a_i,b_i in zip(groups_a[c],group_b)}
        if canon_edges(a,mapping)!=canon_edges(b,{i:i for i in range(len(b.coords))}):continue
        if canon_faces(a,mapping)==canon_faces(b,{i:i for i in range(len(b.coords))}):return True
    return False


def rename_mesh(mesh, p):
    inv={old:new for new,old in enumerate(p)}
    return Mesh(tuple(mesh.coords[x] for x in p),
                tuple(tuple(inv[v] for v in e) for e in reversed(mesh.edges)),
                tuple(tuple(inv[v] for v in f) for f in reversed(mesh.faces)))


class DocumentaryContractTests(unittest.TestCase):
    def test_all_32_synthetic_reference_contracts(self):
        self.assertEqual(len(SCENARIOS),32)
        for c in SCENARIOS:
            with self.subTest(case=c.case,title=c.title):
                self.assertEqual(decision(c),c.expected)

    def test_naive_direct_only_misses_indirect_instancing(self):
        c=SCENARIOS[8]
        has_direct=any(rel=='direct' and tgt=='D' for src,tgt,rel in c.edges)
        self.assertFalse(has_direct)
        self.assertEqual(decision(c),'GLOBAL_ABORT')

    def test_membership_alone_must_not_block(self):
        self.assertEqual(decision(SCENARIOS[1]),'AUTO_REMOVE')
        self.assertEqual(decision(SCENARIOS[2]),'AUTO_REMOVE')

    def test_document_normative_section_presence(self):
        doc=ADENDO.read_text(encoding='utf-8')
        for x in ('AD-R2-01','AD-R2-02','AD-R2-03','AD-R2-04','AD-R2-05','AD-R2-06','AD-R2-07',
                  'DESCONHECIDA','FUNCIONAL_INDIRETA','user_map()', 'MAX_PLAN_SECONDS',
                  'INDETERMINADO', 'SEM-01','Blender 5.0','Collection Info'):
            with self.subTest(section=x):self.assertIn(x,doc)

    def test_exact_isomorphism_orient_cycle(self):
        a=Mesh(((1,1,1),(2,2,2),(3,3,3)),((0,1),(1,2),(2,0)),((0,1,2),))
        b=Mesh(a.coords,a.edges,((1,2,0),))
        self.assertTrue(iso_oracle(a,b))

    def test_winding_reversed_distinct_coords_not_equivalent(self):
        a=Mesh(((1,),(2,),(3,)),((0,1),(1,2),(2,0)),((0,1,2),))
        b=Mesh(a.coords,a.edges,((0,2,1),))
        self.assertFalse(iso_oracle(a,b))

    def test_sem01_coincident_triangle_permutation_equivalent(self):
        a=Mesh(((0,),(0,),(0,)),((0,1),(1,2),(2,0)),((0,1,2),))
        b=Mesh(a.coords,a.edges,((0,2,1),))
        self.assertTrue(iso_oracle(a,b))

    def test_edge_multiplicity_must_match(self):
        a=Mesh(((0,),(0,),(0,)),((0,1),(1,2),(2,0),(2,0)),((0,1,2),))
        b=Mesh(a.coords,((0,1),(1,2),(2,0),(0,1)),a.faces)
        # Same unlabeled edge multiset under SOME permutation, so use unequal total instead.
        b=Mesh(a.coords,((0,1),(1,2),(2,0)),a.faces)
        self.assertFalse(iso_oracle(a,b))

    def test_same_counts_same_degrees_but_6_cycle_vs_two_triangles(self):
        a=Mesh(((0,),)*6,tuple((i,(i+1)%6) for i in range(6)),())
        b=Mesh(a.coords,((0,1),(1,2),(2,0),(3,4),(4,5),(5,3)),())
        self.assertFalse(iso_oracle(a,b))

    def test_reindexed_17gon_equivalent(self):
        n=17
        a=Mesh(tuple((i,i*i) for i in range(n)),tuple((i,(i+1)%n) for i in range(n)),(tuple(range(n)),))
        p=tuple((i*5)%n for i in range(n))
        self.assertTrue(iso_oracle(a,rename_mesh(a,p)))

    def test_nonlinear_face_hypergraph_not_edges_only(self):
        a=Mesh(((0,),)*4,(),((0,1,2),(0,2,3)))
        b=Mesh(a.coords,(),((0,1,2),(0,1,2)))
        self.assertFalse(iso_oracle(a,b))

    def test_float_boundary_and_nonfinite_are_not_native_precision(self):
        import numpy as np
        q=lambda v:int(np.rint(np.float64(np.float32(v))*100000.0))
        self.assertEqual(q(0.0),0)
        self.assertNotEqual(q(0.0),q(0.0001))
        for v in (float('nan'),float('inf'),float('-inf')):
            self.assertFalse(bool(np.isfinite(np.float32(v))))

    def test_rank_absolute_modifiers_then_shapes(self):
        arr=[('A_mods1_shape10',1,10),('B_mods2_shape0',2,0),('C_mods1_shape11',1,11)]
        ordered=sorted(arr,key=lambda ob:(-ob[1],-ob[2],ob[0].casefold(),ob[0]))
        self.assertEqual(ordered[0][0],'B_mods2_shape0')

    def test_entry_sha_manifest_matches_bytes(self):
        manifest={}
        for line in ORIGIN.read_text().splitlines():
            h,name=line.split('  ',1)
            manifest[name]=h
        self.assertEqual(len(manifest),9)
        for name,expected in manifest.items():
            with self.subTest(file=name):self.assertEqual(sha256(ORIGIN.parent/name),expected)


if __name__=='__main__':
    import contextlib,io,platform
    stream=io.StringIO()
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(DocumentaryContractTests)
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    cases=[{'id':c.case,'desc':c.title,'expected':c.expected,'observed':decision(c),
            'graph_edges':[list(e) for e in c.edges], 'note':'INDEPENDENT SYNTHETIC POLICY ORACLE, NOT v1.0.1 TEST'} for c in SCENARIOS]
    summary={'scope':'DOCUMENT_CONTRACT_ONLY','test_methods':result.testsRun,
             'test_methods_passed':result.testsRun-len(result.failures)-len(result.errors),
             'synthetic_contract_scenarios':len(cases),
             'synthetic_contracts_concordant':sum(x['observed']==x['expected'] for x in cases),
             'failed':len(result.failures),'errors':len(result.errors),
             'platform':platform.platform(),'python':sys.version.split()[0],
             'blender_5_0_executed':False,'bpy_imported':False,'blend_files_accessed':False,
             'candidate_v1_0_1_tested':False,
             'limitations':'Synthetic model validates policy self-consistency and semantic witness; no new implementation exists.'}
    ev=ROOT/'EVIDENCIAS';ev.mkdir(exist_ok=True)
    (ev/'qa_contratos_R2.log').write_text(stream.getvalue(),encoding='utf-8')
    (ev/'qa_contratos_R2.json').write_text(json.dumps(summary,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
    (ev/'testes_grafo_R2.json').write_text(json.dumps(cases,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2,ensure_ascii=True))
    sys.exit(int(not result.wasSuccessful()))
