#!/usr/bin/env python3
"""Auditor A: oracle by exhaustive coordinate-preserving bijections, independent of candidate pruning.
No real bpy, file writes or removal of scene objects. Python + NumPy in isolated process.
Usage: python audit_geometry.py /path/to/candidate.py
"""
import collections
import importlib.util
import itertools
import json
import random
import sys
import traceback
import time
import numpy as np
from pathlib import Path

modfile = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location('candidate_geometry_under_audit', modfile)
candidate = importlib.util.module_from_spec(spec)
sys.modules[spec.name]=candidate
spec.loader.exec_module(candidate)

class Sequence:
    def __init__(self, rows):
        self.rows = rows
    def __len__(self):
        return len(self.rows)
    def foreach_get(self, key, target):
        v = []
        for row in self.rows:
            value = row[key]
            if isinstance(value, (tuple, list)):
                v.extend(value)
            else:
                v.append(value)
        target[:] = np.array(v, dtype=target.dtype)

class MockMesh:
    def __init__(self, coords, edges, faces, label=''):
        self.label = label
        self.coords = [[float(np.float32(x)) for x in row] for row in coords]
        self.edgepairs = [tuple(int(x) for x in edge) for edge in edges]
        self.faceloops = [tuple(int(x) for x in face) for face in faces]
        self.vertices = Sequence([{'co':c} for c in self.coords])
        self.edges = Sequence([{'vertices':e} for e in self.edgepairs])
        looptable, polygons = [], []
        for f in self.faceloops:
            polygons.append({'loop_start':len(looptable), 'loop_total':len(f)})
            looptable.extend({'vertex_index':v} for v in f)
        self.polygons, self.loops = Sequence(polygons), Sequence(looptable)
        self.shape_keys = None
    def as_pointer(self):
        return id(self)
    def dump(self):
        return {'coords':self.coords,'edges':self.edgepairs,'faces':self.faceloops}


def oracle_quant(v):
    # Declare the quantization for oracle; input is already made float32 by the fake bpy API.
    return tuple(int(round(float(x) * 100_000)) for x in v)

def canonical_winding(face):
    if not face:
        return ()
    return min(tuple(face[i:]+face[:i]) for i in range(len(face)))

def oracle_equivalent(a, b):
    """Brute force independent: enumerate permutations within equal coordinates, compare multisets.
    No candidate topology helpers, labels or isomorphism pruning are called.
    """
    if (len(a.coords),len(a.edgepairs),len(a.faceloops),sum(map(len,a.faceloops))) != (len(b.coords),len(b.edgepairs),len(b.faceloops),sum(map(len,b.faceloops))):
        return False
    n = len(a.coords)
    coords_a = [oracle_quant(v) for v in a.coords]
    coords_b = [oracle_quant(v) for v in b.coords]
    if sorted(coords_a) != sorted(coords_b):
        return False
    groups = collections.defaultdict(list)
    for i, c in enumerate(coords_a):
        groups[c].append(i)
    group_pairs = []
    for c, ai in groups.items():
        bi = [j for j, bc in enumerate(coords_b) if bc == c]
        group_pairs.append((ai, list(itertools.permutations(bi))))
    b_edges = collections.Counter(tuple(sorted(e)) for e in b.edgepairs)
    b_faces = collections.Counter(canonical_winding(list(f)) for f in b.faceloops)
    for options in itertools.product(*(p for _, p in group_pairs)):
        assignment = [0]*n
        for (as_, _), bs in zip(group_pairs, options):
            for ai, bi in zip(as_, bs):
                assignment[ai] = bi
        a_edges = collections.Counter(tuple(sorted((assignment[u], assignment[v]))) for u,v in a.edgepairs)
        if a_edges != b_edges:
            continue
        a_faces = collections.Counter(canonical_winding([assignment[v] for v in f]) for f in a.faceloops)
        if a_faces == b_faces:
            return True
    return False


def permute(m,rng,force_noop=False):
    n = len(m.coords)
    indexes = list(range(n))
    rng.shuffle(indexes)  # new index -> old index
    if force_noop:
        indexes = list(range(n))
    old_to_new = {old:new for new,old in enumerate(indexes)}
    new_edges = [[old_to_new[v] for v in edge] for edge in m.edgepairs]
    for e in new_edges:
        if rng.random() < .5:
            e.reverse()
    rng.shuffle(new_edges)
    new_faces = []
    for face in m.faceloops:
        f = [old_to_new[v] for v in face]
        if f:
            shift = rng.randrange(len(f))
            f = f[shift:]+f[:shift]
        new_faces.append(f)
    rng.shuffle(new_faces)
    return MockMesh([m.coords[i] for i in indexes], new_edges,new_faces,'permuted')


def make_random(rng, n, valid_only=False):
    poolsize = rng.randint(1, max(1,n)) if not valid_only else rng.randint(max(1,n//2), max(1,n))
    pool = [[float(i),float(i%3), float((i*7)%4)] for i in range(poolsize)]
    coords = [rng.choice(pool) for _ in range(n)]
    if n < 2: edges=[]
    else:
        count = rng.randrange(min(n*2,12)+1)
        edges = []
        possible = [(a,b) for a in range(n) for b in range(a+1,n)]
        for _ in range(count):
            if not valid_only and rng.random()<.08:
                edges.append((rng.randrange(n),)*2)
            elif possible:
                pair = rng.choice(possible)
                if valid_only and pair in edges:
                    continue
                edges.append(pair)
    faces=[]
    if n >= 3:
        for _ in range(rng.randrange(0,4)):
            size = rng.randrange(3, min(6,n+1)) if n>=4 else 3
            face = (rng.sample(range(n),size) if valid_only else [rng.randrange(n) for _ in range(size)])
            faces.append(face)
    return MockMesh(coords,edges,faces,'random')


def tweak(m,rng):
    coords = [list(v) for v in m.coords]
    edges = list(m.edgepairs)
    faces = [list(f) for f in m.faceloops]
    choice = rng.choice(['coord','edge','edge','face','face'])
    n = len(coords)
    if choice=='coord' and n:
        coords[rng.randrange(n)][rng.randrange(3)] += .004
    elif choice=='edge' and edges and n:
        ix=rng.randrange(len(edges)); e=list(edges[ix]); e[rng.randrange(2)] = rng.randrange(n); edges[ix]=e
    elif choice=='face' and faces and n:
        ix = rng.randrange(len(faces)); f=faces[ix]; f[rng.randrange(len(f))] = rng.randrange(n)
    elif n:
        coords[rng.randrange(n)][0] += 1.0
    return MockMesh(coords,edges,faces,'mutated')


def check(label,a,b,expected=None):
    global checks,failures
    checks += 1
    o = oracle_equivalent(a,b)
    if expected is not None and o != expected:
        failures.append({'name':label,'reason':'bad fixture','oracle':o,'expected':expected,'a':a.dump(),'b':b.dump()})
    try:
        got=bool(candidate.meshes_equal(a,b))
    except Exception as exc:
        failures.append({'name':label,'reason':'exception','exception':repr(exc),'traceback':traceback.format_exc(),'oracle':o,'a':a.dump(),'b':b.dump()})
        return
    if o != got:
        failures.append({'name':label,'reason':'candidate vs independent oracle','candidate':got,'oracle':o,'a':a.dump(),'b':b.dump()})

checks=0
failures=[]
started=time.perf_counter()
rng=random.Random(20261021)

# Short-cycle canonicalizer is tested separately against a simple enumeration.
cycles=0
for length in range(0,51):
    for _ in range(30):
        seq=[rng.randrange(4) for _ in range(length)]
        expected=canonical_winding(seq)
        actual=candidate._canonical_cycle(seq)
        if actual!=expected:
            failures.append({'name':'booth','input':seq,'actual':actual,'expected':expected})
        cycles += 1

# Vectorized canonizer is independently compared with brute rotations.
rows=0
for length in range(1,13):
    data=np.array([[rng.randrange(5) for _ in range(length)] for _ in range(100)],dtype=np.int64)
    actual=candidate._canon_rows(data)
    expected=np.array([canonical_winding(list(row)) for row in data], dtype=np.int64)
    if not np.array_equal(actual,expected):
        failures.append({'name':'_canon_rows','length':length})
    rows += len(data)

# Baseline with explicit ground truth independent of candidate.
triangle_a=MockMesh([[0,0,0],[1,0,0],[0,1,0]],[(0,1),(1,2),(2,0)],[(0,1,2)])
triangle_b=MockMesh([[0,0,0],[1,0,0],[0,1,0]],[(0,1),(1,2),(2,0)],[(0,2,1)])
check('reversed winding of unique-coord triangle',triangle_a,triangle_b,False)
check('cyclic face rotation',triangle_a,MockMesh(triangle_a.coords, triangle_a.edgepairs, [(1,2,0)]),True)
check('mutated connectivity',MockMesh([[0,0,0],[0,0,0],[1,0,0]],[(0,2)],[]),MockMesh([[0,0,0],[0,0,0],[1,0,0]],[(0,1)],[]),False)
check('all-equal vertices, edge vs no edge',MockMesh([[0,0,0]]*4,[(0,1)],[]),MockMesh([[0,0,0]]*4,[(1,1)],[]),False)
check('edge multiplicity',MockMesh([[0,0,0]]*3,[(0,1),(0,1)],[]),MockMesh([[0,0,0]]*3,[(0,1),(0,2)],[]))
check('isolated vertices identical',MockMesh([[0,0,0]]*5,[],[]),MockMesh([[0,0,0]]*5,[],[]),True)
check('blank meshes',MockMesh([],[],[]),MockMesh([],[],[]),True)
check('large face / cyclic',MockMesh([[i,0,0] for i in range(13)],[],[list(range(13))]),MockMesh([[i,0,0] for i in range(13)],[],[list(range(5,13))+list(range(5))]),True)
check('large face / reversed',MockMesh([[i,0,0] for i in range(13)],[],[list(range(13))]),MockMesh([[i,0,0] for i in range(13)],[],[list(reversed(range(13)))]),False)

for n in range(0,9):
    iterations = 55 if n>=7 else 110
    for i in range(iterations):
        a=make_random(rng,n,valid_only=bool(i%2))
        b=permute(a,rng)
        check('permuted n%d #%d'%(n,i),a,b,True)
        c=tweak(b,rng)
        check('mutated n%d #%d'%(n,i),a,c)
        # Same coordinate counts, arbitrary connectivity.
        d=make_random(rng,n)
        d=MockMesh(a.coords,d.edgepairs,d.faceloops)
        check('unrelated topology n%d #%d'%(n,i),a,d)


print('A_GEOMETRY_CANDIDATE_V101', 'checks=', checks, 'cycles=', cycles, 'rows=', rows, 'failures=', len(failures), 'elapsed_sec=', round(time.perf_counter()-started,4))
if failures:
 print(json.dumps(failures[:10],ensure_ascii=False,default=str))
 sys.exit(1)
