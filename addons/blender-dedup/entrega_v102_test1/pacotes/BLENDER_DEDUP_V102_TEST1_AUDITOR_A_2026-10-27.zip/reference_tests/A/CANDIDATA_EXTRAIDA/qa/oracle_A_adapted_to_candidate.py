#!/usr/bin/env python3
"""Independent mathematical oracle against FROZEN v1.0 only, never v1.0.1/bpy.
Run from bundle root: python EVIDENCIAS/teste_oraculo_independente_r2_a.py ORIGINAIS/BASELINE/remover_duplicatas_blend_v1.py EVIDENCIAS/oraculo_resultados.json
"""
import collections as C
import hashlib
import importlib.util
import itertools
import json
import random
import sys
import time
from pathlib import Path
import numpy as np
PIN='1d4175b1190732ea6077232b32d4fd632021f99c9ccb80e5ba15dd5e4dcb9956'
rng=random.Random(21012026)
class Buffer:
 def __init__(self, rows):self.rows=rows
 def __len__(self):return len(self.rows)
 def foreach_get(self,key,out):
  flat=[]
  for row in self.rows:
   x=row[key]
   flat.extend(x if isinstance(x,(tuple,list)) else [x])
  out[:]=np.asarray(flat,dtype=out.dtype)
class Mesh:
 def __init__(self,coords,edges,faces):
  self.c=[tuple(float(np.float32(x)) for x in p) for p in coords]
  self.e=[tuple(map(int,e)) for e in edges]
  self.f=[tuple(map(int,f)) for f in faces]
  self.vertices=Buffer([{'co':p} for p in self.c]); self.edges=Buffer([{'vertices':e} for e in self.e])
  polys=[];loops=[]
  for face in self.f:
   polys.append({'loop_start':len(loops),'loop_total':len(face)})
   loops.extend({'vertex_index':i} for i in face)
  self.polygons=Buffer(polys);self.loops=Buffer(loops)
 def as_pointer(self):return id(self)
def quant(p):return tuple(int(np.rint(float(np.float32(x))*100000)) for x in p)
def cycle(f):return min(tuple(f[i:])+tuple(f[:i]) for i in range(len(f))) if f else ()
def under_witness(a,b,m):
 if any(quant(a.c[i])!=quant(b.c[m[i]]) for i in m):return False
 ea=C.Counter(tuple(sorted((m[u],m[v]))) for u,v in a.e)
 eb=C.Counter(tuple(sorted(e)) for e in b.e)
 fa=C.Counter(cycle(tuple(m[i] for i in f)) for f in a.f)
 fb=C.Counter(cycle(f) for f in b.f)
 return ea==eb and fa==fb
def exact_oracle(a,b):
 if len(a.c)!=len(b.c) or len(a.e)!=len(b.e) or len(a.f)!=len(b.f):return None
 if C.Counter(map(quant,a.c))!=C.Counter(map(quant,b.c)):return None
 if C.Counter(map(len,a.f))!=C.Counter(map(len,b.f)):return None
 ca=C.defaultdict(list);cb=C.defaultdict(list)
 for i,p in enumerate(a.c):ca[quant(p)].append(i)
 for j,p in enumerate(b.c):cb[quant(p)].append(j)
 classes=sorted(ca)
 for groups in itertools.product(*(itertools.permutations(cb[c]) for c in classes)):
  mapping={i:j for c,target in zip(classes,groups) for i,j in zip(ca[c],target)}
  if under_witness(a,b,mapping):return mapping
 return None
def transform(a,seed):
 r=random.Random(seed); order=list(range(len(a.c)));r.shuffle(order); inv={i:j for j,i in enumerate(order)}
 edges=[tuple(inv[x] for x in e) for e in a.e]
 edges=[tuple(reversed(e)) if r.randrange(2) else e for e in edges]
 r.shuffle(edges)
 faces=[]
 for face in a.f:
  f=[inv[x] for x in face]; s=r.randrange(len(f)) if f else 0;faces.append(tuple(f[s:]+f[:s]))
 r.shuffle(faces)
 return Mesh([a.c[x] for x in order],edges,faces)
def component_sizes(n,edges,faces,include_faces):
 parent=list(range(n))
 def find(x):
  while parent[x]!=x:x=parent[x]
  return x
 def join(x,y):parent[find(x)]=find(y)
 for u,v in edges:join(u,v)
 if include_faces:
  for f in faces:
   for i in f[1:]:join(f[0],i)
 return sorted(C.Counter(find(i) for i in range(n)).values())
def main():
 source,dest=sys.argv[1:3]
 assert hashlib.sha256(Path(source).read_bytes()).hexdigest()==PIN
 spec=importlib.util.spec_from_file_location('candidate_v101_oracle_r2',source)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 assert m.bpy is None,'Blender bpy forbidden'
 logs=[];counts=C.Counter()
 def check(label,a,b,category):
  st=time.perf_counter();w=exact_oracle(a,b);exp=w is not None;obs=bool(m.meshes_equal(a,b))
  row={'label':label,'category':category,'oracle':exp,'observed_candidate_v101':obs,
       'witness':list(w.items()) if w else None,'elapsed_ms':round((time.perf_counter()-st)*1000,4),'pass':exp==obs}
  logs.append(row);counts[category]+=1
  if exp!=obs:raise AssertionError(json.dumps(row))
 t=Mesh([(0,0,0)]*3,[(0,1),(1,2),(0,2)],[(0,1,2)])
 tr=Mesh([(0,0,0)]*3,[(0,1),(1,2),(0,2)],[(0,2,1)])
 check('SEM-01 coincident winding reversal IS isomorphic',t,tr,'semantic')
 cd=[(0,0,0),(1,0,0),(0,1,0)]
 check('distinguishable winding reversal is NOT isomorphic',Mesh(cd,t.e,t.f),Mesh(cd,t.e,tr.f),'semantic')
 h=Mesh([(0,0,0)]*6,[],[(0,1,2),(2,3,4)])
 assert component_sizes(6,h.e,h.f,False)!=component_sizes(6,h.e,h.f,True)
 check('synthetic face-only hypergraph reindexed',h,transform(h,777),'hypergraph')
 check('multiplicity and face orientation control',
       Mesh([(0,0,0)]*4,[(0,1),(0,1),(1,2)],[(0,1,2),(0,1,2)]),
       Mesh([(0,0,0)]*4,[(0,1),(1,2),(1,2)],[(0,1,2),(0,2,1)]),'multiplicity')
 n=17;coords=[(i,i*i%11,i*i*i%7) for i in range(n)];edges=[(i,(i+1)%n) for i in range(n)]
 big=Mesh(coords,edges,[tuple(range(n))])
 check('n-gon 17 reindexed rotation',big,transform(big,20261022),'long_cycle')
 check('n-gon 17 orientation reversed',big,Mesh(coords,edges,[tuple(reversed(range(n)))]),'long_cycle')
 for i in range(260):
  n=3+(i%4);coords=[rng.choice([(0,0,0),(1,0,0),(2,0,0)]) for _ in range(n)]
  ec=rng.randrange(n+4);edges=[tuple(rng.sample(range(n),2)) for _ in range(ec)]
  faces=[tuple(rng.sample(range(n),rng.randrange(3,min(n,5)+1))) for _ in range(rng.randrange(3))]
  a=Mesh(coords,edges,faces)
  if i%2==0:b=transform(a,1000+i);kind='generated_isomorphic'
  else:
   coords2=list(coords);rng.shuffle(coords2)
   b=Mesh(coords2,[tuple(rng.sample(range(n),2)) for _ in range(ec)],
          [tuple(rng.sample(range(n),len(f))) for f in faces]);kind='randomized_nonmatch_or_match'
  check('random_%03d'%i,a,b,kind)
 report={'scope':'FROZEN v1.0.1 candidate (synthetic QA only, NO Blender)',
         'candidate_sha256':PIN,'rng_seed':21012026,'executed':len(logs),
         'passed':sum(x['pass'] for x in logs),'by_kind':dict(counts),
         'hypergraph_edge_only':component_sizes(6,h.e,h.f,False),
         'hypergraph_edge_and_face':component_sizes(6,h.e,h.f,True),
         'numpy':np.__version__,'python':sys.version,'checks':logs}
 Path(dest).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
 print('PASS %d/%d - v1.0.1 candidate'%(report['passed'],len(logs)))
 print('Categories:',dict(counts));print('Hypergraph: edge-only=%s vs edges+faces=%s'%(report['hypergraph_edge_only'],report['hypergraph_edge_and_face']))
 print('No bpy real; candidate comparison only; no removals')
if __name__=='__main__':main()
