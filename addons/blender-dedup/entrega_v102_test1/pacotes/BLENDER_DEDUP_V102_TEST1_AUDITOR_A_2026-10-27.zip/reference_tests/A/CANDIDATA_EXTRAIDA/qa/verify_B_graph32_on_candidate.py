#!/usr/bin/env python3
"""Adapt B synthetic policy cases F01-F32 into *candidate* fake bpy exercise."""
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_candidate_v101 import (d,Obj,Collection,Scene,Material,NodeTree,Node,FakeText,Driver,
                                 MockID,RNA,Mesh,basic,quick_execute)

ROOT=Path(__file__).resolve().parents[1]
REFERENCE=ROOT/'originais'/'master_r2'/'QA_REFERENCIA'/'B'/'testes_grafo_R2.json'
CANON={x['id']:x for x in json.loads(REFERENCE.read_text())}

def _extra_direct(b, target, name='owner'):
    src=MockID('World',name)
    src.direct=target
    src.bl_rna=RNA('World',direct='POINTER')
    b.other_ids.append(src)
    return src

def setup(case):
    b,objs=basic(count=3)
    D,K,D2=objs
    limits=None
    if case in ('F01','F02','F03','F14','F22','F23','F31','F32'):
        pass
    if case == 'F03':
        c2=Collection('c2',[D]);b.collections.append(c2)
        b.scenes.append(Scene('s2',c2,[D]))
    elif case == 'F04':
        b.objects.append(Obj('surviving_child',None,kind='EMPTY',parent=D))
    elif case == 'F05':
        c=Obj('constraint-owner',None,kind='EMPTY')
        c.constraints=[Node(target=D)];b.objects.append(c)
    elif case == 'F06':
        b.materials.append(Material('driver_owner',animation_data=Driver(target=D)))
    elif case == 'F07':
        t=NodeTree('custom_pointer_owner')
        t.idprops['entry']={'a':[D]};b.node_groups.append(t)
    elif case == 'F08':
        K.modifiers[0].object=D
    elif case == 'F09':
        s=Obj('instance',None,kind='EMPTY')
        s.instance_collection=b.collections[0];b.objects.append(s)
    elif case == 'F10':
        t=NodeTree('tree',[Node(collection=b.collections[0])]);b.node_groups.append(t)
        K.idprops['geometry_tree']=t
    elif case == 'F11':
        ancestor=Collection('ancestor',children=[b.collections[0]])
        b.collections.append(ancestor)
        instance=Obj('instance',None,kind='EMPTY')
        instance.instance_collection=ancestor;b.objects.append(instance)
    elif case == 'F12':
        D2.instance_collection=b.collections[0]
    elif case == 'F13':
        b.node_groups.append(NodeTree('orphan',[Node(collection=b.collections[0])]))
    elif case == 'F14':
        D.parent=K
    elif case == 'F15':
        _extra_direct(b,D,'mystery')
    elif case == 'F16':
        b.bl_rna=None
    elif case == 'F17':
        b.texts.append(FakeText('dynamic','bpy.data.objects[x]'))
    elif case == 'F18':
        D.library=object()
    elif case == 'F19':
        D.is_editable=False
    elif case == 'F20':
        D.override_library=object()
    elif case == 'F21':
        D.is_library_indirect=True
    elif case == 'F22':
        K.library=object();K.is_editable=False
    elif case == 'F23':
        D.data=K.data
    elif case == 'F24':
        D.mode='EDIT'
    elif case == 'F25':
        coords=[(100,0,0),(101,0,0),(100,1,0)]
        e=[(0,1),(1,2),(2,0)];faces=[(0,1,2)]
        loser=Obj('group2_D',Mesh(coords,e,faces),modifier_count=0)
        winner=Obj('group2_K',Mesh(coords,e,faces),modifier_count=6)
        b.objects.extend((loser,winner));b.meshes.extend([loser.data,winner.data])
        b.collections[0].objects.extend((loser,winner));b.scenes[0].objects.extend((loser,winner))
        _extra_direct(b,loser,'unsafe_owner')
    elif case == 'F26':
        limits=d.Limits(bucket_objects=2)
    elif case == 'F27':
        D2.parent=D
    elif case == 'F28':
        tree=NodeTree('used_by_keep_and_drop',[Node(collection=b.collections[0])])
        b.node_groups.append(tree);K.idprops['geo']=tree;D2.idprops['geo']=tree
    elif case == 'F29':
        b.extra_user_map[D]={MockID('World','missing')}
    elif case == 'F30':
        b.objects.append(Obj('nonmesh',None,kind='EMPTY',parent=D))
    elif case == 'F31':
        above=Collection('above',children=[b.collections[0]])
        b.collections.append(above)
        b.scenes.append(Scene('other',above,[]))
    elif case == 'F32':
        tree=NodeTree('owned_node_tree',[Node(target=D)])
        b.node_groups.append(tree);K.idprops['geo']=tree
    return b,limits

failures=[]; cases=[]
for case in sorted(CANON):
    expected=CANON[case]['expected'];b,limits=setup(case)
    try:
        result=quick_execute(b,limits=limits)
        actual='AUTO_REMOVE' if result['status']=='REMOVOES_CONFIRMADAS' else result['status']
    except d.PreflightAborted:
        actual='GLOBAL_ABORT'
    except RuntimeError as exc:
        actual='UNEXPECTED_RUNTIME_ERROR:' + str(exc)[:70]
    ok=expected==actual
    if actual=='GLOBAL_ABORT' and b.objects.remove_calls!=0:ok=False
    cases.append({'case':case,'expected':expected,'observed_candidate':actual,
                  'remove_calls':b.objects.remove_calls,'pass':ok})
    if not ok:failures.append(cases[-1])
report={'scope':'v1.0.1 NEW candidate, synthetic fake bpy, B graph policy reference',
        'cases':len(cases),'passed':len(cases)-len(failures),'failures':failures,'results':cases}
(ROOT/'evidencias'/'B_graph32_candidate.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print('B GRAPH R2 cases on NEW candidate:',report['passed'],'/',report['cases'],'passed')
if failures:
    print('FAILURES:',json.dumps(failures,ensure_ascii=False,indent=2))
    sys.exit(1)
