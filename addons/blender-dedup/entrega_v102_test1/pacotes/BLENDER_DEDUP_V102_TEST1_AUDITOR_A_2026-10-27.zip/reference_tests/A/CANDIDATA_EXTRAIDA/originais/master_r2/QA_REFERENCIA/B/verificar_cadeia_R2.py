#!/usr/bin/env python3
"""Verify R2 input custody including nested prior B hash manifest; read-only."""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parent.parent
ZPATH = ROOT/'ORIGINAIS/ZIP_ORIGINAL.zip'
EXTRACTED = ROOT/'ORIGINAIS/EXTRAIDOS'
EV = ROOT/'EVIDENCIAS'

def digest(b):
    return hashlib.sha256(b).hexdigest()

with ZipFile(ZPATH) as z:
    names = set(z.namelist())
    manifest = {}
    for l in z.read('SHA256SUMS.txt').decode().splitlines():
        if l.strip():
            h,n=l.split('  ',1)
            manifest[n]=h
    checks=[]
    for n,h in manifest.items():
        file_bytes=z.read(n)
        extracted_bytes=(EXTRACTED/n).read_bytes()
        checks.append({'name':n,'sha256_expected':h,'sha256_actual':digest(file_bytes),
            'hash_match':digest(file_bytes)==h,
            'extracted_byte_equal':file_bytes==extracted_bytes})
    nested = z.read('REFERENCIA_SEU_RETORNO_B.zip')
    nested_checks=[]
    import io
    with ZipFile(io.BytesIO(nested)) as prev:
        prev_m=prev.read('MANIFESTO_SHA256.txt').decode()
        for line in prev_m.splitlines():
            if '  ' not in line:continue
            hash_,name=line.split('  ',1)
            if len(hash_) != 64:continue
            try:actual=digest(prev.read(name))
            except KeyError:actual='MISSING'
            nested_checks.append({'name':name,'match':actual==hash_})
        prev_member_count=len(prev.namelist())

    report={
       'sha256_input_zip':digest(ZPATH.read_bytes()),
       'input_zip_members':len(names),
       'input_manifest_entries':len(manifest),
       'all_input_hashes_ok':all(x['hash_match'] for x in checks),
       'all_extracted_bytes_equal':all(x['extracted_byte_equal'] for x in checks),
       'previous_B_zip_sha256':digest(nested),
       'previous_B_zip_members':prev_member_count,
       'previous_B_manifest_entries':len(nested_checks),
       'previous_B_manifest_all_ok':all(x['match'] for x in nested_checks),
       'candidate_v101_present': any('remover_duplicatas_blend_v1_0_1.py' in n for n in names),
       'files':checks,
       'previous_B_nested_checks':nested_checks,
    }
    EV.joinpath('verificacao_entrada_R2.json').write_text(json.dumps(report,indent=2,ensure_ascii=True)+'\n')
    EV.joinpath('verificacao_entrada_R2.log').write_text('\n'.join([
      f"Original ZIP SHA256: {report['sha256_input_zip']}",
      f"Input manifest: {sum(x['hash_match'] for x in checks)}/{len(checks)}",
      f"Extracted bytes equal: {sum(x['extracted_byte_equal'] for x in checks)}/{len(checks)}",
      f"Nested previous B manifest: {sum(x['match'] for x in nested_checks)}/{len(nested_checks)}",
      f"v1.0.1 candidate included: {report['candidate_v101_present']}",
      "No Blender, bpy or .blend used in custody verification."
    ])+'\n')
    print(json.dumps({k:report[k] for k in report if k not in ('files','previous_B_nested_checks')},indent=2))
    assert len(checks)==9 and all(x['hash_match'] and x['extracted_byte_equal'] for x in checks)
    assert len(nested_checks)==32 and all(x['match'] for x in nested_checks)
    assert not report['candidate_v101_present']
