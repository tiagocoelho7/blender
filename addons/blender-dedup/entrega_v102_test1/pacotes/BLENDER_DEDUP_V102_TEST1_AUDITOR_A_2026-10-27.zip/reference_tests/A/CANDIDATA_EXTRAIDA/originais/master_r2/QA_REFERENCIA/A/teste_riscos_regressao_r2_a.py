#!/usr/bin/env python3
"""R2 documentary risk demonstrator. Executes unmodified v1.0 in standard Python only.
Demonstrates baseline NaN identity shortcut and checks numeric budget tension.
These are R2 implementation requirements, NOT R2 code tests.
"""
import hashlib, importlib.util, json, math, sys
from pathlib import Path
from teste_oraculo_independente_r2_a import Mesh
PIN='f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3'
source, output=sys.argv[1:3]
assert hashlib.sha256(Path(source).read_bytes()).hexdigest()==PIN
spec=importlib.util.spec_from_file_location('frozen_dedup_r2_a',source)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
assert mod.bpy is None
m=Mesh([(float('nan'),0,0),(1,0,0),(0,1,0)],[(0,1),(1,2),(0,2)],[(0,1,2)])
same_pointer=mod.meshes_equal(m,m)
error=None
try:mod.quantized_vertices(m)
except BaseException as ex:error=type(ex).__name__
assert same_pointer is True and error=='ValueError'
# Cases where budget must be a reason to ABORT, not a proof of NON-EQUIVALENCE.
limits={'seconds_plan':300,'seconds_pair':45,'comparisons_total':50000,
        'states_total':2000000,'states_pair':250000,
        'temp_plan_bytes':2147483648,'temp_pair_bytes':536870912,'bucket_objects':2048}
assert limits['seconds_pair'] <= limits['seconds_plan']
assert limits['states_pair'] <= limits['states_total']
assert limits['temp_pair_bytes'] <= limits['temp_plan_bytes']
expected={str(k):k*(k-1)//2 for k in (6,8,2048)}
assert expected['6']==15 and expected['8']==28
assert expected['2048']>limits['comparisons_total']
out={
 'scope':'DOCUMENTARY QA and FROZEN baseline v1.0 only. Future v1.0.1 absent',
 'baseline_sha256':PIN,
 'observation_01':{'name':'SAME_MESH_POINTER_NAN_SHORTCUT','same_pointer_equal_baseline_v1':same_pointer,
                   'direct_quantization_error':error,
                   'future_v101_required':'ALL non-finite coordinates must trigger global preflight abort even for shared Mesh identity shortcut'},
 'observation_02':{'name':'COMPARISON_CAP_NONMATCH_BUCKET',
                   'limits_proposed':limits,'combinations_for_all_nonmatches':expected,
                   'future_v101_required':'MUST ABORT entire file, no remove; over-limit is never an evidence of non-duplication'},
 'no_blender':'No bpy or .blend used; zero calls to Blender remove',
 'pass':True}
Path(output).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('PASS: baseline NaN same-pointer True; direct quantization ValueError; must not carry shortcut into v1.0.1 unchanged')
print('PASS: proposed budgets monotonic and relative limits consistent; K=6 => 15, K=8 => 28, K=2048 => 2096128')
print('NOT TESTED: no v1.0.1, budget enforcement remains unimplemented')
