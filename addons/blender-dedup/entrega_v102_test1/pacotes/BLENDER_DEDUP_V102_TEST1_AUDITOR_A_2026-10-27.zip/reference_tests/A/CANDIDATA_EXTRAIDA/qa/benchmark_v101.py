"""Synthetic array-backed 1M-vertex benchmark and fail-closed adversarial budget.
No Blender or real .blend access. Includes wall seconds, process RSS and estimates.
"""
import hashlib, importlib.util, json, os, sys, time
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src'/'remover_duplicatas_blend_v1_0_1.py'
spec=importlib.util.spec_from_file_location('t7_bench_newcandidate_v101',SRC)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
assert m.bpy is None
class Buffer:
    def __init__(self,arr):self.arr=arr
    def __len__(self):return len(self.arr)
    def foreach_get(self,name,out):out[:]=self.arr.reshape(-1)
class Mesh:
    def __init__(self,coords,edges):
        self.vertices=Buffer(coords)
        self.edges=Buffer(edges)
        self.polygons=Buffer(np.empty((0,2),dtype=np.int32))
        self.loops=Buffer(np.empty((0,),dtype=np.int32))
    def as_pointer(self):return id(self)

# Zero numpy RNG variation that could mask a false positive.
N=int(os.environ.get('BENCH_VERTICES','1000000'))
coords=np.empty((N,3),dtype=np.float32)
coords[:,0]=np.arange(N,dtype=np.float32)*0.125
coords[:,1]=np.arange(N,dtype=np.float32)%11
coords[:,2]=7.0
edges=np.column_stack((np.arange(N-1,dtype=np.int32),np.arange(1,N,dtype=np.int32)))
a=Mesh(coords,edges)
b=Mesh(coords[::-1].copy(), (N-1-edges[:,::-1]).astype(np.int32))
# 1D chain edges map to B reversed indexing via N-1-i for each endpoint.
b.edges=Buffer((N-1-edges).astype(np.int32))

budget=m.BudgetContext()
t0=time.perf_counter()
with m.bound_budget(budget):
 with budget.pair():
  same=m.meshes_equal(a,b)
elapsed=time.perf_counter()-t0
record={'scope':'SYNTHETIC NumPy array-backed; NOT Blender/bpy',
 'N_vertices_each':N,'N_edges_each':N-1,'N_faces_each':0,
 'equal_after_reindex':same, 'elapsed_s':round(elapsed,3),
 'budget_states':budget.total_states,'estimated_peak_request_bytes':budget.global_allocation_peak_request,
 'rss_start':budget.initial_rss,'rss_peak_sampled':budget.rss_peak,
 'rss_growth_sampled':(budget.rss_peak-budget.initial_rss) if budget.initial_rss else None,
 'limits_default': vars(budget.limits)}
print('SYNTHETIC_BIG',json.dumps(record,sort_keys=True))
assert same

# Fail-closed adversarial graph pair: 16 vertices all coincident, equal degree,
# non-isomorphic Rook and Shrikhande graphs. Requires networkx for oracle.
import networkx as nx
rook=nx.Graph();rook.add_nodes_from(range(16))
for i in range(16):
 for j in range(i+1,16):
  if i//4==j//4 or i%4==j%4:rook.add_edge(i,j)
shr=nx.Graph();shr.add_nodes_from(range(16))
for i in range(16):
 x,y=divmod(i,4)
 for dx,dy in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1)]:
  shr.add_edge(i,((x+dx)%4)*4+(y+dy)%4)
assert not nx.is_isomorphic(rook,shr)
coincident=np.zeros((16,3),dtype=np.float32)
ma=Mesh(coincident,np.asarray(list(rook.edges()),dtype=np.int32))
mb=Mesh(coincident,np.asarray(list(shr.edges()),dtype=np.int32))
short=m.BudgetContext(m.Limits(total_seconds=4,pair_seconds=0.1,states_per_pair=750))
start=time.perf_counter()
try:
 with m.bound_budget(short):
  with short.pair():
   equal=m.meshes_equal(ma,mb)
 outcome='DETERMINATE_NON_EQUAL' if equal is False else 'UNSAFE_FALSE_POSITIVE'
except m.ComplexityBudgetExceeded:
 outcome='ABORT_INCONCLUSIVE_NO_DELETE'
record2={'case':'Rook vs Shrikhande','oracle_equal':False,'candidate_outcome':outcome,
         'elapsed_s':round(time.perf_counter()-start,4),'states':short.total_states,
         'pair_time_budget':short.limits.pair_seconds,'rss_peak':short.rss_peak}
print('SYNTHETIC_ADVERSARIAL',json.dumps(record2,sort_keys=True))
assert outcome!='UNSAFE_FALSE_POSITIVE'
(ROOT/'evidencias'/'benchmark_v101.json').write_text(json.dumps({'large':record,'adversarial':record2},indent=2)+'\n')
