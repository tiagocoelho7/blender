"""Timing probe: cooperative deadline on degenerate coincident class, offline."""
import json,time
import importlib.util,sys,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'CANDIDATA_EXTRAIDA/src/remover_duplicatas_blend_v1_0_1.py'
s=importlib.util.spec_from_file_location('deadline_candidate',p);d=importlib.util.module_from_spec(s);sys.modules[s.name]=d;s.loader.exec_module(d)
class Buf:
 def __len__(self):return 0
 def foreach_get(self,key,out):pass
class Fake:
 def __init__(self,n):self.vertices=range(n);self.edges=Buf();self.polygons=Buf();self.loops=Buf()
n=200;q=np.zeros((n,3),dtype=np.int64);o=np.arange(n)
requested=.010
budget=d.BudgetContext(d.Limits(pair_seconds=requested,total_seconds=10,mem_global_bytes=2_000_000_000))
start=time.monotonic()
try:
 with d.bound_budget(budget):
  with budget.pair():d._ambiguous_isomorphism(Fake(n),Fake(n),q,q,o,o)
 outcome='COMPLETED'
except d.ComplexityBudgetExceeded as e:
 outcome='ABORT_RESOURCE'
except Exception as e:
 outcome='UNEXPECTED_'+type(e).__name__
elapsed=time.monotonic()-start
print(json.dumps({'n':n,'budget_pair_seconds':requested,'elapsed_seconds':round(elapsed,4),'overshoot_factor':round(elapsed/requested,1),'states':budget.total_states,'outcome':outcome}))
