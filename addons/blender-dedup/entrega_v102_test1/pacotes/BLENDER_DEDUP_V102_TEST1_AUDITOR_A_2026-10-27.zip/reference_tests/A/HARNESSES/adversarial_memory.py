"""Memory accounting counterexample for candidate internal ambiguous search, synthetic only.
Run in subprocess per size; do not run Blender. Probe is intentionally small.
"""
import importlib.util, json, os, sys, time
import numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'CANDIDATA_EXTRAIDA'
s=importlib.util.spec_from_file_location('memory_candidate',ROOT/'src/remover_duplicatas_blend_v1_0_1.py')
c=importlib.util.module_from_spec(s);sys.modules[s.name]=c;s.loader.exec_module(c)
class Buf:
 def __len__(self):return 0
 def foreach_get(self,k,o):pass
class Fake:
 def __init__(self,n):
  self.vertices=range(n);self.edges=Buf();self.polygons=Buf();self.loops=Buf()

def run(n):
 q=np.zeros((n,3),dtype=np.int64)
 o=np.arange(n,dtype=np.int64)
 mesh=Fake(n)
 limit=60_000
 budget=c.BudgetContext(c.Limits(pair_seconds=4,total_seconds=5,mem_pair_bytes=limit,mem_global_bytes=1_000_000_000))
 start=time.monotonic()
 with c.bound_budget(budget):
  with budget.pair():
   equal=c._ambiguous_isomorphism(mesh,mesh,q,q,o,o)
 budget.checkpoint('final')
 elapsed=time.monotonic()-start
 rss_growth=max(budget.rss_peak-budget.initial_rss,0)
 return {'n':n,'true':equal,'seconds':round(elapsed,4),
 'pair_cap_bytes':limit,'reported_largest_allocation':budget.global_allocation_peak_request,
 'sampled_rss_delta_bytes':rss_growth,'rss_over_pair_cap':rss_growth>limit,
 'states':budget.total_states}
if __name__=='__main__':
 print(json.dumps(run(int(sys.argv[1]))))
