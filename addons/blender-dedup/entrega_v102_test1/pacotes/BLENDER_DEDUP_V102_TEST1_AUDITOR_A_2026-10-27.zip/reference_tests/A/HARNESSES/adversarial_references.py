"""Independent targeted mock-bpy contraproofs for candidate v1.0.1.
Synthetic, no Blender, no .blend, no modifications to frozen candidate.
"""
import importlib.util, json, sys, traceback, os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'CANDIDATA_EXTRAIDA'
PATH=ROOT/'qa/test_candidate_v101.py'
spec=importlib.util.spec_from_file_location('qa_as_fixture',PATH)
qa=importlib.util.module_from_spec(spec);sys.modules[spec.name]=qa;spec.loader.exec_module(qa)
c=qa.d
results=[]
def track(name,method):
 try:
  data=method(); results.append({'case':name,'result':data});print(name,':',json.dumps(data,ensure_ascii=True))
 except BaseException as e:
  results.append({'case':name,'harness_error':type(e).__name__,'message':str(e)});print(name,'HARNESS_ERROR',e)

def baseline_safe():
 b,objs=qa.basic();return b,objs

def mutate_parent_during_ledger():
 b,objs=baseline_safe(); survivor=qa.Obj('survivor_empty',None,kind='EMPTY');b.objects.append(survivor)
 def emit(label,data):
  if label=='[T7-DEDUP-LEDGER-PRE]':survivor.parent=objs[0]
 result=c.execute(b,emit=emit)
 return {'status':result['status'],'removed_calls':b.objects.remove_calls,
   'removed_target':objs[0] not in b.objects,'dangling_survivor_parent':survivor.parent is objs[0],
   'survivor_remains':survivor in b.objects}

def update_parent_on_first_remove():
 b,objs=baseline_safe();survivor=qa.Obj('survivor_empty',None,kind='EMPTY');b.objects.append(survivor)
 base=b.objects.remove
 def patched_remove(obj,do_unlink=False):
  result=base(obj,do_unlink=do_unlink)
  if b.objects.remove_calls==1:survivor.parent=objs[2]
  return result
 b.objects.remove=patched_remove
 result=c.execute(b,emit=lambda label,data:None)
 return {'status':result['status'],'removed_calls':b.objects.remove_calls,
   'removed_target':objs[2] not in b.objects,'dangling_survivor_parent':survivor.parent is objs[2],
   'survivor_remains':survivor in b.objects}

def imported_alias_dynamic_lookup():
 b,objs=baseline_safe()
 script='from bpy import data as d\nname = "model." + str(0).zfill(3)\nobj = d.objects[name]'
 t=qa.FakeText('script',script);b.texts.append(t)
 detection=c._text_lookup_risk(script,{objs[0].name})
 res=c.execute(b,emit=lambda label,data:None)
 return {'blocked_lookup_risk':detection,'status':res['status'],'removed':b.objects.remove_calls,
         'script_points_to_removed_name':objs[0].name not in [x.name for x in b.objects],
         'script_content':script}

def bpy_data_via_getattr_dynamic_lookup():
 b,objs=baseline_safe()
 script='import bpy\nwhich = "model." + str(0).zfill(3)\nresult = getattr(bpy.data, "objects").get(which)'
 b.texts.append(qa.FakeText('script',script))
 detection=c._text_lookup_risk(script,{objs[0].name})
 res=c.execute(b,emit=lambda label,data:None)
 return {'blocked_lookup_risk':detection,'status':res['status'],'removed':b.objects.remove_calls,
         'script_points_to_removed_name':objs[0].name not in [x.name for x in b.objects]}

def unbalanced_user_map_is_accepted():
 b,objs=baseline_safe()
 b.extra_user_map[objs[0]]=set()
 inventory=c.preflight(b)[2]['inventory']
 return {'user_map_owners_claimed':0,
         'rna_membership_found':sum(1 for r in inventory['references'] if r['target']['name']==objs[0].name),
         'preflight_passed':True}

for name,fn in [
 ('REF-01-mutate-reference-after-ledger',mutate_parent_during_ledger),
 ('REF-02-mutate-reference-after-first-remove',update_parent_on_first_remove),
 ('REF-03-Text-imported-data-alias-lookup',imported_alias_dynamic_lookup),
 ('REF-04-Text-getattr-lookup',bpy_data_via_getattr_dynamic_lookup),
 ('REF-05-user-map-undercount',unbalanced_user_map_is_accepted),
]:track(name,fn)
out=Path(os.environ.get('DEDUP_RESULT_DIR', Path(__file__).resolve().parents[1]/'REPLAY_GERADO'))
out.mkdir(parents=True,exist_ok=True)
(out/'adversarial_references.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
