"""Bounded external process for memory counterexample."""
import json,subprocess,sys,pathlib,os
root=pathlib.Path(__file__).resolve().parents[1]
out=pathlib.Path(os.environ.get('DEDUP_RESULT_DIR',root/'REPLAY_GERADO'));out.mkdir(parents=True,exist_ok=True)
rows=[]
for n in (100,200,240):
 try:
  p=subprocess.run([sys.executable,str(root/'HARNESSES'/'adversarial_memory.py'),str(n)],capture_output=True,text=True,timeout=8)
  rows.append({'n':n,'returncode':p.returncode,'data':json.loads(p.stdout) if p.returncode==0 else None,'stderr':p.stderr[-600:]})
 except subprocess.TimeoutExpired:
  rows.append({'n':n,'timeout_external_s':8})
print(json.dumps(rows,indent=2))
(out/'adversarial_memory.json').write_text(json.dumps(rows,indent=2))
