"""Independent brute-force vertex-bijection reference; synthetic only.
Does not derive equality from candidate labels, graph refinements, or hashes.
"""
import argparse, collections, importlib.util, itertools, json, random, sys, time, os
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]/'CANDIDATA_EXTRAIDA'
spec=importlib.util.spec_from_file_location('candidate_geometry_only',ROOT/'src/remover_duplicatas_blend_v1_0_1.py')
c=importlib.util.module_from_spec(spec);sys.modules[spec.name]=c;spec.loader.exec_module(c)

class Buf:
 def __init__(self,rows):self.rows=rows
 def __len__(self):return len(self.rows)
 def foreach_get(self,key,out):
  vals=[]
  for r in self.rows:
   x=r[key]
   vals.extend(x if isinstance(x,(tuple,list,np.ndarray)) else [x])
  out[:]=np.array(vals,dtype=out.dtype)
class Mesh:
 def __init__(self,coords,edges,faces):
  self.coords=coords;self.e=edges;self.f=faces
  self.vertices=Buf([{'co':p} for p in coords])
  self.edges=Buf([{'vertices':p} for p in edges])
  loops=[];polygons=[]
  for f in faces:
   polygons.append({'loop_start':len(loops),'loop_total':len(f)})
   loops.extend({'vertex_index':v} for v in f)
  self.polygons=Buf(polygons);self.loops=Buf(loops)
 def as_pointer(self):return id(self)

def rotmin(seq):
 seq=tuple(seq)
 return min(seq[i:]+seq[:i] for i in range(len(seq))) if seq else ()
def oracle(a,b):
 if (len(a.coords),len(a.e),len(a.f),sum(map(len,a.f)))!=(len(b.coords),len(b.e),len(b.f),sum(map(len,b.f))):return False
 qa=[tuple(int(np.rint(float(np.float32(x))*100000)) for x in v) for v in a.coords]
 qb=[tuple(int(np.rint(float(np.float32(x))*100000)) for x in v) for v in b.coords]
 if collections.Counter(qa)!=collections.Counter(qb):return False
 groups=[]
 for coord in sorted(set(qa)):
  ia=[i for i,v in enumerate(qa) if v==coord];ib=[i for i,v in enumerate(qb) if v==coord]
  groups.append((ia,list(itertools.permutations(ib))))
 be=collections.Counter(tuple(sorted(e)) for e in b.e)
 bf=collections.Counter(rotmin(f) for f in b.f)
 for perms in itertools.product(*(t for _,t in groups)):
  mapping={a:b for (ais,_),p in zip(groups,perms) for a,b in zip(ais,p)}
  if collections.Counter(tuple(sorted(mapping[i] for i in e)) for e in a.e)!=be:continue
  if collections.Counter(rotmin(tuple(mapping[i] for i in f)) for f in a.f)==bf:return True
 return False

def random_mesh(r,n):
 pool=[(0.,0.,0.),(0.,0.,0.),(1.,0.,0.),(2.,0.,0.),(3.,0.,0.)]
 coords=[pool[r.randrange(len(pool))] for i in range(n)]
 edges=[tuple(r.choices(range(n),k=2)) for j in range(r.randrange(n*2+1))]
 faces=[tuple(r.choices(range(n),k=r.randrange(3,min(7,n+2)))) for j in range(r.randrange(5))]
 return Mesh(coords,edges,faces)

def permute(r,a):
 order=list(range(len(a.coords)));r.shuffle(order)
 trans={k:order.index(k) for k in range(len(order))}
 coords=[a.coords[i] for i in order]
 edges=[(trans[u],trans[v]) for u,v in a.e];r.shuffle(edges)
 faces=[]
 for f in a.f:
  f=tuple(trans[x] for x in f)
  sh=r.randrange(len(f))
  faces.append(f[sh:]+f[:sh])
 r.shuffle(faces)
 return Mesh(coords,edges,faces)

if __name__=='__main__':
 r=random.Random(20261023)
 cases=[];results=[];start=time.monotonic()
 for i in range(400):
  n=r.randrange(2,8)
  a=random_mesh(r,n)
  if i%4==0:
   b=permute(r,a);label='guaranteed_equal'
  elif i%4==1:
   b=permute(r,a)
   if b.e:b.e[0]=(r.randrange(n),r.randrange(n))
   elif b.f:
    f=list(b.f[0]);f[-1]=r.randrange(n);b.f[0]=tuple(f)
   else:
    b.coords[-1]=(9.,0.,0.)
   b=Mesh(b.coords,b.e,b.f);label='mutation_maybe'
  elif i%4==2:
   b=random_mesh(r,n);label='independent_random'
  else:
   # Hypergraph faces-only with repeated/coincident vertices.
   a=Mesh([(0.,0.,0.)]*n,[],[tuple(r.choices(range(n),k=r.randrange(3,8))) for j in range(r.randrange(3))])
   b=permute(r,a) if i%8==3 else random_mesh(r,n);label='faces_only'
  t=time.monotonic()
  expected=oracle(a,b)
  with c.bound_budget(c.BudgetContext(c.Limits(total_seconds=300,pair_seconds=10))):
   actual=c.meshes_equal(a,b)
  rec={'index':i,'type':label,'n':n,'expected':expected,'actual':actual,'sec':round(time.monotonic()-t,6)}
  if expected!=actual:
   rec['a']={'coords':a.coords,'edges':a.e,'faces':a.f};rec['b']={'coords':b.coords,'edges':b.e,'faces':b.f}
  results.append(rec)
 mismatch=[x for x in results if x['expected']!=x['actual']]
 path=Path(os.environ.get('DEDUP_RESULT_DIR', Path(__file__).resolve().parents[1]/'REPLAY_GERADO'))/'independent_geometry_oracle.json'
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps({'seed':20261023,'total':len(results),'mismatches':len(mismatch),'seconds':round(time.monotonic()-start,4),'cases':results},indent=2))
 print('INDEPENDENT_GEOMETRY',len(results),'mismatches',len(mismatch),'elapsed',round(time.monotonic()-start,3), 'first',mismatch[:1])
 sys.exit(bool(mismatch))
