# Plano de reparos para candidata nova v1.0.1 (não implementada)

**Baseline imutável:** `CONGELADO/remover_duplicatas_blend_v1.py`, SHA-256 `f4290a066e23c6a1089c67c88c13b633c4b017d823220240222c4ca78a479fb3`.
**Alterações:** somente em **novo arquivo** `remover_duplicatas_blend_v1_0_1.py`; não editar baseline, relatórios, ZIPs nem a especificação congelada.

## P0-A — segurança de referências antes da exclusão

- Elaborar inventário de **referências recebidas** por cada objeto candidato à remoção que provenham de objetos/IDs **sobreviventes**: parents/children; constraints; drivers/targets; modifiers de outros objetos que apontem para aquele Object; instancing, custom ID pointers e outras dependências relevantes.
- Não confundir associação de objeto à collection com dependência que precisa migrar: R3 explicitamente ignora collections para identidade e alcance. A análise, porém, precisa considerar todos os IDs/cenas e não só os visíveis.
- Nunca remapear automaticamente para `keep` apenas porque as geometrias-base são iguais: posição/rotação/escala podem ser distintas.
- Onde a integridade não puder ser verificada ou a referência exigir escolha semântica, **falhar fechado antes da primeira chamada a `remove()`**, com lista de objetos e razões. Sem diálogo obrigatório nos casos seguros.
- Evidências: cenas simuladas e fixtures posteriores no Blender 5.0 em cópia, incluindo pai filho, constraints, drivers e referencias cruzadas multi-scene. Cobrir dependências ocultas. Deixar claro o que não pode ser inspecionado completamente.

## P0-B — algoritmo exato sob recursos limitados

- Preservar equivalência topológica independente dos índices; não substituir comparação por igualdade simples de listas ou hash.
- Reduzir custo da seleção de candidatos em classes de coordenadas coincidentes (evitar alocação ingênua O(g²) e repetição O(g³), quando possível). Melhorar invariantes/refinamento e componentes conexos antes do backtracking.
- Introduzir **orçamento de tempo/estados/memória apropriado**, com erro tipado de complexidade excedida que cause **aborto completo do planejamento**, sem remoção. Não classificar caso inconclusivo como não duplicado.
- Testar contraprovas A e B: ciclos coincidentes não isomorfos, um vértice distinto e centenas de coincidentes, grafos regulares simétricos, malhas com milhões de vértices regulares e índices permutados. Registrar tempo/pico de memória e configuração; não exigir falso 'PASS' sob timeout.

## P1-C — exclusões não transacionais

- Validar integralmente o plano e IDs antes do primeiro `remove()` (referências, editabilidade, modo Blender, dados disponíveis e cancelamentos por recurso).
- Antes do primeiro `remove`, manter um registro consolidado de keep/drop, para prints/diagnóstico e recuperação; não exigir prévia aprovação individual.
- Capturar e reportar falhas de remoção com nome do objeto e lista exata do que já foi excluído; não afirmar rollback; **não salvar o `.blend`**.
- Fazer testes com falha injetada na primeira, segunda e última remoção e testar que erros do plano causam **zero** exclusões.

## P1-D — admissibilidade de biblioteca/overrides

- Verificar política para `library`, `override_library`, `is_editable`, `is_library_indirect`, links multi-cena e datablocks compartilhados. Qualquer status não demonstrado seguro deve impedir exclusão **antes** do primeiro `remove()`.
- A função de descarte é de Object, não de Mesh. Preservar os dados referenciados por survivors; não introduzir limpeza em `bpy.data.meshes.remove` inadvertidamente.
- Testar status fake adversariais e mais tarde Blender 5.0 real em cópias autorizadas.

## P2-E — QA, regressões e entrega

- Reexecutar todos os testes A e B sobre a **nova candidata**; scripts de QA devem apontar explicitamente para novo caminho e novo SHA-256, não o v1.0 congelado.
- Acrescentar fixtures negativas: ID compartilhado, objeto não MESH, alteração destrutiva, shape key vs modifier, edit mode, NaN/Inf, faces de 14+ lados, multi-scene, normal invertida, arrays com índices permutados.
- Proteger a cadeia de custódia com SHA-256 da v1.0 e da nova candidata e manifestos verificáveis. Bundle novo: script, diff unificado, especificação, relatórios, logs, testes, hashes, README e prompt de continuidade. Marcar **candidata**, não produção.

## Critério de conclusão

Todos os riscos e resultados devem estar explícitos; sem dependências inseguras o script continua removendo automaticamente conforme R4. R5 e o gate de Blender real continuam vigentes. O Master deve consolidar nova auditoria cega A/B e somente depois submeter prova real sob autorização.
