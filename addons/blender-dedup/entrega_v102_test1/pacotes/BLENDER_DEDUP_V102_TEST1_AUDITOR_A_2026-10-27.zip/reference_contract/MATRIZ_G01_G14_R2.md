# Matriz de gate documental R2 (pre-implementacao)

Este checklist e documental: `SUFICIENTE` nao significa implementado/homologado.

| ID | Evidencia de criterio verificavel exigida no adendo R2 | Resultado da rechecagem A/B |
|---|---|---|
| G01 | Inventario por drop, owner ID, RNA path, categoria e status da varredura em IDs sobreviventes | A preencher |
| G02 | Permitir membership simples; bloquear consumo indireto de Collection por survivor | A preencher |
| G03 | Drivers em IDs nao-Object, nested IDProperties, RNA nodes/sockets, unknown => aborto global | A preencher |
| G04 | Nao remapear dependencias para keep por geometria | A preencher |
| G05 | Oraculo matematico orientado, bijecao global, SEM-01 e teste negativo com vertices distintos | A preencher |
| G06 | Orçamento numerico global/par: tempo, estados, pares, estimativa memoria, bucket; propagacao erro | A preencher |
| G07 | QA com positivos/negativos certificados, n-gons, vertices coincidentes, 24 oraculos B futuros | A preencher |
| G08 | Modifiers > shape keys > nome, nunca reordenar por editabilidade | A preencher |
| G09 | Matriz KEEP/DROP/Mesh linked, override, readonly, indirect, shared, multi-scene | A preencher |
| G10 | Ledger antes da primeira exclusao, reconciliacao de erro pos-mutacao e estado indeterminado | A preencher |
| G11 | SHA, diffs, originais, prompt continuidade e gate de Blender real expresso | A preencher |
| G12 | Quantizacao 5 casas e fronteiras; NaN/Inf/overflow => erro, nao false | A preencher |
| G13 | Scripts textuais/dinamicos: fronteira da prova e risco residual documentados | A preencher |
| G14 | Normais Blender 5.0 testadas apenas apos autorizacao; nenhum blender ou .blend agora | A preencher |

Veredito permitido: `GO DOCUMENTAL PARA IMPLEMENTAR`, `HOLD DOCUMENTAL`, `INCONCLUSIVO`. **Nunca** aprovar execucao Blender, candidata ainda inexistente ou producao a partir deste checklist.
